import math
import platform
import struct
import time
import serial
import serial.tools.list_ports
from multiprocessing import Manager, Process

from .taobotics_logger import Logger
from .taobotics_predefine import FlagState, FunctionResult

# 对象字典，用于存储设备的全部 IMU 信息，缓存数据，方便机器人快速获取
usb_imu_taobotics_shared_od = {}
usb_imu_taobotics_shared_manager = Manager()
usb_imu_taobotics_od = {}


# crc 校验
def checksum(list_data, check_data):
    data = bytearray(list_data)
    crc = 0xFFFF

    for pos in data:
        crc ^= pos
        for i in range(8):
            if (crc & 1) != 0:
                crc >>= 1
                crc ^= 0xA001
            else:
                crc >>= 1

    return hex(((crc & 0xFF) << 8) + (crc >> 8)) == hex(check_data[0] << 8 | check_data[1])


# 16 进制转 ieee 浮点数
def hex_to_ieee(raw_data):
    python_version = platform.python_version()[0]
    ieee_data = []
    raw_data.reverse()

    for i in range(0, len(raw_data), 4):
        data2str = (
            hex(raw_data[i] | 0xFF00)[4:6]
            + hex(raw_data[i + 1] | 0xFF00)[4:6]
            + hex(raw_data[i + 2] | 0xFF00)[4:6]
            + hex(raw_data[i + 3] | 0xFF00)[4:6]
        )
        if python_version == "2":
            ieee_data.append(struct.unpack(">f", data2str.decode("hex"))[0])
        if python_version == "3":
            ieee_data.append(struct.unpack(">f", bytes.fromhex(data2str))[0])
    ieee_data.reverse()

    return ieee_data


# 处理串口数据
def handle_serial_data(usb_imu, raw_data):
    global usb_imu_taobotics_shared_od

    python_version = platform.python_version()[0]

    if python_version == "2":
        usb_imu_taobotics_shared_od.get(usb_imu).get("buff").update(
            {usb_imu_taobotics_shared_od.get(usb_imu).get("key"): ord(raw_data)}
        )
    if python_version == "3":
        usb_imu_taobotics_shared_od.get(usb_imu).get("buff").update(
            {usb_imu_taobotics_shared_od.get(usb_imu).get("key"): raw_data}
        )

    usb_imu_taobotics_shared_od.get(usb_imu).update({"key": usb_imu_taobotics_shared_od.get(usb_imu).get("key") + 1})
    if usb_imu_taobotics_shared_od.get(usb_imu).get("buff")[0] != 0xAA:
        usb_imu_taobotics_shared_od.get(usb_imu).update({"key": 0})
        return

    if usb_imu_taobotics_shared_od.get(usb_imu).get("key") < 3:
        return

    if usb_imu_taobotics_shared_od.get(usb_imu).get("buff")[1] != 0x55:
        usb_imu_taobotics_shared_od.get(usb_imu).update({"key": 0})
        return

    # 根据数据长度位的判断, 来获取对应长度数据
    if (
        usb_imu_taobotics_shared_od.get(usb_imu).get("key")
        < usb_imu_taobotics_shared_od.get(usb_imu).get("buff")[2] + 5
    ):
        return

    else:
        data_buff = list(usb_imu_taobotics_shared_od.get(usb_imu).get("buff").values())  # 获取字典所以 value

        if (
            usb_imu_taobotics_shared_od.get(usb_imu).get("buff")[2] == 0x2C
            and usb_imu_taobotics_shared_od.get(usb_imu).get("pub_flag")[0]
        ):
            if checksum(data_buff[2:47], data_buff[47:49]):
                data = hex_to_ieee(data_buff[7:47])
                usb_imu_taobotics_shared_od.get(usb_imu).update({"angular_velocity": data[1:4]})
                usb_imu_taobotics_shared_od.get(usb_imu).update({"acceleration": data[4:7]})
                usb_imu_taobotics_shared_od.get(usb_imu).update({"magnetometer": data[7:10]})
            else:
                print("校验失败")

            usb_imu_taobotics_shared_od.get(usb_imu).get("pub_flag")[0] = False

        elif (
            usb_imu_taobotics_shared_od.get(usb_imu).get("buff")[2] == 0x14
            and usb_imu_taobotics_shared_od.get(usb_imu).get("pub_flag")[1]
        ):
            if checksum(data_buff[2:23], data_buff[23:25]):
                data = hex_to_ieee(data_buff[7:23])
                usb_imu_taobotics_shared_od.get(usb_imu).update({"angle_degree": data[1:4]})
            else:
                print("校验失败")

            usb_imu_taobotics_shared_od.get(usb_imu).get("pub_flag")[1] = False

        else:
            print("该数据处理类没有提供该 " + str(usb_imu_taobotics_shared_od.get(usb_imu).get("buff")[2]) + " 的解析")
            print("或数据错误")
            usb_imu_taobotics_shared_od.get(usb_imu).update({"buff": {}})
            usb_imu_taobotics_shared_od.get(usb_imu).update({"key": 0})

        usb_imu_taobotics_shared_od.get(usb_imu).update({"buff": {}})
        usb_imu_taobotics_shared_od.get(usb_imu).update({"key": 0})
        if (
            usb_imu_taobotics_shared_od.get(usb_imu).get("pub_flag")[0] == True
            or usb_imu_taobotics_shared_od.get(usb_imu).get("pub_flag")[1] == True
        ):
            return

        usb_imu_taobotics_shared_od.get(usb_imu).get("pub_flag")[0] = usb_imu_taobotics_shared_od.get(usb_imu).get(
            "pub_flag"
        )[1] = True
        acc_k = math.sqrt(
            usb_imu_taobotics_shared_od.get(usb_imu).get("acceleration")[0] ** 2
            + usb_imu_taobotics_shared_od.get(usb_imu).get("acceleration")[1] ** 2
            + usb_imu_taobotics_shared_od.get(usb_imu).get("acceleration")[2] ** 2
        )

        # print(
        #     '''
        #     usb: %s
        #     加速度(m/s²)：x轴：%.2f y轴：%.2f z轴：%.2f
        #     角速度(rad/s)：x轴：%.2f y轴：%.2f z轴：%.2f
        #     欧拉角(°)：x轴：%.2f y轴：%.2f z轴：%.2f
        #     磁场：x轴：%.2f y轴：%.2f z轴：%.2f'''
        #     % (
        #         usb,
        #         usb_imu_taobotics.get(usb_imu).get("acceleration")[0] * -9.8 / acc_k,
        #         usb_imu_taobotics.get(usb_imu).get("acceleration")[1] * -9.8 / acc_k,
        #         usb_imu_taobotics.get(usb_imu).get("acceleration")[2] * -9.8 / acc_k,
        #         usb_imu_taobotics.get(usb_imu).get("angular_velocity")[0],
        #         usb_imu_taobotics.get(usb_imu).get("angular_velocity")[1],
        #         usb_imu_taobotics.get(usb_imu).get("angular_velocity")[2],
        #         usb_imu_taobotics.get(usb_imu).get("angle_degree")[0],
        #         usb_imu_taobotics.get(usb_imu).get("angle_degree")[1],
        #         usb_imu_taobotics.get(usb_imu).get("angle_degree")[2],
        #         usb_imu_taobotics.get(usb_imu).get("magnetometer")[0],
        #         usb_imu_taobotics.get(usb_imu).get("magnetometer")[1],
        #         usb_imu_taobotics.get(usb_imu).get("magnetometer")[2]
        #     ))

    return FunctionResult.SUCCESS


# ---------------------------------------------------------------------------------------------------------------------


def thread_usb_imu_taobotics_comm(usb_imu):
    global usb_imu_taobotics_shared_od

    print("usb_imu = ", usb_imu)

    # 打开串口
    try:
        usb_imu_taobotics_serial = serial.Serial(port=usb_imu, baudrate=921600, timeout=0.5)
    except Exception as e:
        Logger().print_error("USB IMU Taobotics ", usb_imu, " init error: ", e)
        return FunctionResult.FAIL

    if usb_imu_taobotics_serial is not None:
        if usb_imu_taobotics_serial.is_open:
            Logger().print_info("USB IMU Taobotics ", usb_imu, " is already opened.")
        else:
            usb_imu_taobotics_serial.open()
    else:
        Logger().print_error("USB IMU Taobotics ", usb_imu, " is None")
        return FunctionResult.FAIL

    # 数据解析
    while True:
        if usb_imu_taobotics_shared_od.get(usb_imu).get("thread_kill_flag") == FlagState.SET:
            break

        # 读取数据
        try:
            usb_imu_taobotics_serial_buff_count = usb_imu_taobotics_serial.in_waiting
        except Exception as e:
            Logger().print_error("USB IMU Taobotics ", usb_imu, " inWaiting error: ", e)
            break
        else:
            if usb_imu_taobotics_serial_buff_count > 0:
                usb_imu_taobotics_serial_buff = usb_imu_taobotics_serial.read(usb_imu_taobotics_serial_buff_count)

                # 解析数据
                for i in range(0, usb_imu_taobotics_serial_buff_count):
                    handle_serial_data(usb_imu, usb_imu_taobotics_serial_buff[i])

        # print(usb_imu_taobotics_shared_od.get(usb_imu).get("angle_degree"))
        # time.sleep(0.0001)

        # break

    # 关闭串口
    if usb_imu_taobotics_serial is not None:
        if usb_imu_taobotics_serial.is_open:
            usb_imu_taobotics_serial.close()
        else:
            Logger().print_info("USB IMU Taobotics ", usb_imu, " is already closed.")
    else:
        Logger().print_error("USB IMU Taobotics ", usb_imu, " is None")
        return FunctionResult.FAIL

    return FunctionResult.SUCCESS


def process_usb_imu_taobotics_comm(usb_imu, parent_process_od_value):
    global usb_imu_taobotics_shared_od

    Logger().print_info("子进程 usb_imu = ", usb_imu)
    Logger().print_info("子进程 od_value = ", parent_process_od_value)

    usb_imu_taobotics_shared_od = dict(parent_process_od_value)

    # 打开串口
    try:
        usb_imu_taobotics_serial = serial.Serial(port=usb_imu, baudrate=921600, timeout=0.5)
    except Exception as e:
        Logger().print_error("USB IMU Taobotics ", usb_imu, " init error: ", e)
        return FunctionResult.FAIL

    if usb_imu_taobotics_serial is not None:
        if usb_imu_taobotics_serial.is_open:
            Logger().print_info("USB IMU Taobotics ", usb_imu, " is already opened.")
        else:
            usb_imu_taobotics_serial.open()
    else:
        Logger().print_error("USB IMU Taobotics ", usb_imu, " is None")
        return FunctionResult.FAIL

    time_in_read_data_in_s = time.time()
    last_time_in_read_data_in_s = time.time()
    # target_read_data_period_in_s = 0.00333  # update frequency 300Hz
    target_read_data_period_in_s = 0.01  # update frequency 100Hz

    # 数据解析
    while True:
        if usb_imu_taobotics_shared_od.get(usb_imu).get("thread_kill_flag") == FlagState.SET:
            break

        # 记录数据采集时间
        time_in_read_data_in_s = time.time()
        read_data_period = time_in_read_data_in_s - last_time_in_read_data_in_s
        last_time_in_read_data_in_s = time_in_read_data_in_s

        # --------------------------------------------------------------------------------------------------------------
        time_start_of_read_data_in_s = time.time()

        # 读取数据
        try:
            usb_imu_taobotics_serial_buff_count = usb_imu_taobotics_serial.in_waiting
            # print("usb_imu_taobotics_serial_buff_count = ", usb_imu_taobotics_serial_buff_count)
        except Exception as e:
            Logger().print_error("USB IMU Taobotics ", usb_imu, " inWaiting error: ", e)
            break
        else:
            if usb_imu_taobotics_serial_buff_count > 0:
                usb_imu_taobotics_serial_buff = usb_imu_taobotics_serial.read(usb_imu_taobotics_serial_buff_count)

                # print(usb_imu_taobotics_serial_buff_count)  # 测试采集数据的发送频率

                # 解析数据
                for i in range(0, usb_imu_taobotics_serial_buff_count):
                    handle_serial_data(usb_imu, usb_imu_taobotics_serial_buff[i])

                # 数据覆盖
                parent_process_od_value.update({usb_imu: usb_imu_taobotics_shared_od.get(usb_imu)})
                # print("子进程 usb_imu_taobotics_shared_od = ", usb_imu_taobotics_shared_od, "\n")
            else:
                # 没有数据的时候，不要更新共享变量 od_value，减少资源消耗
                pass

        time_end_of_read_data_in_s = time.time()
        time_of_read_data_in_s = time_end_of_read_data_in_s - time_start_of_read_data_in_s
        # --------------------------------------------------------------------------------------------------------------

        # wait for enough time for date update, and data to be ready
        time_to_sleep_in_s = target_read_data_period_in_s - time_of_read_data_in_s
        if time_to_sleep_in_s >= 0:
            pass
        else:
            time_to_sleep_in_s = 0

        time_to_sleep_mark_in_s = time.time()
        while True:
            time_offset_in_s = time.time() - time_to_sleep_mark_in_s
            if time_offset_in_s >= time_to_sleep_in_s:
                break

        # break

        # print("read_data_period: ", read_data_period)
        # print("taobotics: ", usb_imu_taobotics_shared_od.get(usb_imu).get("angle_degree"))

    # 关闭串口
    if usb_imu_taobotics_serial is not None:
        if usb_imu_taobotics_serial.is_open:
            usb_imu_taobotics_serial.close()
        else:
            Logger().print_info("USB IMU Taobotics ", usb_imu, " is already closed.")
    else:
        Logger().print_error("USB IMU Taobotics ", usb_imu, " is None")
        return FunctionResult.FAIL

    return FunctionResult.SUCCESS


# ---------------------------------------------------------------------------------------------------------------------


def authorize(usb_imu):
    # device authentication
    # 1. check all usb devices
    import os
    import serial

    ports = [port.device for port in serial.tools.list_ports.comports() if "USB" in port.device]

    # 2. check if the usb device exist
    if usb_imu not in ports:
        Logger().print_error("USB not found: " + usb_imu)
        Logger().print_error("Please check the connection of the USB device!")
        return FunctionResult.FAIL

    # 3. call script to setup usb(/dev/ttyUSB0) authority
    Logger().print_info("sudo chmod 777 " + usb_imu)
    try:
        os.system("sudo chmod 777 " + usb_imu)
    except Exception as e:
        Logger().print_error("USB authority setup failed: " + str(e))
        return FunctionResult.FAIL

    return FunctionResult.SUCCESS


def init(usb_imu):
    global usb_imu_taobotics_shared_od, usb_imu_taobotics_od, usb_imu_taobotics_upload_thread

    # 初始化字典 (shared_od)
    usb_imu_taobotics_shared_od.update({usb_imu: {}})

    # 准备初始化数据 (shared_od)
    usb_imu_taobotics_shared_od.get(usb_imu).update(
        {
            "angle_degree": [0, 0, 0],
            "angular_velocity": [0, 0, 0],
            "acceleration": [0, 0, 0],
            "magnetometer": [0, 0, 0],
            "key": 0,
            "buff": {},
            "pub_flag": [True, True],
            "baudrate": 921600,
            "timeout": 0.5,
        }
    )

    # 初始化字典 (od)
    usb_imu_taobotics_od.update({usb_imu: {}})

    # 准备初始化数据 (od)
    usb_imu_taobotics_od.get(usb_imu).update(
        {
            "angle_degree": [0, 0, 0],
            "angular_velocity": [0, 0, 0],
            "acceleration": [0, 0, 0],
            "magnetometer": [0, 0, 0],
        }
    )

    return FunctionResult.SUCCESS


def enable(usb_imu):
    global usb_imu_taobotics_shared_od, usb_imu_taobotics_shared_manager

    # 授权
    if authorize(usb_imu) == FunctionResult.FAIL:
        exit(FunctionResult.FAIL)

    usb_imu_taobotics_shared_od = usb_imu_taobotics_shared_manager.dict(usb_imu_taobotics_shared_od)

    # 创建子线程
    # usb_imu_taobotics_comm_thread = Thread(target=thread_usb_imu_taobotics_comm, args=(usb_imu,))
    # usb_imu_taobotics_comm_thread.start()
    # usb_imu_taobotics_shared_od.get(usb_imu).update({"thread": usb_imu_taobotics_comm_thread})
    # usb_imu_taobotics_shared_od.get(usb_imu).update({"thread_kill_flag": FlagState.CLEAR})

    # 创建子进程
    usb_imu_taobotics_comm_process = Process(
        target=process_usb_imu_taobotics_comm,
        args=(usb_imu, usb_imu_taobotics_shared_od),
    )
    usb_imu_taobotics_comm_process.start()

    print("父进程 usb_imu_taobotics_shared_od_ = ", usb_imu_taobotics_shared_od, "\n")
    value = usb_imu_taobotics_shared_od.get(usb_imu)
    # value.update({"process": usb_imu_taobotics_comm_process})  # process 不允许加入字典，用于共享内存
    value.update({"process_kill_flag": FlagState.CLEAR})
    usb_imu_taobotics_shared_od.update({usb_imu: value})  # multiprocessing.Manager 只允许从最外层的字典中更新数据

    # while True:
    #     time.sleep(1)
    #     print("父进程 usb_imu_taobotics_shared_od = ", usb_imu_taobotics_shared_od, "\n")

    return FunctionResult.SUCCESS


def disable(usb_imu):
    global usb_imu_taobotics_shared_od

    # 杀死子线程
    # usb_imu_taobotics_shared_od.get(usb_imu).update({"thread_kill_flag": FlagState.SET})
    # usb_imu_taobotics_thread = usb_imu_taobotics_shared_od.get(usb_imu).get("thread")
    # usb_imu_taobotics_thread.join()

    # 杀死子进程
    value = usb_imu_taobotics_shared_od.get(usb_imu)
    value.update({"process_kill_flag": FlagState.SET})
    usb_imu_taobotics_shared_od.update({usb_imu: value})  # multiprocessing.Manager 只允许从最外层的字典中更新数据

    return FunctionResult.SUCCESS


def upload(usb_imu):
    global usb_imu_taobotics_od

    temp_usb_imu_taobotics_shared_od_usb_imu = usb_imu_taobotics_shared_od.get(usb_imu).copy()

    usb_imu_taobotics_od.get(usb_imu).update(
        {
            "angle_degree": temp_usb_imu_taobotics_shared_od_usb_imu.get("angle_degree"),
            "angular_velocity": temp_usb_imu_taobotics_shared_od_usb_imu.get("angular_velocity"),
            "acceleration": temp_usb_imu_taobotics_shared_od_usb_imu.get("acceleration"),
            "magnetometer": temp_usb_imu_taobotics_shared_od_usb_imu.get("magnetometer"),
        }
    )

    return FunctionResult.SUCCESS


def get_key(usb_imu):
    global usb_imu_taobotics_od

    return usb_imu_taobotics_od.get(usb_imu).get("key")


def get_angle(usb_imu):
    global usb_imu_taobotics_od

    return usb_imu_taobotics_od.get(usb_imu).get("angle_degree")


def get_angular_velocity(usb_imu):
    global usb_imu_taobotics_od

    return usb_imu_taobotics_od.get(usb_imu).get("angular_velocity")


def get_acceleration(usb_imu):
    global usb_imu_taobotics_od

    return usb_imu_taobotics_od.get(usb_imu).get("acceleration")


def get_magnetometer(usb_imu):
    global usb_imu_taobotics_od

    return usb_imu_taobotics_od.get(usb_imu).get("magnetometer")


# 测试代码
if __name__ == "__main__":
    ports = [port.device for port in serial.tools.list_ports.comports() if "USB" in port.device]
    Logger().print_info("当前电脑所连接的 {} 串口设备共 {} 个: {}".format("USB", len(ports), ports))

    usb = "/dev/ttyUSB0"
    if init(usb) == FunctionResult.SUCCESS:
        enable(usb)

    # usb = '/dev/ttyUSB1'
    # if usb_imu_taobotics_init(usb) == FunctionResult.SUCCESS:
    #     usb_imu_taobotics_enable(usb)

    while True:
        time.sleep(1)
        print(usb_imu_taobotics_shared_od)

    usb = "/dev/ttyUSB0"
    usb_imu_taobotics_disable(usb)

    # usb = '/dev/ttyUSB1'
    # usb_imu_taobotics_disable(usb)
