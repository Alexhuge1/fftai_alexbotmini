from .fi_hardware_predefine import FunctionResult


def ethernet_imu_get_angle_degree(self, ip):
    return FunctionResult.SUCCESS


def ethernet_imu_get_acceleration(self, ip):
    return FunctionResult.SUCCESS


def ethernet_imu_get_angular_velocity(self, ip):
    return FunctionResult.SUCCESS


def ethernet_imu_get_magnetometer(self, ip):
    return FunctionResult.SUCCESS
