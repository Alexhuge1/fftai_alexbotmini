import numpy
from collections.abc import Iterable

from .fi_hardware_predefine import FunctionResult
from .fi_hardware_logger import Logger
from .fi_hardware_import import (
    fd_aios,
)


# -------------------------------------------------------------------------
# FSA absolute encoder related functions
def fd_aios_get_absolute_position(self, ip):
    result = fd_aios.get_absolute_position(server_ip=ip)
    return result


def fd_aios_set_absolute_zero(self, ip):
    fd_aios.set_absolute_zero(server_ip=ip)
    return FunctionResult.SUCCESS


# -------------------------------------------------------------------------

def fd_aios_init(self, ip):
    Logger().print_info(f"FD AIOS init: {ip}...")
    fd_aios.init(server_ip=ip)
    return FunctionResult.SUCCESS


def fd_aios_comm(self, ip, enable=True):
    fd_aios.comm(server_ip=ip, enable=enable)
    return FunctionResult.SUCCESS


def fd_aios_check(self, ip):
    result = fd_aios.check(server_ip=ip)
    return result


def fd_aios_subscribe(self, ip, enable=False):
    result = fd_aios.subscribe(server_ip=ip, enable=enable)
    return result


def fd_aios_get_pvc(self, ip):
    result = fd_aios.get_pvc(server_ip=ip)

    position = None
    velocity = None
    current = None
    timeout = None

    if result is not None and isinstance(result, Iterable):
        position, velocity, current, timeout = result

    return position, velocity, current, timeout


def fd_aios_get_pvct(self, ip):
    result = fd_aios.get_pvct(server_ip=ip)

    position = None
    velocity = None
    current = None
    torque = None
    timeout = None

    if result is not None and isinstance(result, Iterable):
        position, velocity, current, torque, timeout = result

    return position, velocity, current, torque, timeout


def fd_aios_get_error(self, ip):
    result = fd_aios.get_error_code(server_ip=ip)
    return FunctionResult.SUCCESS


def fd_aios_set_control_pid(
        self,
        ip,
        position_control_kp=None,
        velocity_control_kp=None,
        velocity_control_ki=None,
) -> FunctionResult:
    # support version above v1.0
    # support version above v2.0
    result = fd_aios.set_pid_param_imm(
        server_ip=ip,
        control_position_kp=position_control_kp,
        control_velocity_kp=velocity_control_kp,
        control_velocity_ki=velocity_control_ki,
    )

    return result


def fd_aios_set_control_pd(
        self,
        ip,
        pd_control_kp=None,
        pd_control_kd=None,
) -> FunctionResult:
    # support version above v1.0
    # support version above v2.0
    result = fd_aios.set_pid_param_imm(
        server_ip=ip,
        control_pd_kp=pd_control_kp,
        control_pd_kd=pd_control_kd,
    )

    return result


def fd_aios_set_control_mode(self, ip, control_mode):
    fd_aios.set_mode_of_operation(server_ip=ip,
                                  mode_of_operation=control_mode, )
    return FunctionResult.SUCCESS


def fd_aios_set_position_control(self, ip, command_position, velocity_ff=0.0, current_ff=0.0):
    fd_aios.set_position_control(server_ip=ip,
                                 position=command_position,
                                 velocity_ff=velocity_ff,
                                 current_ff=current_ff, )
    return FunctionResult.SUCCESS


def fd_aios_set_velocity_control(self, ip, command_velocity, current_ff=0.0):
    fd_aios.set_velocity_control(server_ip=ip,
                                 velocity=command_velocity,
                                 current_ff=current_ff, )
    return FunctionResult.SUCCESS


def fd_aios_set_torque_control(self, ip, command_torque):
    fd_aios.set_torque_control(server_ip=ip,
                               torque=command_torque, )
    return FunctionResult.SUCCESS


def fd_aios_set_current_control(self, ip, command_current):
    fd_aios.set_current_control(server_ip=ip,
                                current=command_current, )
    return FunctionResult.SUCCESS


def fd_aios_set_pd_control(self, ip, command_position):
    fd_aios.set_pd_control(server_ip=ip,
                           position=command_position, )
    return FunctionResult.SUCCESS


def fd_aios_set_servo_on(self, ip):
    fd_aios.set_enable(server_ip=ip)
    return FunctionResult.SUCCESS


def fd_aios_set_servo_off(self, ip):
    fd_aios.set_disable(server_ip=ip)
    return FunctionResult.SUCCESS


def fd_aios_set_servo_reboot(self, ip):
    fd_aios.reboot(server_ip=ip)
    return FunctionResult.SUCCESS


def fd_aios_set_clear_fault(self, ip):
    fd_aios.set_clear_fault(server_ip=ip)
    return FunctionResult.SUCCESS


# -------------------------------------------------------------------------

def fd_aios_set_servo_on_group(self, ips):
    result = fd_aios.enable_group(server_ips=ips)

    return FunctionResult.SUCCESS


def fd_aios_set_servo_off_group(self, ips):
    result = fd_aios.disable_group(server_ips=ips)

    return FunctionResult.SUCCESS


def fd_aios_set_servo_reboot_group(self, ips):
    for ip in ips:
        fd_aios.reboot(server_ip=ip)

    return FunctionResult.SUCCESS


def fd_aios_set_clear_fault_group(self, ips):
    result = fd_aios.clear_fault_group(server_ips=ips)

    return FunctionResult.SUCCESS


def fd_aios_get_pvc_group(self, ips):
    result = fd_aios.get_pvc_group(server_ips=ips)

    positions = None
    velocities = None
    currents = None
    timeouts = None

    if result is not None and isinstance(result, Iterable):
        positions, velocities, currents, timeouts = result

    return positions, velocities, currents, timeouts


def fd_aios_get_pvct_group(self, ips):
    result = fd_aios.get_pvct_group(server_ips=ips)

    positions = None
    velocities = None
    currents = None
    torques = None
    timeouts = None

    if result is not None and isinstance(result, Iterable):
        positions, velocities, currents, torques, timeouts = result

    return positions, velocities, currents, torques


def fd_aios_get_error_group(self, ips):
    error_codes = fd_aios.get_error_code_group(server_ips=ips)

    if error_codes is not None:
        return error_codes
    return FunctionResult.FAIL


def fd_aios_set_control_mode_group(self, ips, control_modes):
    result = fd_aios.set_mode_of_operation_group(server_ips=ips, mode_of_operations=control_modes)

    return FunctionResult.SUCCESS


def fd_aios_set_position_control_group(self, ips, command_positions):
    command_velocity_ffs = numpy.zeros_like(command_positions).tolist()
    command_current_ffs = numpy.zeros_like(command_positions).tolist()

    result = fd_aios.set_position_control_group(
        server_ips=ips,
        positions=command_positions,
        velocity_ffs=command_velocity_ffs,
        current_ffs=command_current_ffs,
    )

    positions = None
    velocities = None
    currents = None
    if result is not None:
        positions, velocities, currents = result

    return positions, velocities, currents


def fd_aios_set_velocity_control_group(self, ips, command_velocities):
    command_current_ffs = numpy.zeros_like(command_velocities).tolist()

    result = fd_aios.set_velocity_control_group(
        server_ips=ips,
        velocities=command_velocities,
        current_ffs=command_current_ffs,
    )

    positions = None
    velocities = None
    currents = None
    if result is not None:
        positions, velocities, currents = result

    return positions, velocities, currents


def fd_aios_set_torque_control_group(self, ips, command_torques):
    command_currents = command_torques

    result = fd_aios.set_torque_control_group(server_ips=ips, torques=command_currents)

    positions = None
    velocities = None
    currents = None
    if result is not None:
        positions, velocities, currents = result

    return positions, velocities, currents


def fd_aios_set_current_control_group(self, ips, command_currents):
    result = fd_aios.set_current_control_group(server_ips=ips, currents=command_currents)

    positions = None
    velocities = None
    currents = None
    if result is not None:
        positions, velocities, currents = result

    return positions, velocities, currents


def fd_aios_set_pd_control_group(self, ips, command_positions):
    result = fd_aios.set_pd_control_group(server_ips=ips, positions=command_positions)

    positions = None
    velocities = None
    currents = None
    if result is not None:
        positions, velocities, currents = result

    return positions, velocities, currents


# -------------------------------------------------------------------------

def fd_aios_set_servo_on_fast(self, ip):
    fd_aios.fast_set_enable(server_ip=ip)
    return FunctionResult.SUCCESS


def fd_aios_set_servo_off_fast(self, ip):
    fd_aios.fast_set_disable(server_ip=ip)
    return FunctionResult.SUCCESS


def fd_aios_set_clear_fault_fast(self, ip):
    fd_aios.fast_set_clear_fault(server_ip=ip)
    return FunctionResult.SUCCESS


def fd_aios_set_control_mode_fast(self, ip, control_mode):
    fd_aios.fast_set_mode_of_operation(server_ip=ip, mode_of_operation=control_mode)
    return FunctionResult.SUCCESS


def fd_aios_set_position_control_fast(self, ip, command_position, velocity_ff=0.0, current_ff=0.0):
    fd_aios.fast_set_position_control(
        server_ip=ip,
        position=command_position,
        velocity_ff=velocity_ff,
        current_ff=current_ff,
    )
    return FunctionResult.SUCCESS


def fd_aios_set_velocity_control_fast(self, ip, command_velocity, current_ff=0.0):
    fd_aios.fast_set_velocity_control(server_ip=ip, velocity=command_velocity, current_ff=current_ff)
    return FunctionResult.SUCCESS


def fd_aios_set_torque_control_fast(self, ip, command_torque):
    fd_aios.fast_set_torque_control(server_ip=ip, torque=command_torque)
    return FunctionResult.SUCCESS


def fd_aios_set_current_control_fast(self, ip, command_current):
    fd_aios.fast_set_current_control(server_ip=ip, current=command_current)
    return FunctionResult.SUCCESS


def fd_aios_set_pd_control_fast(self, ip, command_position):
    fd_aios.fast_set_pd_control(server_ip=ip, position=command_position)
    return FunctionResult.SUCCESS


def fd_aios_get_pvc_fast(self, ip):
    result = fd_aios.fast_get_pvc(server_ip=ip)

    position = None
    velocity = None
    current = None
    timeout = 0

    if result is not None and isinstance(result, Iterable):
        position, velocity, current, timeout = result
    else:
        timeout = 1

    return position, velocity, current, timeout


def fd_aios_get_pvct_fast(self, ip):
    result = fd_aios.fast_get_pvct(server_ip=ip)

    position = None
    velocity = None
    current = None
    torque = None
    timeout = 0

    if result is not None and isinstance(result, Iterable):
        position, velocity, current, torque, timeout = result
    else:
        timeout = 1

    return position, velocity, current, torque, timeout


def fd_aios_get_error_fast(self, ip):
    result = fd_aios.fast_get_error(server_ip=ip)

    error = None
    if result is not None:
        error = result

    return error


def fd_aios_set_control_pid_fast(
        self,
        ip,
        position_control_kp=None,
        velocity_control_kp=None,
        velocity_control_ki=None):
    result = fd_aios.fast_set_pid_param_imm(
        server_ip=ip,
        position_control_kp=position_control_kp,
        velocity_control_kp=velocity_control_kp,
        velocity_control_ki=velocity_control_ki,
    )
    return FunctionResult.SUCCESS


def fd_aios_set_control_pd_fast(
        self,
        ip,
        pd_control_kp=None,
        pd_control_kd=None):
    result = fd_aios.fast_set_pd_param_imm(
        server_ip=ip,
        pd_control_kp=pd_control_kp,
        pd_control_kd=pd_control_kd,
    )
    return FunctionResult.SUCCESS


# -------------------------------------------------------------------------

def fd_aios_set_servo_on_fast_group(self, ips):
    fd_aios.fast_set_enable_group(server_ips=ips)
    return FunctionResult.SUCCESS


def fd_aios_set_servo_off_fast_group(self, ips):
    fd_aios.fast_set_disable_group(server_ips=ips)
    return FunctionResult.SUCCESS


def fd_aios_set_clear_fault_fast_group(self, ips):
    fd_aios.fast_set_clear_fault_group(server_ips=ips)
    return FunctionResult.SUCCESS


def fd_aios_set_control_mode_fast_group(self, ips, control_modes):
    fd_aios.fast_set_mode_of_operation_group(server_ips=ips, mode_of_operations=control_modes)
    return FunctionResult.SUCCESS


def fd_aios_set_position_control_fast_group(self, ips, command_positions):
    fd_aios.fast_set_position_control_group(
        server_ips=ips,
        positions=command_positions,
    )
    return FunctionResult.SUCCESS


def fd_aios_set_velocity_control_fast_group(self, ips, command_velocities):
    fd_aios.fast_set_velocity_control_group(
        server_ips=ips,
        velocities=command_velocities,
    )
    return FunctionResult.SUCCESS


def fd_aios_set_torque_control_fast_group(self, ips, command_torques):
    fd_aios.fast_set_torque_control_group(server_ips=ips, torques=command_torques)
    return FunctionResult.SUCCESS


def fd_aios_set_current_control_fast_group(self, ips, command_currents):
    fd_aios.fast_set_current_control_group(server_ips=ips, currents=command_currents)
    return FunctionResult.SUCCESS


def fd_aios_set_pd_control_fast_group(self, ips, command_positions):
    fd_aios.fast_set_pd_control_group(server_ips=ips, positions=command_positions)
    return FunctionResult.SUCCESS


def fd_aios_get_pvc_fast_group(self, ips):
    result = fd_aios.fast_get_pvc_group(server_ips=ips)

    positions = [None] * len(ips)
    velocities = [None] * len(ips)
    currents = [None] * len(ips)
    timeouts = [0] * len(ips)

    if result is not None and isinstance(result, Iterable):
        positions, velocities, currents, timeouts = result
    else:
        timeouts = [1] * len(ips)

    return positions, velocities, currents, timeouts


def fd_aios_get_pvct_fast_group(self, ips):
    result = fd_aios.fast_get_pvct_group(server_ips=ips)

    positions = [None] * len(ips)
    velocities = [None] * len(ips)
    currents = [None] * len(ips)
    torques = [None] * len(ips)
    timeouts = [0] * len(ips)

    if result is not None and isinstance(result, Iterable):
        positions, velocities, currents, torques, timeouts = result
    else:
        timeouts = [1] * len(ips)

    return positions, velocities, currents, torques, timeouts


def fd_aios_get_error_fast_group(self, ips):
    result = fd_aios.fast_get_error_group(server_ips=ips)

    errors = None
    if result is not None:
        errors = result

    return errors
