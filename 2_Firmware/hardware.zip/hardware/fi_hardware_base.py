from .fi_hardware_logger import Logger
from .fi_hardware_predefine import FunctionResult


class HardwareBase:
    def __init__(self):
        pass

    def clock_init(self):
        return FunctionResult.SUCCESS

    def adc_init(self):
        return FunctionResult.SUCCESS

    def gpio_init(self):
        return FunctionResult.SUCCESS

    def gpio_write_led(self, led, status):
        return FunctionResult.SUCCESS

    def flash_init(self):
        return FunctionResult.SUCCESS

    def can_init(self):
        return FunctionResult.SUCCESS

    def ethernet_init(self):
        return FunctionResult.SUCCESS

    def spi_init(self):
        return FunctionResult.SUCCESS

    def uart_init(self):
        return FunctionResult.SUCCESS

    # -------------------------------------------------------------------------

    from .fi_hardware_usb_imu import (
        usb_imu_init,
        usb_imu_comm,
        usb_imu_check,
        usb_imu_get_quat,
        usb_imu_get_angle,
        usb_imu_get_acceleration,
        usb_imu_get_angular_velocity,
        usb_imu_get_magnetometer,
    )
