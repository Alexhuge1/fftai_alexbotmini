#include "vn/port.h"

namespace vn {
namespace xplat {

IPort::~IPort() { }

}
}
