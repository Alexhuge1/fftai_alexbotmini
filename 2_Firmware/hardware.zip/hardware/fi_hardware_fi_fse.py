from .fi_hardware_logger import Logger
from .fi_hardware_import import (
    fi_fse,
)


def fi_fse_init(self, ip):
    Logger().print_info(f"FI FSE init: {ip}...")
    return fi_fse.init(server_ip=ip)


def fi_fse_comm(self, ip, enable=True):
    return fi_fse.comm(server_ip=ip, enable=enable)


def fi_fse_check(self, ip):
    return fi_fse.check(server_ip=ip)


def fi_fse_get_measured(self, ip):
    return fi_fse.get_measured(server_ip=ip)


def fi_fse_get_angle(self, ip):
    return fi_fse.get_measured(server_ip=ip)[0]


def fi_fse_get_radian(self, ip):
    return fi_fse.get_measured(server_ip=ip)[1]
