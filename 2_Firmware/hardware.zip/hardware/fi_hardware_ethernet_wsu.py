from .fi_hardware_import import fi_sensor_ethernet


def ethernet_wsu_get_key_state(self, ip):
    result = fi_sensor_ethernet.ethernet_wsu_get_key_state(ip=ip)

    key_state = [0, 0, 0, 0]
    if result is not None:
        key_state = result

    return key_state
