from .fi_hardware_logger import Logger
from .fi_hardware_predefine import FunctionResult
from .fi_hardware_import import taobotics_imu_usb


def usb_imu_taobotics_init(self, usb):
    Logger().print_info(f"USB_IMU init: {usb}...")
    return taobotics_imu_usb.init(usb_imu=usb)


def usb_imu_taobotics_comm(self, usb, enable=True, frequency=100):
    return taobotics_imu_usb.comm(usb_imu=usb, enable=enable, frequency=frequency)


def usb_imu_taobotics_check(self, usb):
    return FunctionResult.SUCCESS


def usb_imu_taobotics_upload(self, usb):
    return taobotics_imu_usb.upload(usb_imu=usb)


def usb_imu_taobotics_get_angle(self, usb):
    return taobotics_imu_usb.get_angle(usb_imu=usb)


def usb_imu_taobotics_get_acceleration(self, usb):
    return taobotics_imu_usb.get_acceleration(usb_imu=usb)


def usb_imu_taobotics_get_angular_velocity(self, usb):
    return taobotics_imu_usb.get_angular_velocity(usb_imu=usb)
