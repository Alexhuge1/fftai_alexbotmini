from .fi_hardware_logger import Logger
from .fi_hardware_predefine import FunctionResult
from .fi_hardware_import import hipnuc_imu_usb


def usb_imu_hipnuc_init(self, usb):
    Logger().print_info(f"USB_IMU init: {usb}...")
    return hipnuc_imu_usb.init(usb_imu=usb)


def usb_imu_hipnuc_comm(self, usb, enable=True, frequency=100):
    return hipnuc_imu_usb.comm(usb_imu=usb, enable=enable, frequency=frequency)


def usb_imu_hipnuc_check(self, usb):
    return FunctionResult.SUCCESS


def usb_imu_hipnuc_upload(self, usb):
    return hipnuc_imu_usb.upload(usb_imu=usb)


def usb_imu_hipnuc_get_quat(self, usb):
    return hipnuc_imu_usb.get_quat(usb_imu=usb)


def usb_imu_hipnuc_get_angle(self, usb):
    return hipnuc_imu_usb.get_angle(usb_imu=usb)


def usb_imu_hipnuc_get_acceleration(self, usb):
    return hipnuc_imu_usb.get_acceleration(usb_imu=usb)


def usb_imu_hipnuc_get_angular_velocity(self, usb):
    return hipnuc_imu_usb.get_angular_velocity(usb_imu=usb)
