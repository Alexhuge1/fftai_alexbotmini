from collections.abc import Iterable

from .fi_hardware_logger import Logger
from .fi_hardware_predefine import FunctionResult
from .fi_hardware_import import fi_ioboard_typea


def ethernet_ioboard_fi_ioboard_typea_init(self, ip):
    Logger().print_info(f"IOBOARD init: {ip}...")
    return FunctionResult.SUCCESS


def ethernet_ioboard_fi_ioboard_typea_set_xxx(self, ip):
    return FunctionResult.SUCCESS


def ethernet_ioboard_fi_ioboard_typea_set_led(self, ip):
    result = fi_ioboard_typea.setLEDStrip(ip)

    if result is not None and isinstance(result, Iterable):
        address, led = result
        return address, led
    elif result == FunctionResult.FAIL:
        return FunctionResult.FAIL
    elif result == FunctionResult.TIMEOUT:
        return FunctionResult.TIMEOUT
    else:
        return FunctionResult.FAIL


def ethernet_ioboard_fi_ioboard_typea_get_xxx(self, ip):
    return FunctionResult.SUCCESS


def ethernet_ioboard_fi_ioboard_typea_get_info(self, ip):
    result = fi_ioboard_typea.getInfo(ip)

    if result is not None and isinstance(result, Iterable):
        (
            address,
            system_state,
            emergency_state,
            voltage_value,
            voltage_value_percent,
            robot_charging_level,
            robot_charging_state,
        ) = result

        return (
            address,
            system_state,
            emergency_state,
            voltage_value,
            voltage_value_percent,
            robot_charging_level,
            robot_charging_state,
        )

    elif result == FunctionResult.FAIL:
        return FunctionResult.FAIL

    elif result == FunctionResult.TIMEOUT:
        return FunctionResult.TIMEOUT

    else:
        return FunctionResult.FAIL
