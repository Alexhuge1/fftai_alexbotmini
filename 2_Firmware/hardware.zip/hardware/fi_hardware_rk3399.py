from .fi_hardware_connect import HardwareConnect


class HardwareRK3399(HardwareConnect):
    def __init__(self):
        super().__init__()

        # Board : NanoPi R4S
        # Wiki : https://wiki.friendlyelec.com/wiki/index.php/NanoPi_R4S#Download_Image_Files
        self.object_dictionary = {
            "number_led_wan_pin": 32,
            "number_led_lan_pin": 33,
            "number_gpio1_a7_pin": 39,
            "number_gpio1_b0_pin": 40,
            "number_gpio1_b1_pin": 41,
            "number_gpio4_c0_pin": 42,
            "number_gpio4_c1_pin": 48,
            "number_gpio4_c2_pin": 49,
            # 1 or 0
            "value_led_wan": 1,
            "value_led_lan": 1,
            "value_gpio1_a7_pin": 1,
            "value_gpio1_b0_pin": 1,
            "value_gpio1_b1_pin": 1,
            "value_gpio4_c0_pin": 1,
            "value_gpio4_c1_pin": 1,
            "value_gpio4_c2_pin": 1,
        }
