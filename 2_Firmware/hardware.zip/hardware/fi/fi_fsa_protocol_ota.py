from .fi_fsa_predefine import (
    FunctionResult,
    FSAPort,
)
from .fi_fsa_protocol_json import (
    json_protocol_send_recv,
)


# ---------------------------------------------------------------------------------------------------------------------
# FSA OTA


def ota(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_test(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota_test",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_devel(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota_devel",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_cloud(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota_cloud",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_custom(server_ip, version_str):
    data = {"method": "SET", "reqTarget": "/ota_custom", "property": version_str}

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_driver(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota_driver",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_driver_test(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota_driver_test",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_driver_devel(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota_driver_devel",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_driver_cloud(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota_driver_cloud",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_driver_custom(server_ip, version_str):
    data = {"method": "SET", "reqTarget": "/ota_driver_custom", "property": version_str}

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None

# ---------------------------------------------------------------------------------------------------------------------
