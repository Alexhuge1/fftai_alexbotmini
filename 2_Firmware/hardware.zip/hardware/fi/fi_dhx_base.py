from .fi_dhx_socket import (
    DHXSocket,
    DHXPort,
)


class Hand:
    def __init__(self, ip, ctrl_port=DHXPort.PORT_CTRL, comm_port=DHXPort.PORT_COMM, timeout=0.1):
        self.ctrl_port = ctrl_port
        self.comm_port = comm_port
        self.ip = ip
        self.s = DHXSocket(server_ip=self.ip, timeout_time=timeout)

    def send_messages(self, tx_messages, port):
        pass

    def get_messages(self, tx_messages):
        pass

    def clean_error(self):
        pass

    def save_config_flash(self):
        pass

    def reset(self):
        pass

    def calibration(self):
        pass

    def set_ip(self, ip):
        pass

    def get_ip(self):
        pass

    def set_current_limit(self, current_limit):
        pass

    def set_force_limit(self, force_limit):
        pass

    def set_speed(self, speed):
        pass

    def set_pos(self, pos):
        pass

    def set_angle(self, angle):
        pass

    def get_pos(self):
        pass

    def get_angle(self):
        pass

    def get_force(self):
        pass

    def get_current(self):
        pass

    def get_error_code(self):
        pass

    def get_status(self):
        pass

    def get_temperature(self):
        pass
