import json
import time

from .fi_fse_logger import Logger
from .fi_fse_predefine import (
    FSEPort,
)
from .fi_fse_socket import gl_fse_socket


# ---------------------------------------------------------------------------------------------------------------------
# Broadcast Query FSE in LAN


# 广播查询局域网下的全部
# 参数：无
# 返回 成功 失败 超时
def broadcast_func():
    Logger().print_debug("FSE start listening for broadcast...")

    found_server = False
    address_list = []

    gl_fse_socket.send_to(b"Is any fourier smart server here?", (gl_fse_socket.broadcast_network, FSEPort.PORT_COMM))
    print("\n")

    while True:
        try:
            data, address = gl_fse_socket.recv_from(1024)
            address_list.append(address[0])
            Logger().print_info("Received from {}:{}".format(address, data.decode("utf-8")))
            # json_obj = json.loads(data.decode("utf-8"))
            found_server = True

        except TimeoutError:  # fail after 1 second of no activity
            if found_server:
                print("\n")
                print("found servers")
                print(address_list)
                print("lookup Finished! \n")
                time.sleep(2)
                return address_list
            else:
                Logger().print_error("Do not have any server! [Timeout] \n")
                return False


# 广播查询局域网下的全部 filter_type = "Actuator" or "AbsEncoder" or "CtrlBox"
def broadcast_func_with_filter(filter_type=None):
    Logger().print_debug("FSE start listening for broadcast...")

    found_server = False
    address_list = []

    gl_fse_socket.send_to(b"Is any fourier smart server here?", (gl_fse_socket.broadcast_network, FSEPort.PORT_COMM))
    print("\n")

    while True:
        try:
            data, address = gl_fse_socket.recv_from(1024)
            Logger().print_info("Received from {}:{}".format(address, data.decode("utf-8")))

            # 如果没有过滤条件，直接返回所有的IP
            # 如果有过滤条件，只返回符合条件的IP
            if filter_type is None:
                address_list.append(address[0])
                found_server = True
                continue
            else:
                pass

            json_obj = json.loads(data.decode("utf-8"))
            if "type" in json_obj:
                if json_obj["type"] == filter_type:
                    address_list.append(address[0])
                    found_server = True

        except TimeoutError:  # fail after 1 second of no activity
            if found_server:
                print("\n")
                print("found servers")
                print(address_list)
                print("lookup Finished! \n")
                time.sleep(2)
                return address_list
            else:
                Logger().print_error("Do not have any server! [Timeout] \n")
                return False

# ---------------------------------------------------------------------------------------------------------------------
