import json

from .fi_fse_logger import Logger
from .fi_fse_model import gl_fse_group
from .fi_fse_predefine import (
    FunctionResult,
)
from .fi_fse_socket import gl_fse_socket_group


# ---------------------------------------------------------------------------------------------------------------------


def json_protocol_send_recv(server_ip: str,
                            port: int,
                            send_data: dict,
                            reply_enable=True,
                            comm_disable_response=None,
                            clear_recv_buffer=False):
    """
    Send JSON data to server_ip through port, and receive the response.
    """

    # clear receive buffer in socket if needed
    if clear_recv_buffer:
        while True:
            try:
                gl_fse_socket_group.socket_map[server_ip].json_recv_from(256)
            except:
                break

    # check if the communication is enabled
    # if not enabled, return comm_disable_response
    if not gl_fse_group.fse_map[server_ip].comm_enable:
        return comm_disable_response

    # check if the reply is enabled
    if reply_enable:
        send_data.update({"reply_enable": True})
    else:
        send_data.update({"reply_enable": False})

    # send request
    send_json = json.dumps(send_data)

    try:
        gl_fse_socket_group.socket_map[server_ip].json_send_to(
            str.encode(send_json), (server_ip, port))

        if gl_fse_socket_group.socket_map[server_ip].flag_debug is True:
            Logger().print_debug(f"{server_ip} Send JSON Obj: {send_json}")

    except Exception as e:
        Logger().print_warning(f"{server_ip} fi_fse except {e}")
        return None

    # check if the reply is enabled
    if not reply_enable:
        return None

    # receive response
    try:
        """
        Jason 2024-07-01:
        限制缓冲区大小，保证数据量足够又足够小
        """
        recv_result = gl_fse_socket_group.socket_map[server_ip].json_recv_from(512)

        if recv_result is None:
            return None

        recv_data, recv_address = recv_result
        recv_ip, recv_port = recv_address

        recv_json = json.loads(recv_data.decode("utf-8"))

        if gl_fse_socket_group.socket_map[server_ip].flag_debug is True:
            Logger().print_debug(f"{recv_ip} Recv JSON Obj: {recv_json}")

        if recv_json.get("status") == "OK":
            return recv_json
        else:
            Logger().print_warning(f"{server_ip} : function return status is not OK!")
            return None

    except TimeoutError:
        Logger().print_warning(
            f"{server_ip} fi_fse timeout"
            f"{send_data}"
        )

    except Exception as e:
        Logger().print_warning(
            f"{server_ip} fi_fse except"
            f"{e}"
            f"{send_data}"
        )

    return None


def json_protocol_group_send_recv(server_ips: list,
                                  port: int,
                                  requests: list,
                                  reply_enable=True,
                                  comm_disable_response=None):
    """
    Send JSON data to server_ips through port, and receive the response.
    """

    _server_ips = []
    _requests = []

    # check if the communication is enabled
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        request = requests[i]

        # if the communication is enabled, add the ip and request from the list
        if gl_fse_group.fse_map[server_ip].comm_enable:
            _server_ips.append(server_ip)
            _requests.append(request)

    # send request
    for i in range(len(_server_ips)):
        server_ip = _server_ips[i]
        request = _requests[i]

        # check if the reply is enabled
        if reply_enable:
            request.update({"reply_enable": True})
        else:
            request.update({"reply_enable": False})

        send_json = json.dumps(request)

        if gl_fse_socket_group.socket_map[server_ip].flag_debug is True:
            Logger().print_debug(f"{server_ip} Send JSON Obj: {send_json}")

        try:
            gl_fse_socket_group.socket_map[server_ip].json_send_to(str.encode(send_json), (server_ip, port))

        except Exception as e:
            Logger().print_warning(f"{server_ip} fi_fse except: {e}")
            continue

    # check if the reply is enabled
    if not reply_enable:
        return None

    # receive response
    # Initialize response dictionary with server IPs set to None
    response: dict = {server_ip: None for server_ip in _server_ips}

    # check if the communication is enabled
    # if not enabled, return comm_disable_response
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if not gl_fse_group.fse_map[server_ip].comm_enable:
            response.update({server_ip: comm_disable_response})

    for i in range(len(_server_ips)):
        server_ip = _server_ips[i]

        while True:
            """
            Jason 2024-09-19:
            利用循环来接收数据，直到接收到合适的数据为止
            """

            try:
                """
                Jason 2024-07-01:
                限制缓冲区大小，保证数据量足够又足够小
                """
                recv_result = gl_fse_socket_group.socket_map[server_ip].json_recv_from(512)

                if recv_result is None:
                    """
                    Jason 2024-09-19
                    如果接收到的数据为空，说明接收失败，跳出循环
                    """
                    break

                recv_data, recv_address = recv_result
                recv_ip, recv_port = recv_address

                if recv_ip in response:
                    response.update({recv_ip: {"data": recv_data}})
                else:
                    Logger().print_warning(
                        f"fi_fse receive wrong ip address "
                        f"{recv_ip, recv_port, recv_data}")

                    """
                    Jason 2024-09-19
                    如果接收到的数据的IP地址不在列表中，说明接收到错误的数据，则重新接收
                    """
                    continue

            except TimeoutError:
                Logger().print_warning(
                    f"{server_ip} fi_fse timeout")
                """
                Jason 2024-09-19
                如果接收到的数据超时，说明接收失败，跳出循环
                """
                break

            except Exception as e:
                Logger().print_warning(
                    f"{server_ip} fi_fse except: {e}")
                """
                Jason 2024-09-19
                如果接收到的数据出现异常，说明接收失败，跳出循环
                """
                break

            if gl_fse_socket_group.socket_map[server_ip].flag_debug is True:
                Logger().print_debug(f"response[{server_ip}]: {response[server_ip]}")

            break

    # check data is None
    # if data is None, set return value to FAIL
    # if data is not None, check the status of data
    # if status is OK, set return value to SUCCESS
    # if status is not OK, set return value to FAIL
    for i in range(len(_server_ips)):
        server_ip = _server_ips[i]

        response_server_ip = response.get(server_ip)

        if response_server_ip:
            recv_data = response.get(server_ip, {}).get("data")
        else:
            recv_data = None

        if recv_data is None:
            response.update({
                server_ip: {
                    "data": None,
                    "return": FunctionResult.FAIL
                }
            })
            continue

        try:
            recv_json = json.loads(recv_data.decode("utf-8"))

            if gl_fse_socket_group.socket_map[server_ip].flag_debug is True:
                Logger().print_debug(f"{server_ip} Recv JSON Obj: {recv_json}")

            if recv_json.get("status") == "OK":
                response.get(server_ip).update({"return": FunctionResult.SUCCESS})

                # copy all key-value pairs except "status" to response
                for key, value in recv_json.items():
                    if key != "status":
                        response.get(server_ip).update({key: value})

            else:
                response.get(server_ip).update({"return": FunctionResult.FAIL})
                Logger().print_warning(f"{server_ip} receive status is not OK!")
                continue

        except Exception:
            response.get(server_ip).update({"return": FunctionResult.FAIL})
            Logger().print_warning("fi_fse except")
            continue

    return response
