from .fi_fse_logger import Logger
from .fi_fse_model import (
    FSE,
    gl_fse_group,
)
from .fi_fse_predefine import (
    FunctionResult,
)
from .fi_fse_protocol_comm import (
    get_comm_root,
    set_comm_root,
    get_comm_config,
    set_comm_config,
    save_comm_config,
    reboot_comm,
)
from .fi_fse_protocol_ctrl import (
    watchdog,
    get_root,
    set_root,
    get_config,
    set_config,
    save_config,
    reboot,
    get_measured,
    get_home_offset,
    set_home_offset,
    set_home_position,
)
from .fi_fse_protocol_broadcast import (
    broadcast_func,
    broadcast_func_with_filter,
)
from .fi_fse_protocol_ota import (
    ota,
    ota_cloud,
    ota_custom,
    ota_devel,
    ota_test,
)
from .fi_fse_socket import (
    FSESocket,
    gl_fse_socket,
    gl_fse_socket_group,
)


# ---------------------------------------------------------------------------------------------------------------------


def init(server_ip):
    # create FSE object
    gl_fse_group.add_fse(server_ip=server_ip, fse=FSE(server_ip=server_ip))

    # create socket
    gl_fse_socket_group.add_socket(server_ip=server_ip, fse_socket=gl_fse_socket)

    return FunctionResult.SUCCESS


def comm(server_ip, enable=True):
    if enable is True:
        # set comm enable flag
        fse: FSE = gl_fse_group.fse_map[server_ip]
        fse.comm_enable = enable

        # set socket enable
        fse_socket: FSESocket = gl_fse_socket_group.socket_map[server_ip]
        fse_socket.start()

    return FunctionResult.SUCCESS


def check(server_ip):
    result = watchdog(server_ip=server_ip)

    return result
