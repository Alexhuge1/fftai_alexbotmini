import queue
import socket
import struct
import threading
import time
import json

from .fi_dhx_logger import Logger
from .fi_dhx_predefine import DHXPort


class SendThread:
    def __init__(self, sock: socket.socket):
        self._queue: queue.Queue[tuple[bytes, tuple[str, int]]] = queue.Queue()
        self._sock = sock
        self._is_alive = False

    def start(self):
        self._is_alive = True

    def stop(self):
        self._is_alive = False

    def is_alive(self):
        return self._is_alive

    def send(self, data: bytes, address: tuple[str, int]):
        self._sock.sendto(data, address)
        # self._queue.put((data, address))


class ReceiveThread(threading.Thread):
    def __init__(self, sock: socket.socket):
        super().__init__(name="UDPReceiveThread", daemon=False)
        self._stop_event = threading.Event()
        self._sock = sock

        self._check_frequency = False

    def stop(self):
        """Stop the thread."""
        self._stop_event.set()

    @property
    def stopped(self) -> bool:
        """Whether the thread is stopped."""
        return self._stop_event.is_set()

    def run(self):
        self._stop_event.clear()
        Logger().print_debug(f"{self.name} started.")
        # self._sock.settimeout(1. / 1000) # TODO: this need to be tested

        current_time = time.time()
        receive_count = 0

        while not self.stopped:
            try:
                data, address = self._sock.recvfrom(1024)
                self.parse(data, address)

            except TimeoutError:
                # TODO: count the number of timeouts and raise an exception if it exceeds a threshold
                # time.sleep(1 / 1000)  # FIXME: is this sleep necessary? Jason: not necessary!
                continue
            except BlockingIOError:
                time.sleep(1 / 1000)
                continue
            except Exception as exp:
                Logger().print_error(f"ReceiveThread error: {exp}")

            if self._check_frequency:
                receive_count += 1
                if time.time() - current_time >= 1:
                    Logger().print_debug("Receive frequency:", receive_count)
                    current_time = time.time()
                    receive_count = 0

        Logger().print_info(f"{self.name} stopped.")
        # self._sock.close()

    def parse(self, recv_data: bytes, recv_address):
        recv_ip, recv_port = recv_address

        if recv_port == DHXPort.PORT_FAST:
            Logger().print_debug(f"recv from {recv_ip} {recv_port} {recv_data}")

        elif recv_port == DHXPort.PORT_CTRL:
            Logger().print_debug(f"recv from {recv_ip} {recv_port} {recv_data}")

        elif recv_port == DHXPort.PORT_COMM:
            Logger().print_warning(f"Unknown message: {recv_ip} {recv_port} {recv_data}")


class DHXSocket:
    def __init__(
            self,
            server_ip="0.0.0.0",
            timeout_time=None,
            broadcast_network="192.168.137.255",
            flag_debug=False,
    ):
        self.server_ip = server_ip
        self.timeout_time = timeout_time  # unit: second
        self.broadcast_network = broadcast_network
        self.flag_debug = flag_debug
        self.loss_connection_time = None

        # init socket
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if self.timeout_time is not None:
            self.socket.settimeout(self.timeout_time)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        # 设置缓冲区大小
        """
        Jason 2024-07-01:
        必须限制缓冲区大小，否则会导致数据接收无法确保是最新的数据，一旦出现程序卡顿
        （比如出现计算耗时任务，接收数据就会堆积）
        """
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 512)

        # ------------------------------

        # 初始化 json_socket
        self.json_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if self.timeout_time is not None:
            self.json_socket.settimeout(self.timeout_time)
        self.json_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        # 设置缓冲区大小
        self.json_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 512)

        # ------------------------------

        # 初始化 byte_socket
        self.byte_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if self.timeout_time is not None:
            self.byte_socket.settimeout(self.timeout_time)
        self.byte_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        # 设置缓冲区大小
        self.byte_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 512)

        # ------------------------------

        Logger().print_debug("DHX start listening...")

    def __del__(self):
        # kill thread
        self.stop()

        # close socket
        if self.socket is not None:
            self.socket.close()

        if self.json_socket is not None:
            self.json_socket.close()

        if self.byte_socket is not None:
            self.byte_socket.close()

    def start(self):
        pass

    def stop(self):
        pass

    def send_to(self, data: bytes, address: tuple[str, int]):
        return self.socket.sendto(data, address)

    def recv_from(self, size: int) -> tuple[bytes, tuple[str, int]]:
        response = self.socket.recvfrom(size)
        return response

    def json_send_to(self, data: bytes, address: tuple[str, int]):
        self.json_socket.sendto(data, address)

    def json_recv_from(self, size: int) -> tuple[bytes, tuple[str, int]]:
        response = self.json_socket.recvfrom(size)
        return response

    def byte_send_to(self, data: bytes, address: tuple[str, int]):
        self.byte_socket.sendto(data, address)

    def byte_recv_from(self, size: int) -> tuple[bytes, tuple[str, int]]:
        response = self.byte_socket.recvfrom(size)
        return response
