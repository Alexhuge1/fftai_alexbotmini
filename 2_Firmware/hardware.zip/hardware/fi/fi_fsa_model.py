class FSA:
    def __init__(self, server_ip="192.168.137.100"):
        self.server_ip = server_ip

        self.flag_loss_connection = False
        self.flag_subscribe = False
        
        self.comm_enable = False

        self.measured_position = 0
        self.measured_velocity = 0
        self.measured_torque = 0
        self.measured_current = 0

        self.command_mode_of_operation = 0
        self.command_position = 0
        self.command_velocity = 0
        self.command_torque = 0
        self.command_current = 0

        self.status_word = 0
        self.error_code = 0


class FSAGroup:
    def __init__(self):
        self.fsa_map = {}

    def add_fsa(self, server_ip, fsa: FSA):
        self.fsa_map[server_ip] = fsa


gl_fsa_group = FSAGroup()
