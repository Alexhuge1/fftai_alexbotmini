from enum import IntEnum


class FunctionResult(IntEnum):
    SUCCESS = 0
    FAIL = -1
    RUNNING = 1
    PREPARE = 2
    EXECUTE = 3
    NOT_EXECUTE = 4
    TIMEOUT = 5


class FlagState(IntEnum):
    CLEAR = 0
    SET = 1


class FSEPort:
    PORT_CTRL = 2333
    PORT_COMM = 2334
    PORT_FAST = 2335
