class FSE:
    def __init__(self, server_ip="192.168.137.100"):
        self.server_ip = server_ip

        self.flag_loss_connection = False
        self.flag_subscribe = False

        self.comm_enable = False

        self.measured_angle = 0
        self.measured_radian = 0

        self.status_word = 0
        self.error_code = 0


class FSEGroup:
    def __init__(self):
        self.fse_map = {}

    def add_fse(self, server_ip, fse: FSE):
        self.fse_map[server_ip] = fse


gl_fse_group = FSEGroup()
