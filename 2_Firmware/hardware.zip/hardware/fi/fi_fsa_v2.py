from .fi_fsa_logger import Logger
from .fi_fsa_model import (
    FSA,
    gl_fsa_group,
)
from .fi_fsa_predefine import (
    FunctionResult,
)
from .fi_fsa_protocol_comm import (
    get_root as comm_get_root,
    get_config as comm_get_config,
    set_config as comm_set_config,
    save_config as comm_save_config,
    erase_config as comm_erase_config,
    reboot,
    reboot_group,
)
from .fi_fsa_protocol_ctrl import (
    get_root,
    get_config,
    set_config,
    save_config,
    erase_config,
    reboot as ctrl_reboot,

    # Double encoder functions
    get_absolute_position,
    set_absolute_zero,

    # Single encoder functions
    get_pvc,
    get_pvct,
    get_error_code,
    set_control_word,
    set_enable,
    set_disable,
    set_zero,
    set_calibrate_encoder,
    set_clear_fault,
    set_pid_param_imm,
    get_control_param_imm,
    set_control_param_imm,
    set_mode_of_operation,
    set_position_control,
    set_velocity_control,
    set_torque_control,
    set_current_control,
    set_pd_control,

    set_enable_group,
    set_disable_group,
    set_calibrate_encoder_group,
    set_clear_fault_group,
    get_pvc_group,
    get_pvct_group,
    get_error_code_group,
    set_mode_of_operation_group,
    set_position_control_group,
    set_velocity_control_group,
    set_torque_control_group,
    set_current_control_group,
    set_pd_control_group,
)
from .fi_fsa_protocol_fast import (
    fast_get_pvc,
    fast_get_pvc_group,
    fast_get_pvct,
    fast_get_pvct_group,
    fast_get_error,
    fast_get_error_group,

    fast_set_clear_fault,
    fast_set_clear_fault_group,
    fast_set_disable,
    fast_set_disable_group,
    fast_set_enable,
    fast_set_enable_group,
    fast_set_mode_of_operation,
    fast_set_mode_of_operation_group,
    fast_set_position_control,
    fast_set_position_control_group,
    fast_set_velocity_control,
    fast_set_velocity_control_group,
    fast_set_torque_control,
    fast_set_torque_control_group,
    fast_set_current_control,
    fast_set_current_control_group,
    fast_set_pd_control,
    fast_set_pd_control_group,
    fast_watchdog,
    fast_set_pid_param_imm,
    fast_set_pid_param_imm_group,
    fast_set_pd_param_imm,
    fast_set_pd_param_imm_group,
)
from .fi_fsa_protocol_broadcast import (
    broadcast_func,
    broadcast_func_with_filter,
)
from .fi_fsa_protocol_ota import (
    ota,
    ota_cloud,
    ota_custom,
    ota_devel,
    ota_driver,
    ota_driver_cloud,
    ota_driver_custom,
    ota_driver_devel,
    ota_driver_test,
    ota_test,
)
from .fi_fsa_socket import (
    FSASocket,
    gl_fsa_socket,
    gl_fsa_socket_group,
)


# ---------------------------------------------------------------------------------------------------------------------


def init(server_ip):
    # create FSA object
    gl_fsa_group.add_fsa(server_ip=server_ip, fsa=FSA(server_ip=server_ip))

    # create socket
    gl_fsa_socket_group.add_socket(server_ip=server_ip, fsa_socket=gl_fsa_socket)

    return FunctionResult.SUCCESS


def comm(server_ip, enable=True):
    if enable is True:
        # set comm enable flag
        fsa: FSA = gl_fsa_group.fsa_map[server_ip]
        fsa.comm_enable = enable

        # set socket enable
        fsa_socket: FSASocket = gl_fsa_socket_group.socket_map[server_ip]
        fsa_socket.start()

    return FunctionResult.SUCCESS


def check(server_ip):
    result = fast_watchdog(server_ip=server_ip)

    return result


def subscribe(server_ip, enable=False):
    return FunctionResult.SUCCESS
