from .fi_fse_predefine import (
    FSEPort,
)
from .fi_fse_protocol_json import (
    json_protocol_send_recv,
)


# ---------------------------------------------------------------------------------------------------------------------
# Control Parameters of FSE
def watchdog(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_CTRL, data, reply_enable=True)

    return data


def get_root(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_CTRL, data, reply_enable=True)

    return data


def set_root(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_CTRL, data, reply_enable=True)

    return data


def get_config(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/config",
        "property": ""
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_CTRL, data, reply_enable=True)

    return data


def set_config(server_ip, dict=None):
    data = {
        "method": "SET",
        "reqTarget": "/config",
    }

    if dict is not None:
        data["home_offset"] = dict["home_offset"]

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_CTRL, data, reply_enable=True)

    return data


def save_config(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/config",
        "property": "save"
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_CTRL, data, reply_enable=True)

    return data


def reboot(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/reboot",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_CTRL, data, reply_enable=True)

    return data


def get_measured(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/measured",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        angle = data.get("angle")
        radian = data.get("radian")
        timeout = False
    else:
        angle = None
        radian = None
        timeout = True

    return angle, radian, timeout


def get_home_offset(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/home_offset",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        home_offset = data.get("home_offset")
        timeout = False
    else:
        home_offset = None
        timeout = True

    return home_offset, timeout


# fse reset linear count
# Parameters: including server ip，motor number
# no return code
def set_home_offset(server_ip, home_offset):
    data = {
        "method": "SET",
        "reqTarget": "/home_offset",
    }

    if home_offset is not None:
        data["home_offset"] = home_offset

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_CTRL, data, reply_enable=True)

    return data


def set_home_position(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/home_position",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_CTRL, data, reply_enable=True)

    return data
