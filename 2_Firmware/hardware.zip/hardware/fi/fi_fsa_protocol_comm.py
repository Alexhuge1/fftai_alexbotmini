from .fi_fsa_predefine import (
    FunctionResult,
    FSAPort,
)
from .fi_fsa_protocol_json import (
    json_protocol_send_recv,
    json_protocol_group_send_recv,
)


# ---------------------------------------------------------------------------------------------------------------------
def set_subscribe(server_ip, port, enable):
    data = {
        "method": "SET",
        "reqTarget": "/subscribe",
        "port": port,
        "enable": enable,
        "position": True,
        "velocity": True,
        "current": True,
        "torque": True,
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


# ---------------------------------------------------------------------------------------------------------------------
# Communication Parameters of FSA


# fsa Get root attributes
# Parameters: including device IP
# Get all basic attributes of fsa, including serial number, bus voltage, motor temperature, inverter temperature, version number
def get_root(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=True)

    return data


# fsa Get Root Config property
# Parameters: including device IP
# Get fsa bus voltage over-voltage and under-voltage protection threshold
def get_config(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/config",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=True)

    if data is not None:
        if data.get("status") == "OK":
            return FunctionResult.SUCCESS
        else:
            return None
    else:
        return None


# fsa set Root Config properties
# Parameter: The protection threshold of bus voltage overvoltage and undervoltage
# Return success or failure
def set_config(server_ip, dict):
    data = {
        "method": "SET",
        "reqTarget": "/config",
        "name": dict.get("name"),
        "DHCP_enable": dict.get("DHCP_enable"),
        "SSID": dict.get("SSID"),
        "password": dict.get("password"),
        "static_IP": dict.get("static_IP"),
        "gateway": dict.get("gateway"),
        "subnet_mask": dict.get("subnet_mask"),
        "dns_1": dict.get("dns_1"),
        "dns_2": dict.get("dns_2"),
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=True)

    if data is not None:
        if data.get("status") == "OK":
            return FunctionResult.SUCCESS
        else:
            return None
    else:
        return None


# fsa save configuration
# Parameters: including device IP
def save_config(server_ip):
    data = {"method": "SET", "reqTarget": "/config", "property": "save"}

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=True)

    if data is not None:
        if data.get("status") == "OK":
            return FunctionResult.SUCCESS
        else:
            return None
    else:
        return None


def erase_config(server_ip):
    data = {"method": "SET", "reqTarget": "/config", "property": "erase"}

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=True)

    if data is not None:
        if data.get("status") == "OK":
            return FunctionResult.SUCCESS
        else:
            return None
    else:
        return None


# fsa restart
# Parameters: including device IP
def reboot(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/reboot",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_COMM, data, reply_enable=True)

    if data is not None:
        if data.get("status") == "OK":
            return FunctionResult.SUCCESS
        else:
            return None
    else:
        return None


# ---------------------------------------------------------------------------------------------------------------------
# Communication Parameters of FSA Group


# fsa restart
# Parameters: including device IP
def reboot_group(server_ips):
    # request
    request = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        data = {
            "method": "SET",
            "reqTarget": "/reboot",
        }

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_COMM, request, reply_enable=True)

    # response
    func_result = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        func_result.append(response.get(server_ip).get("return"))

    return func_result
