try:
    from fourier_core.predefine import FunctionResult
except ImportError:

    class FunctionResult:
        SUCCESS = 0
        FAIL = -1
        RUNNING = 1
        PREPARE = 2
        EXECUTE = 3
        NOT_EXECUTE = 4
        TIMEOUT = 5


class DHXPort:
    PORT_CTRL = 2333
    PORT_COMM = 2334
    PORT_FAST = 2335
