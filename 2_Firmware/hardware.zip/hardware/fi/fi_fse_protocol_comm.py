from .fi_fse_predefine import (
    FSEPort,
)
from .fi_fse_protocol_json import (
    json_protocol_send_recv,
)


# ---------------------------------------------------------------------------------------------------------------------
# Communication Parameters of FSE


def get_comm_root(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_COMM, data, reply_enable=True)

    return data


def set_comm_root(server_ip, dict):
    data = {
        "method": "SET",
        "reqTarget": "/",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_COMM, data, reply_enable=True)

    return data


def get_comm_config(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/config",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_COMM, data, reply_enable=True)

    return data


def set_comm_config(server_ip, dict):
    data = {
        "method": "SET",
        "reqTarget": "/config",
        "property": "",
        "name": dict.get("name"),
        "DHCP_enable": dict.get("DHCP_enable"),
        "SSID": dict.get("SSID"),
        "password": dict.get("password"),
        "static_IP": dict.get("static_IP"),
        "gateway": dict.get("gateway"),
        "subnet_mask": dict.get("subnet_mask"),
        "dns_1": dict.get("dns_1"),
        "dns_2": dict.get("dns_2"),
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_COMM, data, reply_enable=True)

    return data


def save_comm_config(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/config",
        "property": "save"
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_COMM, data, reply_enable=True)

    return data


def reboot_comm(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/reboot",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_COMM, data, reply_enable=True)

    return data
