from .fi_fse_predefine import (
    FunctionResult,
    FSEPort,
)
from .fi_fse_protocol_json import (
    json_protocol_send_recv,
)


# ---------------------------------------------------------------------------------------------------------------------
# FSE OTA


def ota(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_test(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota_test",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_devel(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota_devel",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_cloud(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/ota_cloud",
    }

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def ota_custom(server_ip, version_str):
    data = {"method": "SET", "reqTarget": "/ota_custom", "property": version_str}

    data = json_protocol_send_recv(server_ip, FSEPort.PORT_COMM, data, reply_enable=False)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None

# ---------------------------------------------------------------------------------------------------------------------
