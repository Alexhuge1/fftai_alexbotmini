from .fi_fsa_logger import Logger
from .fi_fsa_predefine import (
    FunctionResult,
    FSAPort,
    FSAControlWord,
    FSAErrorCode,
)
from .fi_fsa_protocol_json import (
    json_protocol_send_recv,
    json_protocol_group_send_recv,
)


# ---------------------------------------------------------------------------------------------------------------------
# FSA absolute encoder related functions
def get_absolute_position(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/get_abs_position",
        # "reqTarget": "/absolute_position",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        absolute_position = data.get("absolute_position")
    else:
        absolute_position = None

    return absolute_position


# log
def set_absolute_zero(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/set_abs_zero",
        # "reqTarget": "/absolute_zero",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


# ---------------------------------------------------------------------------------------------------------------------
# Control Parameters of FSA


# fsa Get root attributes
# Parameters: including device IP
# Get all basic attributes of fsa, including serial number, bus voltage, motor temperature, inverter temperature, version number
def get_root(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    return data


# fsa Get Root Config property
# Parameters: including device IP
# Get fsa bus voltage over-voltage and under-voltage protection threshold
def get_config(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/config",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        actuator_type = data.get("actuator_type")
        actuator_comm_hardware_type = data.get("actuator_comm_hardware_type")
        actuator_direction = data.get("actuator_direction")
        actuator_reduction_ratio = data.get("actuator_reduction_ratio")

        motor_type = data.get("motor_type")
        motor_hardware_type = data.get("motor_hardware_type")
        motor_vbus = data.get("motor_vbus")
        motor_direction = data.get("motor_direction")
        motor_max_speed = data.get("motor_max_speed")
        motor_max_acceleration = data.get("motor_max_acceleration")
        motor_max_current = data.get("motor_max_current")

    else:
        actuator_type = None
        actuator_comm_hardware_type = None
        actuator_direction = None
        actuator_reduction_ratio = None

        motor_type = None
        motor_hardware_type = None
        motor_vbus = None
        motor_direction = None
        motor_max_speed = None
        motor_max_acceleration = None
        motor_max_current = None

    return (
        actuator_type,
        actuator_comm_hardware_type,
        actuator_direction,
        actuator_reduction_ratio,
        motor_type,
        motor_hardware_type,
        motor_vbus,
        motor_direction,
        motor_max_speed,
        motor_max_acceleration,
        motor_max_current,
    )


# fsa set Root Config properties
# Parameter: The protection threshold of bus voltage overvoltage and undervoltage
# Return success or failure
def set_config(
        server_ip,
        actuator_type=None,
        actuator_comm_hardware_type=None,
        actuator_direction=None,
        actuator_reduction_ratio=None,
        motor_type=None,
        motor_hardware_type=None,
        motor_vbus=None,
        motor_direction=None,
        motor_max_speed=None,
        motor_max_acceleration=None,
        motor_max_current=None,
):
    data = {
        "method": "SET",
        "reqTarget": "/config",
    }

    if actuator_type is not None:
        data["actuator_type"] = actuator_type

    if actuator_comm_hardware_type is not None:
        data["actuator_comm_hardware_type"] = actuator_comm_hardware_type

    if actuator_direction is not None:
        data["actuator_direction"] = actuator_direction

    if actuator_reduction_ratio is not None:
        data["actuator_reduction_ratio"] = actuator_reduction_ratio

    if motor_type is not None:
        data["motor_type"] = motor_type

    if motor_hardware_type is not None:
        data["motor_hardware_type"] = motor_hardware_type

    if motor_vbus is not None:
        data["motor_vbus"] = motor_vbus

    if motor_direction is not None:
        data["motor_direction"] = motor_direction

    if motor_max_speed is not None:
        data["motor_max_speed"] = motor_max_speed

    if motor_max_acceleration is not None:
        data["motor_max_acceleration"] = motor_max_acceleration

    if motor_max_current is not None:
        data["motor_max_current"] = motor_max_current

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


# fsa save configuration
# Parameters: including device IP
def save_config(server_ip):
    data = {"method": "SET", "reqTarget": "/config", "property": "save"}

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


# fsa clear configuration
# Parameters: including device IP
def erase_config(server_ip):
    data = {"method": "SET", "reqTarget": "/config", "property": "erase"}

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


# fsa restart the motor drive
# Parameters: including device IP
def reboot(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/reboot",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def set_control_word(server_ip, control_word=None):
    data = {
        "method": "SET",
        "reqTarget": "/control_word",
    }

    if control_word is not None:
        data["control_word"] = control_word

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    return data


# fsa enable
# Parameters: including device IP and motor number
# Each fsa can control two motors, M0 and M1
def set_enable(server_ip):
    return set_control_word(server_ip, FSAControlWord.SERVO_ON)


# fsa Disable
# Parameters: including device IP and motor number
# Each fsa can control two motors, M0 and M1
def set_disable(server_ip):
    return set_control_word(server_ip, FSAControlWord.SERVO_OFF)


# fsa Set Relative Encoder Zero
def set_zero(server_ip):
    """
    Not implemented
    """
    return FunctionResult.SUCCESS


# fsa Clear Fault
# Parameters: including device IP and motor number
# Clear Fault
def set_clear_fault(server_ip):
    return set_control_word(server_ip, FSAControlWord.CLEAR_FAULT)


# fsa Calibrate Encoder
# Parameters: including device IP and motor number
# Auto rotate clockwise once ,then change direction turn around
def set_calibrate_encoder(server_ip):
    return set_control_word(server_ip, FSAControlWord.CALIBRATE_ENCODER)


# fsa Get current status
# Parameters: including device IP
# Get fsa Get current status
def get_state(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/state",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        state = data.get("state")
    else:
        state = None

    return state


# fsa set control mode
# Parameters: including server ip，motor number
# no return code
def set_mode_of_operation(server_ip, mode_of_operation=None):
    data = {
        "method": "SET",
        "reqTarget": "/mode_of_operation",
    }

    if mode_of_operation is not None:
        data["mode_of_operation"] = mode_of_operation

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


# fsa Get Root Config property
# Parameters: including device IP
# Get fsa bus voltage over-voltage and under-voltage protection threshold
def get_pid_param(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/pid_param",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        control_position_kp = data.get("control_position_kp")
        control_velocity_kp = data.get("control_velocity_kp")
        control_velocity_ki = data.get("control_velocity_ki")
    else:
        control_position_kp = None
        control_velocity_kp = None
        control_velocity_ki = None

    return (
        control_position_kp,
        control_velocity_kp,
        control_velocity_ki,
    )


# fsa set Root Config properties
# Parameter: The protection threshold of bus voltage overvoltage and undervoltage
# Return success or failure
def set_pid_param(
        server_ip,
        control_position_kp=None,
        control_velocity_kp=None,
        control_velocity_ki=None,
        **kwargs,
):
    data = {
        "method": "SET",
        "reqTarget": "/pid_param",
    }

    if control_position_kp is not None:
        data["control_position_kp"] = control_position_kp

    if control_velocity_kp is not None:
        data["control_velocity_kp"] = control_velocity_kp

    if control_velocity_ki is not None:
        data["control_velocity_ki"] = control_velocity_ki

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=False)

    return FunctionResult.SUCCESS


def clear_pid_param(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/pid_param",
        "property": "clear",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return FunctionResult.FAIL


# fsa Get Root Config property
# Parameters: including device IP
# Get fsa bus voltage over-voltage and under-voltage protection threshold
def get_pid_param_imm(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/pid_param_imm",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        control_position_kp = data.get("control_position_kp_imm")
        control_velocity_kp = data.get("control_velocity_kp_imm")
        control_velocity_ki = data.get("control_velocity_ki_imm")
    else:
        control_position_kp = None
        control_velocity_kp = None
        control_velocity_ki = None

    return (
        control_position_kp,
        control_velocity_kp,
        control_velocity_ki,
    )


# fsa set Root Config properties
# Parameter: The protection threshold of bus voltage overvoltage and undervoltage
# Return success or failure
def set_pid_param_imm(
        server_ip,
        control_position_kp=None,
        control_velocity_kp=None,
        control_velocity_ki=None,
        control_pd_kp=None,
        control_pd_kd=None,
        **kwargs,
) -> FunctionResult:
    data = {
        "method": "SET",
        "reqTarget": "/pid_param_imm",
    }

    if control_position_kp is not None:
        data["control_position_kp_imm"] = control_position_kp

    if control_velocity_kp is not None:
        data["control_velocity_kp_imm"] = control_velocity_kp

    if control_velocity_ki is not None:
        data["control_velocity_ki_imm"] = control_velocity_ki

    if control_pd_kp is not None:
        data["control_pd_kp_imm"] = control_pd_kp

    if control_pd_kd is not None:
        data["control_pd_kd_imm"] = control_pd_kd

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=False)

    return FunctionResult.SUCCESS


# fsa get Control Config properties
# Parameters: including device IP
# Get fsa bus voltage over-voltage and under-voltage protection threshold
def get_control_param(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/control_param",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        motor_max_speed = data.get("motor_max_speed")
        motor_max_acceleration = data.get("motor_max_acceleration")
        motor_max_current = data.get("motor_max_current")
    else:
        motor_max_speed = None
        motor_max_acceleration = None
        motor_max_current = None

    return motor_max_speed, motor_max_acceleration, motor_max_current


# fsa get Control Config properties
# Parameters: including device IP
# Get fsa bus voltage over-voltage and under-voltage protection threshold
def get_control_param_imm(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/control_param_imm",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        motor_max_speed = data.get("motor_max_speed_imm")
        motor_max_acceleration = data.get("motor_max_acceleration_imm")
        motor_max_current = data.get("motor_max_current_imm")
    else:
        motor_max_speed = None
        motor_max_acceleration = None
        motor_max_current = None

    return motor_max_speed, motor_max_acceleration, motor_max_current


# fsa set Control Config properties
# Parameter: Set Motor Max Speed ,acceleration and current
# Return success or failure
def set_control_param(server_ip,
                      motor_max_speed=None,
                      motor_max_acceleration=None,
                      motor_max_current=None):
    data = {
        "method": "SET",
        "reqTarget": "/control_param",
    }

    if motor_max_speed is not None:
        data["motor_max_speed"] = motor_max_speed

    if motor_max_acceleration is not None:
        data["motor_max_acceleration"] = motor_max_acceleration

    if motor_max_current is not None:
        data["motor_max_current"] = motor_max_current

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


# fsa set Control Config properties
# Parameter: Set Motor Max Speed ,acceleration and current
# Return success or failure
def set_control_param_imm(server_ip,
                          motor_max_speed=None,
                          motor_max_acceleration=None,
                          motor_max_current=None):
    data = {
        "method": "SET",
        "reqTarget": "/control_param_imm",
    }

    if motor_max_speed is not None:
        data["motor_max_speed_imm"] = motor_max_speed

    if motor_max_acceleration is not None:
        data["motor_max_acceleration_imm"] = motor_max_acceleration

    if motor_max_current is not None:
        data["motor_max_current_imm"] = motor_max_current

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def get_flag_of_operation(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/flag_of_operation",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        flag_do_use_store_actuator_param = data.get("flag_do_use_store_actuator_param")
        flag_do_use_store_motor_param = data.get("flag_do_use_store_motor_param")
        flag_do_use_store_encoder_param = data.get("flag_do_use_store_encoder_param")
        flag_do_use_store_pid_param = data.get("flag_do_use_store_pid_param")
    else:
        flag_do_use_store_actuator_param = None
        flag_do_use_store_motor_param = None
        flag_do_use_store_encoder_param = None
        flag_do_use_store_pid_param = None

    return (
        flag_do_use_store_actuator_param,
        flag_do_use_store_motor_param,
        flag_do_use_store_encoder_param,
        flag_do_use_store_pid_param,
    )


def set_flag_of_operation(
        server_ip,
        flag_do_use_store_actuator_param=None,
        flag_do_use_store_motor_param=None,
        flag_do_use_store_encoder_param=None,
        flag_do_use_store_pid_param=None,
):
    data = {
        "method": "SET",
        "reqTarget": "/flag_of_operation",
    }

    if flag_do_use_store_actuator_param is not None:
        data["flag_do_use_store_actuator_param"] = flag_do_use_store_actuator_param

    if flag_do_use_store_motor_param is not None:
        data["flag_do_use_store_motor_param"] = flag_do_use_store_motor_param

    if flag_do_use_store_encoder_param is not None:
        data["flag_do_use_store_encoder_param"] = flag_do_use_store_encoder_param

    if flag_do_use_store_pid_param is not None:
        data["flag_do_use_store_pid_param"] = flag_do_use_store_pid_param

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


def clear_flag_of_operation(server_ip):
    data = {
        "method": "SET",
        "reqTarget": "/flag_of_operation",
        "property": "clear",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        return FunctionResult.SUCCESS
    else:
        return None


# fsa Get error code
# Parameters: including server IP
def get_error_code(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/error_code",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        temp = data.get("error_code")
        count = 0
        for i in FSAErrorCode:
            temp_error_code = (temp << 1 >> count) & 0x01
            if temp_error_code == 1:
                Logger().print_debug("Now Error Type = ", i.name)
            count = count + 1
        return data.get("error_code")
    else:
        return None


# fsa Get actuator position, velocity, current
# Parameters: including server ip，motor number
# Return position, speed, current in tuple
def get_pvc(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/measured",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        position = data.get("position")
        velocity = data.get("velocity")
        current = data.get("current")
        timeout = False
    else:
        position = None
        velocity = None
        current = None
        timeout = True

    return position, velocity, current, timeout


# fsa Get actuator position, velocity, current, torque
# Parameters: including server ip，motor number
# Return position, speed, current in tuple
def get_pvct(server_ip):
    data = {
        "method": "GET",
        "reqTarget": "/measured",
    }

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=True)

    if data is not None:
        position = data.get("position")
        velocity = data.get("velocity")
        current = data.get("current")
        torque = data.get("torque")
        timeout = False
    else:
        position = None
        velocity = None
        current = None
        torque = None
        timeout = True

    return position, velocity, current, torque, timeout


# fsa position control
# parameter: server IP["xxx.xxx.xxx.xxx"], position[deg], velocity feedforward[deg/s], current feedforward[A]
# return position, velocity, current
def set_position_control(server_ip, position=None, velocity_ff=None, current_ff=None, reply_enable=True):
    data = {
        "method": "SET",
        "reqTarget": "/position_control",
    }

    if position is not None:
        data["position"] = position

    if velocity_ff is not None:
        data["velocity_ff"] = velocity_ff

    if current_ff is not None:
        data["current_ff"] = current_ff

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=reply_enable)

    if data is not None:
        position = data.get("position")
        velocity = data.get("velocity")
        current = data.get("current")
        torque = data.get("torque")
    else:
        position = None
        velocity = None
        current = None
        torque = None

    return position, velocity, current, torque


# fsa velocity control
# parameter: server IP["xxx.xxx.xxx.xxx"], velocity[deg/s], current feedforward[A]
# return position, velocity, current
def set_velocity_control(server_ip, velocity=None, current_ff=None, reply_enable=True):
    data = {
        "method": "SET",
        "reqTarget": "/velocity_control",
    }

    if velocity is not None:
        data["velocity"] = velocity

    if current_ff is not None:
        data["current_ff"] = current_ff

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=reply_enable)

    if data is not None:
        position = data.get("position")
        velocity = data.get("velocity")
        current = data.get("current")
        torque = data.get("torque")
    else:
        position = None
        velocity = None
        current = None
        torque = None

    return position, velocity, current, torque


def set_torque_control(server_ip, torque=None, reply_enable=True):
    data = {
        "method": "SET",
        "reqTarget": "/torque_control",
    }

    if torque is not None:
        data["torque"] = torque

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=reply_enable)

    if data is not None:
        position = data.get("position")
        velocity = data.get("velocity")
        current = data.get("current")
        torque = data.get("torque")
    else:
        position = None
        velocity = None
        current = None
        torque = None

    return position, velocity, current, torque


# fsa current control
# parameter: server IP["xxx.xxx.xxx.xxx"], current[A]
# return position, velocity, current
def set_current_control(server_ip, current=None, reply_enable=True):
    data = {
        "method": "SET",
        "reqTarget": "/current_control",
    }

    if current is not None:
        data["current"] = current

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=reply_enable)

    if data is not None:
        position = data.get("position")
        velocity = data.get("velocity")
        current = data.get("current")
        torque = data.get("torque")
    else:
        position = None
        velocity = None
        current = None
        torque = None

    return position, velocity, current, torque


def set_pd_control(server_ip, position=None, velocity=None, reply_enable=True):
    data = {
        "method": "SET",
        "reqTarget": "/pd_control",
    }

    if position is not None:
        data["position"] = position

    if velocity is not None:
        data["velocity"] = velocity

    data = json_protocol_send_recv(server_ip, FSAPort.PORT_CTRL, data, reply_enable=reply_enable)

    if data is not None:
        position = data.get("position")
        velocity = data.get("velocity")
        current = data.get("current")
        torque = data.get("torque")
    else:
        position = None
        velocity = None
        current = None
        torque = None

    return position, velocity, current, torque


# ---------------------------------------------------------------------------------------------------------------------
# Control Parameters of FSA Group


def set_control_word_group(server_ips, control_words=None):
    # request
    request = []
    for i in range(len(server_ips)):
        data = {
            "method": "SET",
            "reqTarget": "/control_word",
        }

        if control_words is not None:
            data["control_word"] = control_words[i]

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_CTRL, request, reply_enable=True)

    # response
    func_result = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        func_result.append(response.get(server_ip).get("return"))

    return func_result


def set_enable_group(server_ips):
    func_result = set_control_word_group(server_ips, [FSAControlWord.SERVO_ON] * len(server_ips))
    return func_result


def set_disable_group(server_ips):
    func_result = set_control_word_group(server_ips, [FSAControlWord.SERVO_OFF] * len(server_ips))
    return func_result


def set_clear_fault_group(server_ips):
    func_result = set_control_word_group(server_ips, [FSAControlWord.CLEAR_FAULT] * len(server_ips))
    return func_result


def set_calibrate_encoder_group(server_ips):
    func_result = set_control_word_group(server_ips, [FSAControlWord.CALIBRATE_ENCODER] * len(server_ips))
    return func_result


def get_state_group(server_ips):
    # request
    request = []
    for i in range(len(server_ips)):
        data = {
            "method": "GET",
            "reqTarget": "/state",
        }

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_CTRL, request, reply_enable=True)

    # response
    func_result = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        func_result.append(response.get(server_ip).get("return"))

    return func_result


def get_error_code_group(server_ips):
    # request
    request = []
    for i in range(len(server_ips)):
        data = {
            "method": "GET",
            "reqTarget": "/error_code",
        }

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_CTRL, request, reply_enable=True)

    # response
    error_codes = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        error_codes.append(response.get(server_ip).get("error_code"))

    Logger().print_debug("error_code=", error_codes)

    return error_codes


def get_pvc_group(server_ips):
    # request
    request = []
    for i in range(len(server_ips)):
        data = {
            "method": "GET",
            "reqTarget": "/measured",
        }

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_CTRL, request, reply_enable=True)

    # receive response
    positions = [0] * len(server_ips)
    velocities = [0] * len(server_ips)
    currents = [0] * len(server_ips)
    timeouts = [0] * len(server_ips)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if response.get(server_ip).get("data") is None:
            timeouts[i] = 1

        positions[i] = response.get(server_ip).get("position")
        velocities[i] = response.get(server_ip).get("velocity")
        currents[i] = response.get(server_ip).get("current")

    return positions, velocities, currents, timeouts


def get_pvct_group(server_ips):
    # request
    request = []
    for i in range(len(server_ips)):
        data = {
            "method": "GET",
            "reqTarget": "/measured",
        }

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_CTRL, request, reply_enable=True)

    # receive response
    positions = [0] * len(server_ips)
    velocities = [0] * len(server_ips)
    currents = [0] * len(server_ips)
    torques = [0] * len(server_ips)
    timeouts = [0] * len(server_ips)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if response.get(server_ip).get("data") is None:
            timeouts[i] = 1

        positions[i] = response.get(server_ip).get("position")
        velocities[i] = response.get(server_ip).get("velocity")
        currents[i] = response.get(server_ip).get("current")
        torques[i] = response.get(server_ip).get("torque")

    return positions, velocities, currents, torques, timeouts


def set_mode_of_operation_group(server_ips, mode_of_operations=None):
    # request
    request = []
    for i in range(len(server_ips)):
        data = {
            "method": "SET",
            "reqTarget": "/mode_of_operation",
        }

        if mode_of_operations is not None:
            data["mode_of_operation"] = mode_of_operations[i]

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_CTRL, request, reply_enable=True)

    # response
    func_result = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        func_result.append(response.get(server_ip).get("return"))

    return func_result


# ---------------------------------------------------------------------------------------------------------------------


# fsa position control
# parameter: server IP["xxx.xxx.xxx.xxx"], position[deg], velocity feedforward[deg/s], current feedforward[A]
# return position, velocity, current
def set_position_control_group(server_ips, positions=None, velocity_ffs=None, current_ffs=None, reply_enable=True):
    # request
    request = []
    for i in range(len(server_ips)):
        data = {
            "method": "SET",
            "reqTarget": "/position_control",
        }

        if positions is not None:
            data["position"] = positions[i]

        if velocity_ffs is not None:
            data["velocity_ff"] = velocity_ffs[i]

        if current_ffs is not None:
            data["current_ff"] = current_ffs[i]

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_CTRL, request, reply_enable=reply_enable)

    # response
    positions = [0] * len(server_ips)
    velocities = [0] * len(server_ips)
    currents = [0] * len(server_ips)
    torques = [0] * len(server_ips)
    timeouts = [0] * len(server_ips)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if response.get(server_ip).get("data", None) is None:
            timeouts[i] = 1

        positions[i] = response.get(server_ip).get("position", None)
        velocities[i] = response.get(server_ip).get("velocity", None)
        currents[i] = response.get(server_ip).get("current", None)
        torques[i] = response.get(server_ip).get("torque", None)

    return positions, velocities, currents, torques, timeouts


def set_velocity_control_group(server_ips, velocities=None, current_ffs=None, reply_enable=True):
    # request
    request = []
    for i in range(len(server_ips)):
        data = {
            "method": "SET",
            "reqTarget": "/velocity_control",
        }

        if velocities is not None:
            data["velocity"] = velocities[i]

        if current_ffs is not None:
            data["current_ff"] = current_ffs[i]

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_CTRL, request, reply_enable=reply_enable)

    # response
    positions = [0] * len(server_ips)
    velocities = [0] * len(server_ips)
    currents = [0] * len(server_ips)
    torques = [0] * len(server_ips)
    timeouts = [0] * len(server_ips)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if response.get(server_ip).get("data", None) is None:
            timeouts[i] = 1

        positions[i] = response.get(server_ip).get("position", None)
        velocities[i] = response.get(server_ip).get("velocity", None)
        currents[i] = response.get(server_ip).get("current", None)
        torques[i] = response.get(server_ip).get("torque", None)

    return positions, velocities, currents, torques, timeouts


def set_torque_control_group(server_ips, torques=None, reply_enable=True):
    # request
    request = []
    for i in range(len(server_ips)):
        data = {
            "method": "SET",
            "reqTarget": "/torque_control",
        }

        if torques is not None:
            data["torque"] = torques[i]

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_CTRL, request, reply_enable=reply_enable)

    # response
    positions = [0] * len(server_ips)
    velocities = [0] * len(server_ips)
    currents = [0] * len(server_ips)
    torques = [0] * len(server_ips)
    timeouts = [0] * len(server_ips)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if response.get(server_ip).get("data", None) is None:
            timeouts[i] = 1

        positions[i] = response.get(server_ip).get("position", None)
        velocities[i] = response.get(server_ip).get("velocity", None)
        currents[i] = response.get(server_ip).get("current", None)
        torques[i] = response.get(server_ip).get("torque", None)

    return positions, velocities, currents, torques, timeouts


def set_current_control_group(server_ips, currents=None, reply_enable=True):
    # request
    request = []
    for i in range(len(server_ips)):
        data = {
            "method": "SET",
            "reqTarget": "/current_control",
        }

        if currents is not None:
            data["current"] = currents[i]

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_CTRL, request, reply_enable=reply_enable)

    # response
    positions = [0] * len(server_ips)
    velocities = [0] * len(server_ips)
    currents = [0] * len(server_ips)
    torques = [0] * len(server_ips)
    timeouts = [0] * len(server_ips)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if response.get(server_ip).get("data", None) is None:
            timeouts[i] = 1

        positions[i] = response.get(server_ip).get("position", None)
        velocities[i] = response.get(server_ip).get("velocity", None)
        currents[i] = response.get(server_ip).get("current", None)
        torques[i] = response.get(server_ip).get("torque", None)

    return positions, velocities, currents, torques, timeouts


def set_pd_control_group(server_ips, positions=None, velocities=None, reply_enable=True):
    # request
    request = []
    for i in range(len(server_ips)):
        data = {
            "method": "SET",
            "reqTarget": "/pd_control",
        }

        if positions is not None:
            data["position"] = positions[i]

        if velocities is not None:
            data["velocity"] = velocities[i]

        request.append(data)

    # request -> response
    response = json_protocol_group_send_recv(server_ips, FSAPort.PORT_CTRL, request, reply_enable=reply_enable)

    # response
    positions = [0] * len(server_ips)
    velocities = [0] * len(server_ips)
    currents = [0] * len(server_ips)
    torques = [0] * len(server_ips)
    timeouts = [0] * len(server_ips)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if response.get(server_ip).get("data", None) is None:
            timeouts[i] = 1

        positions[i] = response.get(server_ip).get("position", None)
        velocities[i] = response.get(server_ip).get("velocity", None)
        currents[i] = response.get(server_ip).get("current", None)
        torques[i] = response.get(server_ip).get("torque", None)

    return positions, velocities, currents, torques, timeouts
