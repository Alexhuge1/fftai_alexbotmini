from collections.abc import Iterable

from .fi_fsa_logger import Logger
from .fi_fsa_model import (
    FSA,
    gl_fsa_group,
)
from .fi_fsa_predefine import (
    FunctionResult,
)
from .fi_fsa_protocol_broadcast import (
    broadcast_func,
    broadcast_func_with_filter,
)
from .fi_fsa_protocol_comm import (
    get_root as comm_get_root,
    get_config as comm_get_config,
    set_config as comm_set_config,
    save_config as comm_save_config,
    erase_config as comm_erase_config,
    reboot,
    reboot_group,
)
from .fi_fsa_protocol_ctrl import (
    get_root,
    get_config,
    set_config,
    save_config,
    erase_config,
    reboot as ctrl_reboot,

    # Double encoder functions
    # ...

    # Single encoder functions
    get_pvc,
    get_error_code,
    set_control_word,
    set_enable,
    set_disable,
    set_zero,
    set_calibrate_encoder,
    set_clear_fault,
    set_pid_param_imm,
    get_control_param_imm,
    set_control_param_imm,
    set_mode_of_operation,
    set_position_control,
    set_velocity_control,
    set_current_control,

    set_enable_group,
    set_disable_group,
    set_calibrate_encoder_group,
    set_clear_fault_group,
    get_pvc_group,
    get_error_code_group,
    set_mode_of_operation_group,
    set_position_control_group,
    set_velocity_control_group,
    set_current_control_group,
)
from .fi_fsa_protocol_ota import (
    ota,
    ota_cloud,
    ota_custom,
    ota_devel,
    ota_driver,
    ota_driver_cloud,
    ota_driver_custom,
    ota_driver_devel,
    ota_driver_test,
    ota_test,
)
from .fi_fsa_socket import (
    FSASocket,
    gl_fsa_socket,
    gl_fsa_socket_group,
)


# ---------------------------------------------------------------------------------------------------------------------


def get_pvct(server_ip):
    result = get_pvc(server_ip=server_ip)

    if isinstance(result, Iterable):
        position, velocity, current, timeout = result
        torque = current

        return position, velocity, current, torque, timeout
    else:
        return result


def get_pvct_group(server_ips):
    result = get_pvc_group(server_ips=server_ips)

    if isinstance(result, Iterable):
        positions, velocities, currents, timeouts = result
        torques = currents

        return positions, velocities, currents, torques, timeouts
    else:
        return result


# ---------------------------------------------------------------------------------------------------------------------


def init(server_ip):
    # create FSA object
    gl_fsa_group.add_fsa(server_ip=server_ip, fsa=FSA(server_ip=server_ip))

    # create socket
    gl_fsa_socket_group.add_socket(server_ip=server_ip, fsa_socket=gl_fsa_socket)

    return FunctionResult.SUCCESS


def comm(server_ip, enable=True):
    if enable is True:
        # set comm enable flag
        fsa: FSA = gl_fsa_group.fsa_map[server_ip]
        fsa.comm_enable = enable

        # set socket enable
        fsa_socket: FSASocket = gl_fsa_socket_group.socket_map[server_ip]
        fsa_socket.start()

    return FunctionResult.SUCCESS


def check(server_ip):
    position, velocity, current, timeout = get_pvc(server_ip)

    if timeout:
        return FunctionResult.FAIL
    else:
        return FunctionResult.SUCCESS


def subscribe(server_ip, enable=False):
    return FunctionResult.SUCCESS
