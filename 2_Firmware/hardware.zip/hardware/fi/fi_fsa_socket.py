import queue
import socket
import struct
import threading
import time

from .fi_fsa_logger import Logger
from .fi_fsa_model import gl_fsa_group
from .fi_fsa_predefine import FSAPort
from .fi_fsa_predefine_fast import FSAFastCommandWord


class SocketTimeout:
    DEFAULT_TIMEOUT = 0.02  # 20ms, 50Hz
    DEFAULT_JSON_PORT_TIMEOUT = 0.02  # 20ms, 50Hz
    DEFAULT_BYTE_PORT_TIMEOUT = 0.01  # 10ms, 100Hz
    DEFAULT_SUBS_PORT_TIMEOUT = 0.01  # 10ms, 100Hz


class SendThread:
    def __init__(self, sock: socket.socket):
        self._queue: queue.Queue[tuple[bytes, tuple[str, int]]] = queue.Queue()
        self._sock = sock
        self._is_alive = False

    def start(self):
        self._is_alive = True

    def stop(self):
        self._is_alive = False

    def is_alive(self):
        return self._is_alive

    def send(self, data: bytes, address: tuple[str, int]):
        self._sock.sendto(data, address)
        # self._queue.put((data, address))


class ReceiveThread(threading.Thread):
    def __init__(self, sock: socket.socket):
        super().__init__(name="UDPReceiveThread", daemon=False)
        self._stop_event = threading.Event()
        self._sock = sock

        self._check_frequency = False

    def stop(self):
        """Stop the thread."""
        self._stop_event.set()

    @property
    def stopped(self) -> bool:
        """Whether the thread is stopped."""
        return self._stop_event.is_set()

    def run(self):
        self._stop_event.clear()
        Logger().print_debug(f"{self.name} started.")
        # self._sock.settimeout(1. / 1000) # TODO: this need to be tested

        current_time = time.time()
        receive_count = 0

        while not self.stopped:
            try:
                data, address = self._sock.recvfrom(1024)
                self.parse(data, address)

            except TimeoutError:
                # TODO: count the number of timeouts and raise an exception if it exceeds a threshold
                # time.sleep(1 / 1000)  # FIXME: is this sleep necessary? Jason: not necessary!
                continue
            except BlockingIOError:
                time.sleep(1 / 1000)
                continue
            except Exception as exp:
                Logger().print_error(f"ReceiveThread error: {exp}")

            if self._check_frequency:
                receive_count += 1
                if time.time() - current_time >= 1:
                    Logger().print_debug("Receive frequency:", receive_count)
                    current_time = time.time()
                    receive_count = 0

        Logger().print_info(f"{self.name} stopped.")
        # self._sock.close()

    def parse(self, recv_data: bytes, recv_address):
        recv_ip, recv_port = recv_address

        if recv_port == FSAPort.PORT_FAST:
            (recv_command_word,) = struct.unpack(">B", recv_data[0:1])

            if recv_command_word == FSAFastCommandWord.GET_PVC:
                (
                    position,
                    velocity,
                    current,
                ) = struct.unpack(">fff", recv_data[1: 1 + 4 + 4 + 4])

                gl_fsa_group.fsa_map[recv_ip].measured_position = position
                gl_fsa_group.fsa_map[recv_ip].measured_velocity = velocity
                gl_fsa_group.fsa_map[recv_ip].measured_current = current

            elif recv_command_word == FSAFastCommandWord.GET_PVCT:
                (
                    position,
                    velocity,
                    current,
                    torque,
                ) = struct.unpack(">ffff", recv_data[1: 1 + 4 + 4 + 4 + 4])

                gl_fsa_group.fsa_map[recv_ip].measured_position = position
                gl_fsa_group.fsa_map[recv_ip].measured_velocity = velocity
                gl_fsa_group.fsa_map[recv_ip].measured_current = current
                gl_fsa_group.fsa_map[recv_ip].measured_torque = torque

            elif recv_command_word == FSAFastCommandWord.GET_ERROR:
                (error_code,) = struct.unpack(">i", recv_data[1: 1 + 4])
                gl_fsa_group.fsa_map[recv_ip].error_code = error_code

        elif recv_port == FSAPort.PORT_CTRL:
            Logger().print_debug(f"recv from {recv_ip} {recv_port} {recv_data}")

        elif recv_port == FSAPort.PORT_COMM:
            Logger().print_debug(f"recv from {recv_ip} {recv_port} {recv_data}")

        elif recv_port == FSAPort.PORT_SUBS:
            (position_index, position_value,
             velocity_index, velocity_value,
             current_index, current_value,
             torque_index, torque_value) = \
                struct.unpack(">BfBfBfBf", recv_data[0: 1 + 4 + 1 + 4 + 1 + 4 + 1 + 4])

            gl_fsa_group.fsa_map[recv_ip].measured_position = position_value
            gl_fsa_group.fsa_map[recv_ip].measured_velocity = velocity_value
            gl_fsa_group.fsa_map[recv_ip].measured_current = current_value
            gl_fsa_group.fsa_map[recv_ip].measured_torque = torque_value

        else:
            Logger().print_warning(f"Unknown message: {recv_ip} {recv_port} {recv_data}")


class FSASocket:
    def __init__(
            self,
            server_ip="0.0.0.0",
            timeout_time=None,
            broadcast_network="192.168.137.255",
            flag_debug=False,
    ):
        self.server_ip = server_ip
        self.timeout_time = timeout_time
        self.broadcast_network = broadcast_network
        self.flag_debug = flag_debug
        self.loss_connection_time = None

        # ------------------------------

        # 初始化 socket
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if self.timeout_time is not None:
            self.socket.settimeout(max(self.timeout_time, SocketTimeout.DEFAULT_TIMEOUT))
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        # 设置缓冲区大小
        """
        Jason 2024-07-01:
        必须限制缓冲区大小，否则会导致数据接收无法确保是最新的数据，一旦出现程序卡顿
        （比如出现计算耗时任务，接收数据就会堆积）
        """
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 1024)

        # ------------------------------

        # 初始化 json_socket
        self.json_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if self.timeout_time is not None:
            self.json_socket.settimeout(max(self.timeout_time, SocketTimeout.DEFAULT_JSON_PORT_TIMEOUT))
        self.json_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        # 设置缓冲区大小
        self.json_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 1024)

        # ------------------------------

        # 初始化 byte_socket
        self.byte_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if self.timeout_time is not None:
            self.byte_socket.settimeout(max(self.timeout_time, SocketTimeout.DEFAULT_BYTE_PORT_TIMEOUT))
        self.byte_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        # 设置缓冲区大小
        self.byte_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 512)

        # ------------------------------

        # 初始化 subscribe_socket
        self.subscribe_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if self.timeout_time is not None:
            self.subscribe_socket.settimeout(max(self.timeout_time, SocketTimeout.DEFAULT_SUBS_PORT_TIMEOUT))
        self.subscribe_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        # 设置缓冲区大小
        self.subscribe_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 512)

        # 获取端口
        self.subscribe_port = self.subscribe_socket.getsockname()[1]

        self.subscribe_recv_thread = ReceiveThread(sock=self.subscribe_socket)

        # ------------------------------

        Logger().print_debug("FSASocket start listening...")

    def __del__(self):
        # kill thread
        self.stop()

        # close socket
        if self.socket is not None:
            self.socket.close()

        if self.json_socket is not None:
            self.json_socket.close()

        if self.byte_socket is not None:
            self.byte_socket.close()

        if self.subscribe_socket is not None:
            self.subscribe_socket.close()

    def start(self):
        if not self.subscribe_recv_thread.is_alive():
            self.subscribe_recv_thread.start()

    def stop(self):
        if self.subscribe_recv_thread.is_alive():
            self.subscribe_recv_thread.stop()

    def send_to(self, data: bytes, address: tuple[str, int]):
        self.socket.sendto(data, address)

    def recv_from(self, size: int) -> tuple[bytes, tuple[str, int]]:
        response = self.socket.recvfrom(size)
        return response

    def json_send_to(self, data: bytes, address: tuple[str, int]):
        self.json_socket.sendto(data, address)

    def json_recv_from(self, size: int) -> tuple[bytes, tuple[str, int]]:
        response = self.json_socket.recvfrom(size)
        return response

    def byte_send_to(self, data: bytes, address: tuple[str, int]):
        self.byte_socket.sendto(data, address)

    def byte_recv_from(self, size: int) -> tuple[bytes, tuple[str, int]]:
        response = self.byte_socket.recvfrom(size)
        return response


class FSASocketGroup:
    def __init__(self):
        self.socket_map = {}

    def add_socket(self, server_ip, fsa_socket):
        self.socket_map[server_ip] = fsa_socket


# Singleton Object
gl_fsa_socket = FSASocket(timeout_time=0.01)
gl_fsa_socket_group = FSASocketGroup()
