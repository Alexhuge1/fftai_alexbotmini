from .fi_fse_logger import Logger
from .fi_fse_model import gl_fse_group
from .fi_fse_socket import gl_fse_socket_group


# ---------------------------------------------------------------------------------------------------------------------


def fast_protocol_send_recv(server_ip: str,
                            port: int,
                            send_messages: bytes,
                            reply_enable=True,
                            comm_disable_response=None,
                            clear_recv_buffer=False):
    """
    Send BYTE data to server_ip through port, and receive the response.
    """

    # clear receive buffer in socket if needed
    if clear_recv_buffer:
        while True:
            try:
                gl_fse_socket_group.socket_map[server_ip].byte_recv_from(256)
            except:
                break

    # check if the communication is enabled
    # if not enabled, directly return success
    if not gl_fse_group.fse_map[server_ip].comm_enable:
        return comm_disable_response

    try:
        gl_fse_socket_group.socket_map[server_ip].byte_send_to(send_messages, (server_ip, port))

        if gl_fse_socket_group.socket_map[server_ip].flag_debug is True:
            Logger().print_debug(f"{server_ip} : Send Message: {send_messages}")

    except Exception as e:
        Logger().print_warning(f"{server_ip} fi_fse exception: {e}")
        return None

    if not reply_enable:
        return None

    try:
        # Jason 2024-07-01:
        # 限制缓冲区大小，保证数据量足够又足够小
        recv_result = gl_fse_socket_group.socket_map[server_ip].byte_recv_from(256)

        if recv_result is None:
            return None

        recv_message, recv_address = recv_result
        recv_ip, recv_port = recv_address

        if gl_fse_socket_group.socket_map[server_ip].flag_debug is True:
            Logger().print_debug(f"{server_ip} : Recv Message: {recv_message}")

        return recv_message

    except TimeoutError:
        Logger().print_warning(
            f"{server_ip} fi_fse timeout. "
            f"{send_messages}")

    except Exception as e:
        Logger().print_warning(
            f"{server_ip} fi_fse except: {e}")

    return None


def fast_protocol_group_send_recv(server_ips: list,
                                  port: int,
                                  requests: list,
                                  reply_enable=True,
                                  comm_disable_response=None):
    """
    Send BYTE data to server_ips through port, and receive the response.
    """

    _server_ips = []
    _requests = []

    # check if the communication is enabled
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        request = requests[i]

        # if the communication is enabled, add the ip and request from the list
        if gl_fse_group.fse_map[server_ip].comm_enable:
            _server_ips.append(server_ip)
            _requests.append(request)

    # Request: Iterate over the list of server IPs and their corresponding requests
    for i in range(len(_server_ips)):
        server_ip = _server_ips[i]
        request = _requests[i]

        send_message = request

        # Check if debugging is enabled for the server IP
        if gl_fse_socket_group.socket_map[server_ip].flag_debug is True:
            Logger().print_debug(f"{server_ip} : Send Message: {send_message}")

        try:
            # Send the message to the server
            gl_fse_socket_group.socket_map[server_ip].byte_send_to(send_message, (server_ip, port))

        except Exception as e:
            # Log a warning message if an exception occurs
            Logger().print_warning(
                f"{server_ip} fi_fse sendto exception: {e}")
            continue

    if not reply_enable:
        return None

    # Response
    # Initialize response dictionary with server IPs set to None
    response: dict = {server_ip: None for server_ip in _server_ips}

    # check if the communication is enabled
    # if not enabled, return comm_disable_response
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if not gl_fse_group.fse_map[server_ip].comm_enable:
            response.update({server_ip: comm_disable_response})

    for i in range(len(_server_ips)):
        server_ip = _server_ips[i]

        try:
            """
            Jason 2024-07-01:
            限制缓冲区大小，保证数据量足够又足够小
            """
            recv_result = gl_fse_socket_group.socket_map[server_ip].byte_recv_from(256)

            if recv_result is None:
                continue

            recv_message, recv_address = recv_result
            recv_ip, recv_port = recv_address

            if recv_ip in response:
                response.update({recv_ip: recv_message})
            else:
                Logger().print_warning(
                    f"fi_fse receive wrong IP address "
                    f"{(recv_ip, recv_port, recv_message)}")

        except TimeoutError:
            Logger().print_warning(
                f"{server_ip} fi_fse timeout")
            continue

        except Exception as e:
            Logger().print_warning(
                f"{server_ip} fi_fse except: {e}")
            continue

        if gl_fse_socket_group.socket_map[server_ip].flag_debug:
            Logger().print_debug(f"response[{server_ip}]: {response[server_ip]}")

    return response

# ---------------------------------------------------------------------------------------------------------------------
