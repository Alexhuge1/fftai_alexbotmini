import struct

from .fi_fsa_predefine import (
    FunctionResult,
    FSAPort,
    FSAModeOfOperation,
)
from .fi_fsa_predefine_fast import (
    FSAFastCommandWord,
)
from .fi_fsa_protocol_byte import (
    fast_protocol_send_recv,
    fast_protocol_group_send_recv,
)


# ---------------------------------------------------------------------------------------------------------------------


# AIOS get pvc through pt port
# 参数：包括设备IP
# 无返回
def fast_watchdog(server_ip, version="v2"):
    # TODO: change to use command word 0xFF
    if version == "v1":
        # for v1 use 0x1A as watchdog
        send_messages = struct.pack(">B", FSAFastCommandWord.GET_PVC)
    else:
        send_messages = struct.pack(">B", FSAFastCommandWord.WATCH_DOG)

    recv_messages = fast_protocol_send_recv(server_ip,
                                            FSAPort.PORT_FAST,
                                            send_messages,
                                            reply_enable=True,
                                            comm_disable_response=send_messages,
                                            clear_recv_buffer=True)

    if recv_messages is not None:
        feedback = struct.unpack(">B", recv_messages[0: 1])
        return FunctionResult.SUCCESS
    else:
        return FunctionResult.FAIL


def fast_set_enable(server_ip):
    send_messages = struct.pack(">B", FSAFastCommandWord.SET_ENABLE)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_disable(server_ip):
    send_messages = struct.pack(">B", FSAFastCommandWord.SET_DISABLE)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_clear_fault(server_ip):
    send_messages = struct.pack(">B", FSAFastCommandWord.SET_CLEAR_FAULT)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_position_mode(server_ip):
    send_messages = struct.pack(">B", FSAFastCommandWord.SET_POSITION_MODE)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_velocity_mode(server_ip):
    send_messages = struct.pack(">B", FSAFastCommandWord.SET_VELOCITY_MODE)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_torque_mode(server_ip):
    send_messages = struct.pack(">B", FSAFastCommandWord.SET_TORQUE_MODE)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_current_mode(server_ip):
    send_messages = struct.pack(">B", FSAFastCommandWord.SET_CURRENT_MODE)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_pd_mode(server_ip):
    send_messages = struct.pack(">B", FSAFastCommandWord.SET_PD_MODE)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_mode_of_operation(server_ip, mode_of_operation):
    if mode_of_operation == FSAModeOfOperation.POSITION_CONTROL:
        return fast_set_position_mode(server_ip)
    elif mode_of_operation == FSAModeOfOperation.VELOCITY_CONTROL:
        return fast_set_velocity_mode(server_ip)
    elif mode_of_operation == FSAModeOfOperation.TORQUE_CONTROL:
        return fast_set_torque_mode(server_ip)
    elif mode_of_operation == FSAModeOfOperation.CURRENT_CONTROL:
        return fast_set_current_mode(server_ip)
    elif mode_of_operation == FSAModeOfOperation.PD_CONTROL:
        return fast_set_pd_mode(server_ip)
    else:
        return None


def fast_set_position_control(server_ip, position, velocity_ff=0, current_ff=0):
    send_messages = struct.pack(">Bfff", FSAFastCommandWord.SET_POSITION_CONTROL, position, velocity_ff, current_ff)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_velocity_control(server_ip, velocity, current_ff=0):
    send_messages = struct.pack(">Bff", FSAFastCommandWord.SET_VELOCITY_CONTROL, velocity, current_ff)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_torque_control(server_ip, torque):
    send_messages = struct.pack(">Bf", FSAFastCommandWord.SET_TORQUE_CONTROL, torque)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_current_control(server_ip, current):
    send_messages = struct.pack(">Bf", FSAFastCommandWord.SET_CURRENT_CONTROL, current)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_pd_control(server_ip, position):
    send_messages = struct.pack(">Bf", FSAFastCommandWord.SET_PD_CONTROL, position)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


# AIOS get pvc through pt port
# 参数：包括设备IP
# 无返回
def fast_get_pvc(server_ip):
    send_messages = struct.pack(">B", FSAFastCommandWord.GET_PVC)

    feedback = None
    position = None
    velocity = None
    current = None
    timeout = 0

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=True)

    if recv_messages is not None:
        feedback, position, velocity, current = \
            struct.unpack(">Bfff", recv_messages[0: 1 + 4 + 4 + 4])
    else:
        timeout = 1

    return position, velocity, current, timeout


# AIOS get pvc through pt port
# 参数：包括设备IP
# 无返回
def fast_get_pvct(server_ip):
    send_messages = struct.pack(">B", FSAFastCommandWord.GET_PVCT)

    feedback = None
    position = None
    velocity = None
    current = None
    torque = None
    timeout = 0

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=True)

    if recv_messages is not None:
        feedback, position, velocity, current, torque = \
            struct.unpack(">Bffff", recv_messages[0: 1 + 4 + 4 + 4 + 4])
    else:
        timeout = 1

    return position, velocity, current, torque, timeout


def fast_get_error(server_ip):
    send_messages = struct.pack(">B", FSAFastCommandWord.GET_ERROR)

    error = 0

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=True)

    if recv_messages is not None:
        feedback, error = struct.unpack(">Bi", recv_messages[0: 1 + 4])

    return error


def fast_set_pid_param_imm(server_ip, position_control_kp, velocity_control_kp, velocity_control_ki):
    send_messages = struct.pack(">Bfff", FSAFastCommandWord.SET_PID_PARAM_IMM,
                                position_control_kp, velocity_control_kp, velocity_control_ki)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_pd_param_imm(server_ip, pd_control_kp, pd_control_kd):
    send_messages = struct.pack(">Bff", FSAFastCommandWord.SET_PD_PARAM_IMM,
                                pd_control_kp, pd_control_kd)

    recv_messages = fast_protocol_send_recv(server_ip, FSAPort.PORT_FAST, send_messages, reply_enable=False)

    return FunctionResult.SUCCESS


# ---------------------------------------------------------------------------------------------------------------------
# FSA FAST Group


def fast_set_enable_group(server_ips):
    # requests
    requests = []
    for i in range(len(server_ips)):
        data = struct.pack(">B", FSAFastCommandWord.SET_ENABLE)

        requests.append(data)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_disable_group(server_ips):
    # requests
    requests = []
    for i in range(len(server_ips)):
        data = struct.pack(">B", FSAFastCommandWord.SET_DISABLE)

        requests.append(data)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_clear_fault_group(server_ips):
    # requests
    requests = []
    for i in range(len(server_ips)):
        data = struct.pack(">B", FSAFastCommandWord.SET_CLEAR_FAULT)

        requests.append(data)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_mode_of_operation_group(server_ips, mode_of_operations):
    # requests
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        mode_of_operation = mode_of_operations[i]

        fast_set_mode_of_operation(server_ip=server_ip, mode_of_operation=mode_of_operation)

    return FunctionResult.SUCCESS


def fast_set_position_control_group(server_ips, positions, velocity_ffs=None, current_ffs=None):
    # requests
    requests = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        position = positions[i]
        velocity_ff = velocity_ffs[i] if velocity_ffs is not None else 0
        current_ff = current_ffs[i] if current_ffs is not None else 0

        data = struct.pack(">Bfff", FSAFastCommandWord.SET_POSITION_CONTROL, position, velocity_ff, current_ff)

        requests.append(data)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_velocity_control_group(server_ips, velocities, current_ffs=None):
    # requests
    requests = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        velocity = velocities[i]
        current_ff = current_ffs[i] if current_ffs is not None else 0

        data = struct.pack(">Bff", FSAFastCommandWord.SET_VELOCITY_CONTROL, velocity, current_ff)

        requests.append(data)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_torque_control_group(server_ips, torques):
    # requests
    requests = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        torque = torques[i]

        data = struct.pack(">Bf", FSAFastCommandWord.SET_TORQUE_CONTROL, torque)

        requests.append(data)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_current_control_group(server_ips, currents):
    # requests
    requests = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        current = currents[i]

        data = struct.pack(">Bf", FSAFastCommandWord.SET_CURRENT_CONTROL, current)

        requests.append(data)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_pd_control_group(server_ips, positions):
    # requests
    requests = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        position = positions[i]

        data = struct.pack(">Bf", FSAFastCommandWord.SET_PD_CONTROL, position)

        requests.append(data)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=False)

    return FunctionResult.SUCCESS


# Jason 2024-01-27:
# Time Cost: 0.5 ~ 0.8ms
def fast_get_pvc_group(server_ips):
    # requests
    requests = []
    for i in range(len(server_ips)):
        data = struct.pack(">B", FSAFastCommandWord.GET_PVC)

        requests.append(data)

    # response
    feedbacks = [None] * len(server_ips)
    positions = [None] * len(server_ips)
    velocities = [None] * len(server_ips)
    currents = [None] * len(server_ips)
    timeouts = [0] * len(server_ips)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=True)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if response.get(server_ip) is None:
            timeouts[i] = 1
            continue

        feedback, position, velocity, current = struct.unpack(">Bfff", response.get(server_ip)[0: 1 + 4 + 4 + 4])

        feedbacks[i] = feedback
        positions[i] = position
        velocities[i] = velocity
        currents[i] = current

    return positions, velocities, currents, timeouts


def fast_get_pvct_group(server_ips):
    # requests
    requests = []
    for i in range(len(server_ips)):
        data = struct.pack(">B", FSAFastCommandWord.GET_PVCT)

        requests.append(data)

    # response
    feedbacks = [None] * len(server_ips)
    positions = [None] * len(server_ips)
    velocities = [None] * len(server_ips)
    currents = [None] * len(server_ips)
    torques = [None] * len(server_ips)
    timeouts = [0] * len(server_ips)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=True)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if response.get(server_ip) is None:
            timeouts[i] = 1
            continue

        feedback, position, velocity, current, torque = struct.unpack(
            ">Bffff", response.get(server_ip)[0: 1 + 4 + 4 + 4 + 4]
        )

        feedbacks[i] = feedback
        positions[i] = position
        velocities[i] = velocity
        currents[i] = current
        torques[i] = torque

    return positions, velocities, currents, torques, timeouts


# Jason 2024-01-27:
# Time Cost: 0.5 ~ 0.8ms
def fast_get_error_group(server_ips):
    # requests
    requests = []
    for i in range(len(server_ips)):
        data = struct.pack(">B", FSAFastCommandWord.GET_ERROR)

        requests.append(data)

    # response
    feedbacks = [None] * len(server_ips)
    errors = [0] * len(server_ips)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=True)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        if response.get(server_ip) is None:
            continue

        feedback, error = struct.unpack(">Bi", response.get(server_ip)[0: 1 + 4])

        feedbacks[i] = feedback
        errors[i] = error

    return errors


def fast_set_pid_param_imm_group(server_ips, position_control_kps, velocity_control_kps, velocity_control_kis):
    # requests
    requests = []
    for i in range(len(server_ips)):
        data = struct.pack(">Bfff", FSAFastCommandWord.SET_PID_PARAM_IMM,
                           position_control_kps[i], velocity_control_kps[i], velocity_control_kis[i])

        requests.append(data)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=False)

    return FunctionResult.SUCCESS


def fast_set_pd_param_imm_group(server_ips, pd_control_kps, pd_control_kds):
    # requests
    requests = []
    for i in range(len(server_ips)):
        data = struct.pack(">Bff", FSAFastCommandWord.SET_PD_PARAM_IMM,
                           pd_control_kps[i], pd_control_kds[i])

        requests.append(data)

    # requests -> response
    response = fast_protocol_group_send_recv(server_ips, FSAPort.PORT_FAST, requests, reply_enable=False)

    return FunctionResult.SUCCESS
