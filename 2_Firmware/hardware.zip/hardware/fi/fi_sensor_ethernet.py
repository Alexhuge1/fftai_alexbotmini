import json
import socket

from fourier_core.logger import Logger
from fourier_core.predefine import (
    FunctionResult,
)

s_sensor_ethernet = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


# udp 客户端不需要绑定端口和ip，因为不需要主动接收数据，而是主动发送请求数据
# s_sensor_ethernet_server_address = ("0.0.0.0", 11111)
# s_sensor_ethernet.bind(s_sensor_ethernet_server_address)


def ethernet_wsu_get_key_state(ip):
    # wsu configure
    port = 11111

    data = {"ethernet_wsu": {"key_state": ""}}
    json_str = json.dumps(data)
    Logger().print_info("FI Ethernet", "send JSON:", json_str)
    s_sensor_ethernet.sendto(str.encode(json_str), (ip, port))

    try:
        data, address = s_sensor_ethernet.recvfrom(1024)
        Logger().print_info("FI Ethernet", "received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
    except TimeoutError:  # fail after 1 second of no activity
        Logger().print_info("FI Ethernet", "didn't receive anymore data! [Timeout]")
        return FunctionResult.FAIL

    key_state = json_obj.get("key_state")

    if key_state is not None:
        return key_state
    else:
        Logger().print_info("FI Ethernet", "receive data error !")
        return FunctionResult.FAIL


def ethernet_asu_get_adc_value(ip):
    # asu configure
    port = 11111

    data = {"ethernet_asu": {"adc_value": ""}}
    json_str = json.dumps(data)
    Logger().print_info("FI Ethernet", "send JSON:", json_str)
    s_sensor_ethernet.sendto(str.encode(json_str), (ip, port))

    try:
        data, address = s_sensor_ethernet.recvfrom(1024)
        Logger().print_info("FI Ethernet", "received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
    except TimeoutError:  # fail after 1 second of no activity
        Logger().print_info("FI Ethernet", "didn't receive anymore data! [Timeout]")
        return FunctionResult.FAIL

    adc_value = json_obj.get("key_state")

    if adc_value is not None:
        return adc_value
    else:
        Logger().print_info("FI Ethernet", "receive data error !")
        return FunctionResult.FAIL
