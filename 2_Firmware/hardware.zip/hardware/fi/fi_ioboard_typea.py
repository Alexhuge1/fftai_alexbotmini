import json
import os
import platform
import socket
import subprocess
import time

from fourier_core.predefine import (
    FunctionResult,
)

start_time = 0
stop_time = 0

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# s.settimeout(0.2)
s.settimeout(2)
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

PORT_io = 2335  # Real-time control data port, ie. speed, position, current and other real-time data


def isWindows():
    sysstr = platform.system()
    if sysstr == "Windows":
        return True
    return False


def killport(port):
    command_find = "netstat -aon | findstr " + str(port)
    command_kill = ""
    kill_pid_flag = False

    # result = os.popen(command)
    # print(result.read())
    try:
        with os.popen(command_find) as res:
            res = res.read().split("\n")
        result = []
        for line in res:
            temp = [i for i in line.split(" ") if i != ""]
            if len(temp) >= 4:
                result.append(temp[3])
        if len(result) == 0:
            pass
        else:
            for i in range(len(result)):
                # print(' len(result)=', len(result))
                command_kill = "taskkill /pid " + str(result[0]) + " -f"
                print("command_kill = ", command_kill)
                CREATE_NO_WINDOW = 0x08000000
                if (subprocess.call(command_kill, creationflags=CREATE_NO_WINDOW) == 0) is True:
                    print("kill_pid_flag = True")
                    kill_pid_flag = True
                else:
                    print("kill_pid_flag = False")
                    # kill_pid_flag = False
    except:
        pass
    else:
        if kill_pid_flag is True:
            return True
        else:
            return False

    """root authority is required"""

    # os.system(command)


if isWindows() is True:
    if killport(PORT_io) is True:
        time.sleep(2)
    s.bind(("", PORT_io))
# s.bind(('', PORT_io))

# network = '10.0.0.255'
network = "255.255.255.255"


# IO Board Get root attributes
# Parameters: including device IP
def getInfo(server_ip):
    data = {
        "method": "READ",
        "cmdTarget": "READ_INFO",
    }
    json_str = json.dumps(data)
    # print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        # print('Server received from {}:{}'.format(address, data.decode('utf-8')))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            # print('address = ', address)
            # print('data = ', data.decode('utf-8'))
            return (
                address[0],
                json_obj.get("system_state", True),
                json_obj.get("emergency_state", False),
                json_obj.get("voltage_value", 37.0),

                # Notice 2024-09-18:
                # here the wrong spelling is used,
                # because of the original code error
                json_obj.get("voltage_value_precent", 0),
                json_obj.get("robot_charging_level", 3),
                json_obj.get("robot_charging_state", 1),
            )
        else:
            return FunctionResult.FAIL

    except TimeoutError:  # fail after 1 second of no activity
        # print("Didn't receive anymore data! [Timeout]")
        return FunctionResult.TIMEOUT


# Get all basic attributes of IO Board, including version number
def getRoot(server_ip):
    data = {
        "method": "READ",
        "cmdTarget": "READ_ROOT",
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("software_serial_number = ", json_obj.get("software_serial_number"))
            return address, data.decode("utf-8")
    except TimeoutError:  # fail after 1 second of no activity
        print("Didn't receive anymore data! [Timeout]")


# IO Board bus voltage
# Parameters: including device IP
# Get all basic attributes of IO Board, including serial number, bus voltage, motor temperature, inverter temperature, version number
# Return bus voltage
def getVoltage(server_ip):
    data = {
        "method": "READ",
        "cmdTarget": "READ_VOLTAGE",
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}".format(address, json_obj.get("voltage_value")))
            return json_obj.get("voltage_value")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        # print("[getVoltage Timeout]")
        return None


# IO Board braking voltage
# Parameters: including device IP
# Get basic attributes of IO Board
# Return braking voltage
def getBrakingVoltage(server_ip):
    data = {
        "method": "READ",
        "cmdTarget": "READ_BRAKING_VOLTAGE",
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}".format(address, json_obj.get("braking_voltage_value")))
            return json_obj.get("braking_voltage_value")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        # print("[getVoltage Timeout]")
        return None


# IO Board Emergency State
# Parameters: including device IP
# Get basic attributes of IO Board
# Return Emergency Button State
def getEmergencyState(server_ip):
    data = {
        "method": "READ",
        "cmdTarget": "READ_EMERGENCY_STATE",
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}".format(address, json_obj.get("emergency_state")))
            return json_obj.get("emergency_state")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        # print("[getVoltage Timeout]")
        return None


# IO Board System State
# Parameters: including device IP
# Get basic attributes of IO Board
# Return System on or off State
def getSystemState(server_ip):
    data = {
        "method": "READ",
        "cmdTarget": "READ_SYSTEM_STATE",
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}".format(address, json_obj.get("system_state")))
            return json_obj.get("system_state")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        # print("[getVoltage Timeout]")
        return None


# IO Board Relay State
# Parameters: including device IP
# Get basic attributes of IO Board
# Return 5V Relay State
def getRelay5VState(server_ip):
    data = {
        "method": "READ",
        "cmdTarget": "READ_RELAY_5V_STATE",
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}".format(address, json_obj.get("relay_5v_state")))
            return json_obj.get("relay_5v_state")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        # print("[getVoltage Timeout]")
        return None


# IO Board Relay Time
# Parameters: including device IP
# Get basic attributes of IO Board
# Return 5V Relay Duration time ms
def getRelay5VDuration(server_ip):
    data = {
        "method": "READ",
        "cmdTarget": "READ_RELAY_5V_DURATION",
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}ms".format(address, json_obj.get("relay_5v_duration")))
            return json_obj.get("relay_5v_duration")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        # print("[getVoltage Timeout]")
        return None


# IO Board Relay State
# Parameters: including device IP
# Get basic attributes of IO Board
# Return 38V Relay State
def getRelay38VState(server_ip):
    data = {
        "method": "READ",
        "cmdTarget": "READ_RELAY_38V_STATE",
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}".format(address, json_obj.get("relay_38v_state")))
            return json_obj.get("relay_38v_state")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        # print("[getVoltage Timeout]")
        return None


# IO Board OTA State
# Parameters: including device IP
# Get basic attributes of IO Board
# Return OTA Runing State
def getOTAState(server_ip):
    data = {
        "method": "READ",
        "cmdTarget": "READ_OTA_STATE",
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}".format(address, json_obj.get("ota_runing_state")))
            return json_obj.get("ota_runing_state")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        # print("[getVoltage Timeout]")
        return None


# ////////////////////     Write Cmd          ////////////////////////


# IO Board OTA upgrade
# Parameters: including device IP
def OTAupdate(server_ip):
    data = {
        "method": "WRITE",
        "cmdTarget": "START_OTA",
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}".format(address, json_obj.get("ota_runing_state")))
            return json_obj.get("ota_runing_state")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        print("Didn't receive anymore data! [Timeout]")
        return None


# IO Board Relay Time
# Parameters: including device IP
# Set basic attributes of IO Board
# Return 5V Relay Duration time ms
def setRelay5VDuration(server_ip, ms_value=5000.0):
    if ms_value > 15000:
        ms_value_temp = 15000
    elif ms_value < 5000:
        ms_value_temp = 5000
    else:
        ms_value_temp = ms_value

    data = {
        "method": "WRITE",
        "cmdTarget": "WRITE_RELAY_5V_DURATION",
        "relay_5v_duration": ms_value_temp,
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}ms".format(address, json_obj.get("relay_5v_duration")))
            return json_obj.get("relay_5v_duration")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        # print("[getVoltage Timeout]")
        return None


# IO Board braking voltage
# Parameters: including device IP
# Set basic attributes of IO Board
# Return braking voltage
def setBrakingVoltage(server_ip, braking_voltage=48.0):
    if braking_voltage > 56:
        braking_voltage_temp = 56.0
    elif braking_voltage < 26:
        braking_voltage_temp = 26.0
    else:
        braking_voltage_temp = braking_voltage

    data = {
        "method": "WRITE",
        "cmdTarget": "WRITE_BREAKING_VOLTAGE",
        "braking_voltage_value": braking_voltage_temp,
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}".format(address, json_obj.get("braking_voltage_value")))
            return json_obj.get("braking_voltage_value")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        # print("[getVoltage Timeout]")
        return None


# IO Board ws2812b led
# Parameters: including device IP
# Set ws2812b led of IO Board
# Return ws2812b led state
def setLEDStrip(server_ip, on_number=17, color_type="RGB", param_1=5, param_2=5, param_3=5):
    data = {
        "method": "WRITE",
        "cmdTarget": "WRITE_LED_STRIP",
        "led_strip_state": {
            "led_on_number": on_number,
            "led_color_type": color_type,  # HSV RGB
            "led_color_param_1": param_1,
            "led_color_param_2": param_2,
            "led_color_param_3": param_3,
        },
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}".format(address, json_obj.get("led_strip_state")))
            return address[0], json_obj.get("led_strip_state")
        else:
            return FunctionResult.FAIL
    except TimeoutError:  # fail after 1 second of no activity
        # print("[getVoltage Timeout]")
        return FunctionResult.TIMEOUT


# IO Board restart
# Parameters: including device IP
def reboot(server_ip):
    data = {
        "method": "WRITE",
        "cmdTarget": "REBOOT",
    }
    json_str = json.dumps(data)
    print("Send JSON Obj:", json_str)
    s.sendto(str.encode(json_str), (server_ip, PORT_io))
    try:
        data, address = s.recvfrom(1024)
        print("Server received from {}:{}".format(address, data.decode("utf-8")))
        json_obj = json.loads(data.decode("utf-8"))
        if json_obj.get("status") == "OK":
            print("Server received from {}:{}".format(address, json_obj.get("reboot_state")))
            return json_obj.get("reboot_state")
        else:
            return None
    except TimeoutError:  # fail after 1 second of no activity
        print("Didn't receive anymore data! [Timeout]")

# # IO_Module set IO_State status
# # parameter：PWM0_CH PWM1_CH SERVO0 SERVO1
# # Parameter value range: PWM0_CH,PWM1_CH[0~65535], SERVO0,SERVO1[0~180]
# # return AI0 AI1 DI0 DI1
# def setIOState(dict, reply_enable, server_ip):
#     data = {
#         'method' : 'WRITE',
#         'cmdTarget' : '/IO_State',
#     }
#     data['reply_enable'] = reply_enable
#     data['PWM0_CH'] = dict['PWM0_CH']
#     data['PWM1_CH'] = dict['PWM1_CH']
#     data['SERVO0'] = dict['SERVO0']
#     data['SERVO1'] = dict['SERVO1']
#     json_str = json.dumps(data)
#     print ("Send JSON Obj:", json_str)
#     s.sendto(str.encode(json_str), (server_ip, PORT_io))
#     if reply_enable:
#         try:
#             data, address = s.recvfrom(1024)
#             print('Server received from {}:{}'.format(address, data.decode('utf-8')))
#             # json_obj = json.loads(data.decode('utf-8'))
#             # print("Position = %.2f, Velocity = %.0f, Current = %.4f \n" %(json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')))
#         except socket.timeout: # fail after 1 second of no activity
#             print("Didn't receive anymore data! [Timeout]")
