# 本代码示例用于演示如何进行人脸检测
# 参考：
# - https://www.cnblogs.com/lllcccddd/p/11263983.html

import cv2

cap = cv2.VideoCapture(0)  # 0: computer camera; 1: usb camera
cap.set(3, 900)  # width
cap.set(4, 900)  # height

detector = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

while cap.isOpened():
    return_flag, image = cap.read()

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = detector.detectMultiScale(gray, 1.3, 5)

    for x, y, w, h in faces:
        cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 2)

    cv2.imshow("image", image)

    key = cv2.waitKey(1)  # 等待1ms，没有继续刷新
    if key == ord("q"):
        print("完成")
        break

cap.release()
cv2.destroyAllWindows()
