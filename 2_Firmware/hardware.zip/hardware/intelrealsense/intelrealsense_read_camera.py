# 本代码示例用于演示如何读取摄像头的图像信息
# 参考：
# - https://www.cnblogs.com/lllcccddd/p/11263983.html

import cv2

cap = cv2.VideoCapture(0)  # 0: computer camera; 1: usb camera
cap.set(3, 900)  # width
cap.set(4, 900)  # height

while cap.isOpened():
    return_flag, vshow = cap.read()
    cv2.imshow("Capture", vshow)

    key = cv2.waitKey(1)  # 等待1ms，没有继续刷新
    if key == ord("s"):
        print("2222222222")
    elif key == ord("q"):
        print("完成")
        break

cap.release()
cv2.destroyAllWindows()
