from .fi_hardware_import import fi_sensor_ethernet


def ethernet_asu_get_adc_value(self, ip):
    result = fi_sensor_ethernet.ethernet_asu_get_adc_value(ip=ip)

    adc_value = [0, 0, 0, 0]
    if result is not None:
        adc_value = result

    return adc_value
