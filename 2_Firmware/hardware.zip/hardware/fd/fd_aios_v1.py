import socket
import time
import json
import math
import numpy

from .fd_aios_logger import Logger
from .fd_aios_predefine import (
    FunctionResult,
    AIOSFlagState,
    AIOSV1AxisState,
)

aios_debug = False
aios_timeout = 0.2
aios_port_ctrl = 2333
aios_port_comm = 2334
aios_port_fast = 10000
aios_network = "10.10.10.255"

socket_ctrl = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
socket_ctrl.settimeout(aios_timeout)
socket_ctrl.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

socket_comm = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
socket_comm.settimeout(aios_timeout)
socket_comm.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

socket_fast = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
socket_fast.settimeout(aios_timeout)
socket_fast.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)


# ---------------------------------------------------------------------------------------------------------------------

def init(server_ip):
    return FunctionResult.SUCCESS


def comm(server_ip, enable):
    return FunctionResult.SUCCESS


def check(server_ip):
    return FunctionResult.SUCCESS


def subscribe(server_ip):
    return FunctionResult.SUCCESS


# ---------------------------------------------------------------------------------------------------------------------

# AIOSV1 enable
# Parameters: including device IP and motor number
# Each AIOSV1 can control two motors, M0 and M1
def enable(server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/requested_state',
        'property': AIOSV1AxisState.AXIS_STATE_ENABLE.value
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

    json_obj = None
    try:
        data, address = socket_ctrl.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")
        return False

    if json_obj.get('status') == 'OK':
        return True
    else:
        Logger().print_warning("AIOSV1 enable Recv Data Error !")
        return False


def enable_group(server_ips):
    # Jason: 这里为什么要 sleep 1 秒？
    time.sleep(1)

    data = {
        "method": "SET",
        'reqTarget': '/m1/requested_state',
        'property': AIOSV1AxisState.AXIS_STATE_ENABLE.value
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug("enable_group Send JSON Obj:", json_str)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

    response = {}
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        response.update({server_ip: {}})

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len(server_ips)):
        try:
            data, address = socket_ctrl.recvfrom(1024)
            recv_ip, recv_port = address

            if response.get(recv_ip) is not None:
                json_obj = json.loads(data.decode('utf-8'))
                if json_obj.get('status') == 'OK' and json_obj.get('reqTarget') == '/m1/requested_state':
                    response.get(recv_ip).update({"data": data})
                else:
                    Logger().print_error(recv_ip, " receive data reqTarget error!")
                    continue
            else:
                Logger().print_warning("aios_v1.enable_group() receive wrong ip address ",
                                       (recv_ip, recv_port))

                # 接收到错误的 ip，就再接收一次；如果仍然接收错误，则放弃处理，执行下一次的接收
                data, address = socket_ctrl.recvfrom(1024)
                recv_ip, recv_port = address

                if response.get(recv_ip) is not None:
                    response.get(recv_ip).update({"data": data})
                else:
                    Logger().print_warning("aios_v1.enable_group() receive wrong ip address ",
                                           (recv_ip, recv_port))
                    continue

            if aios_debug is True:
                try:
                    Logger().print_debug('Server received from {}:{}'.format(recv_ip, data.decode('utf-8')))
                except:
                    Logger().print_debug('Server received from {} data none'.format(recv_ip))
                    pass

        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_error("aios_v1.enable_group() Didn't receive enough data! [Timeout]")
            continue

        except Exception as e:
            Logger().print_warning("aios_v1.enable_group() except")
            continue

    if aios_debug is True:
        Logger().print_debug(f"response = {response}")

    for i in range(len((server_ips))):
        server_ip = server_ips[i]
        data = response.get(server_ip).get("data")

        try:
            json_obj = json.loads(data.decode('utf-8'))

            if json_obj.get('status') == 'OK':
                response.get(server_ip).update({"return": FunctionResult.SUCCESS})

            else:
                response.get(server_ip).update({"return": FunctionResult.FAIL})
                Logger().print_error(f"{server_ip} receive status is not OK!")
                continue

        except:
            response.get(server_ip).update({"return": FunctionResult.FAIL})
            Logger().print_warning("aios_v1.enable_group() except")
            continue

    func_result = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        func_result.append(response.get(server_ip).get("return"))

    if aios_debug is True:
        Logger().print_debug('func_result = ', func_result)

    return func_result


# AIOSV1 Disable
# Parameters: including device IP and motor number
# Each AIOSV1 can control two motors, M0 and M1
def disable(server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/requested_state',
        'property': AIOSV1AxisState.AXIS_STATE_IDLE.value
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

    json_obj = None
    try:
        data, address = socket_ctrl.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")

    if json_obj.get('status') == 'OK':
        return True
    else:
        Logger().print_warning("AIOSV1 enable Recv Data Error !")
        return False


def disable_group(server_ips):
    data = {
        "method": "SET",
        'reqTarget': '/m1/requested_state',
        'property': AIOSV1AxisState.AXIS_STATE_IDLE.value
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug("disable_group Send JSON Obj:", json_str)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

    response = {}
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        response.update({server_ip: {}})

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len(server_ips)):
        try:
            data, address = socket_ctrl.recvfrom(1024)
            recv_ip, recv_port = address

            if response.get(recv_ip) is not None:
                json_obj = json.loads(data.decode('utf-8'))
                if json_obj.get('status') == 'OK' and json_obj.get('reqTarget') == '/m1/requested_state':
                    response.get(recv_ip).update({"data": data})
                else:
                    Logger().print_error(recv_ip, " receive data reqTarget error!")
                    continue
            else:
                Logger().print_warning("aios_v1.disable_group() receive wrong ip address ",
                                       (recv_ip, recv_port))

                # 接收到错误的 ip，就再接收一次；如果仍然接收错误，则放弃处理，执行下一次的接收
                data, address = socket_ctrl.recvfrom(1024)
                recv_ip, recv_port = address

                if response.get(recv_ip) is not None:
                    response.get(recv_ip).update({"data": data})
                else:
                    Logger().print_warning("aios_v1.disable_group() receive wrong ip address ",
                                           (recv_ip, recv_port))
                    continue

            if aios_debug is True:
                try:
                    Logger().print_debug('Server received from {}:{}'.format(recv_ip, data.decode('utf-8')))
                except:
                    Logger().print_debug('Server received from {} data none'.format(recv_ip))
                    pass

        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_error("aios_v1.disable_group() Didn't receive enough data! [Timeout]")
            continue

        except Exception as e:
            Logger().print_warning("aios_v1.disable_group() except", e)
            continue

    if aios_debug is True:
        Logger().print_debug(f"response = {response}")

    for i in range(len((server_ips))):
        server_ip = server_ips[i]
        data = response.get(server_ip).get("data")

        try:
            if data is None:
                Logger().print_error(server_ip, " receive value is None!")
                response.get(server_ip).update({"return": FunctionResult.FAIL})
                continue

            json_obj = json.loads(data.decode('utf-8'))

            if json_obj.get('status') == 'OK':
                response.get(server_ip).update({"return": FunctionResult.SUCCESS})

            else:
                response.get(server_ip).update({"return": FunctionResult.FAIL})
                Logger().print_error(f"{server_ip} receive status is not OK!")
                continue

        # except e:
        except:
            response.get(server_ip).update({"return": FunctionResult.FAIL})
            Logger().print_warning("aios_v1.disable_group() except")
            continue

    func_result = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        func_result.append(response.get(server_ip).get("return"))

    if aios_debug is True:
        Logger().print_debug('func_result = ', func_result)

    return func_result


# AIOSV1 Get current status
# Parameters: including device IP
# Get AIOSV1 Get current status
def get_state(server_ip):
    data = {
        'method': 'GET',
        'reqTarget': '/m1/requested_state',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))

    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 Get root attributes
# Parameters: including device IP
# Get all basic attributes of AIOSV1, including serial number, bus voltage, motor temperature, inverter temperature, version number
def get_root(server_ip):
    data = {
        'method': 'GET',
        'reqTarget': '/',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 Get root attributes
# Parameters: including device IP
# Get all basic attributes of AIOSV1, including serial number, bus voltage, motor temperature, inverter temperature, version number
def get_info(server_ip):
    data = {
        'id': 0,
        'method': 'Device.Info',
        'params': '',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 Get Root Config property
# Parameters: including device IP
# Get AIOSV1 bus voltage over-voltage and under-voltage protection threshold
def get_root_config(server_ip):
    data = {
        'method': 'GET',
        'reqTarget': '/config',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 set Root Config properties
# Parameter: The protection threshold of bus voltage overvoltage and undervoltage
# Return success or failure
def set_root_config(dict, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/config',
        'dc_bus_overvoltage_trip_level': 30,
        'dc_bus_undervoltage_trip_level': 10,
    }
    data['dc_bus_overvoltage_trip_level'] = dict['dc_bus_overvoltage_trip_level']
    data['dc_bus_undervoltage_trip_level'] = dict['dc_bus_undervoltage_trip_level']
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 save configuration
# Parameters: including device IP
def save_config(server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/',
        'property': 'save_config'
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 clear configuration
# Parameters: including device IP
def erase_config(server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/',
        'property': 'erase_config'
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 restart
# Parameters: including device IP
def reboot(server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/',
        'property': 'reboot'
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOS restart
# Parameters: including device IP
def reboot_group(server_ips):
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        data = {
            'method': 'SET',
            'reqTarget': '/',
            'property': 'reboot'
        }
        json_str = json.dumps(data)

        if aios_debug is True:
            Logger().print_debug("reboot_group Send JSON Obj:", json_str)

        socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))

    response = {}
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        response.update({server_ip: {}})

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len(server_ips)):
        try:
            data, address = socket_comm.recvfrom(1024)
            recv_ip, recv_port = address
            response.get(recv_ip).update({"data": data})

            if aios_debug is True:
                Logger().print_debug('Server received from {}:{}'.format(address, data.decode('utf-8')))

        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_error("aios_v1.reboot_group() Didn't receive enough data! [Timeout]")
            continue

        except:
            Logger().print_warning("aios_v1.reboot_group() except")
            continue

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len((server_ips))):
        server_ip = server_ips[i]
        data = response.get(server_ip).get("data")

        try:
            json_obj = json.loads(data.decode('utf-8'))

            if json_obj.get('status') == 'OK':
                response.get(server_ip).update({"return": FunctionResult.SUCCESS})
            else:
                response.get(server_ip).update({"return": FunctionResult.FAIL})
                Logger().print_error(f"{server_ip} receive status is not OK!")
                continue

        except:
            response.get(server_ip).update({"return": FunctionResult.FAIL})
            Logger().print_warning(server_ip + " aios_v1.reboot_group() except")
            continue

    func_result = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        func_result.append(response.get(server_ip).get("return"))

    if aios_debug is True:
        Logger().print_debug(func_result)

    return func_result


# AIOSV1 restart the motor drive
# Parameters: including device IP
def reboot_motor_drive(server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/',
        'property': 'reboot_motor_drive'
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 OTA upgrade
# Parameters: including device IP
def ota_update(server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/',
        'property': 'OTA_update'
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 Get error code
# Parameters: including server IP
def get_error(server_ip):
    data = {
        'method': 'GET',
        'reqTarget': '/m1/error',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
        if json_obj.get('status') == 'OK':
            return json_obj.get('axis'), json_obj.get('motor'), json_obj.get('encoder')

    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


def get_error_group(server_ips):
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        data = {
            'method': 'GET',
            'reqTarget': '/m1/error',
        }
        json_str = json.dumps(data)

        if aios_debug is True:
            Logger().print_debug("get_error_group Send JSON Obj:", json_str)

        socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))

    response = {}
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        response.update({server_ip: {}})

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len(server_ips)):
        try:
            data, address = socket_comm.recvfrom(1024)
            recv_ip, recv_port = address
            response.get(recv_ip).update({"data": data})

            if aios_debug is True:
                Logger().print_debug('Server received from {}:{}'.format(address, data.decode('utf-8')))

        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_error("aios_v1.get_error_group() Didn't receive enough data! [Timeout]")
            continue

        except:
            Logger().print_warning("aios_v1.get_error_group() except")
            continue

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len((server_ips))):
        server_ip = server_ips[i]
        data = response.get(server_ip).get("data")

        try:
            json_obj = json.loads(data.decode('utf-8'))

            if json_obj.get('status') == 'OK':
                response.get(server_ip).update({"return": FunctionResult.SUCCESS})
                response.get(server_ip).update({"axis": json_obj.get('axis')})
                response.get(server_ip).update({"motor": json_obj.get('motor')})
                response.get(server_ip).update({"encoder": json_obj.get('encoder')})
            else:
                response.get(server_ip).update({"return": FunctionResult.FAIL})
                Logger().print_error(f"{server_ip} receive status is not OK!")
                continue

        except:
            response.get(server_ip).update({"return": FunctionResult.FAIL})
            Logger().print_warning(server_ip + " aios_v1.get_error_group() except")
            continue

    axis = []
    motors = []
    encoders = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        axis.append(response.get(server_ip).get("axis"))
        motors.append(response.get(server_ip).get("motor"))
        encoders.append(response.get(server_ip).get("encoder"))

    if aios_debug is True:
        Logger().print_debug(axis)
        Logger().print_debug(motors)
        Logger().print_debug(encoders)
    Logger().print_debug('axis=', axis)
    Logger().print_debug('motor=', motors)
    Logger().print_debug('encoder=', encoders)

    return axis, motors, encoders


# AIOSV1 Remove error
# Parameters: including server IP
def clear_error(server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/error',
        'clear_error': True
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


def clear_error_group(server_ips):
    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        data = {
            'method': 'SET',
            'reqTarget': '/m1/error',
            'clear_error': True
        }
        json_str = json.dumps(data)

        if aios_debug is True:
            Logger().print_debug("clear_error_group Send JSON Obj:", json_str)

        socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))

    response = {}
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        response.update({server_ip: {}})

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len(server_ips)):
        try:
            data, address = socket_comm.recvfrom(1024)
            recv_ip, recv_port = address
            response.get(recv_ip).update({"data": data})

            if aios_debug is True:
                Logger().print_debug('Server received from {}:{}'.format(recv_ip, data.decode('utf-8')))

        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_error("aios_v1.clear_error_group() Didn't receive enough data! [Timeout]")
            continue

        except:
            Logger().print_warning("aios_v1.clear_error_group() except")
            continue

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len((server_ips))):
        server_ip = server_ips[i]
        data = response.get(server_ip).get("data")

        try:
            json_obj = json.loads(data.decode('utf-8'))

            if json_obj.get('status') == 'OK':
                response.get(server_ip).update({"return": FunctionResult.SUCCESS})
            else:
                response.get(server_ip).update({"return": FunctionResult.FAIL})
                Logger().print_error(f"{server_ip} receive status is not OK!")
                continue

        except:
            response.get(server_ip).update({"return": FunctionResult.FAIL})
            Logger().print_warning(server_ip + " aios_v1.clear_error_group() except")
            continue

    func_result = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        func_result.append(response.get(server_ip).get("return"))

    if aios_debug is True:
        Logger().print_debug(func_result)

    return func_result


# AIOSV1 Get actuator position, speed, current
# Parameters: including server ip，motor number
# Return position, speed, current in tuple
def get_pvc(server_ip):
    data = {
        'method': 'GET',
        'reqTarget': '/m1/CVP',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"Send JSON Obj: {json_str}")

    socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

    try:
        data, address = socket_ctrl.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))

        if json_obj.get('status') == 'OK':
            return json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')
        else:
            return FunctionResult.FAIL

    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")
        return FunctionResult.TIMEOUT


def get_pvc_group(server_ips):
    data = {
        'method': 'GET',
        'reqTarget': '/m1/CVP',
    }
    json_str = json.dumps(data)

    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        if aios_debug is True:
            Logger().print_debug("get_pvc_group Send JSON Obj:", json_str)

        socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

    response = {}
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        response.update({server_ip: {}})

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len(server_ips)):
        try:
            data, address = socket_ctrl.recvfrom(1024)
            recv_ip, recv_port = address

            json_obj = json.loads(data.decode("utf-8"))
            if json_obj.get("status") == "OK":
                response.get(recv_ip).update({"data": json_obj})
            else:
                continue

            if aios_debug is True:
                Logger().print_debug('Server received from {}:{}'.format(recv_ip, data.decode('utf-8')))

        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_error(response)
            Logger().print_error("aios_v1.get_pvc_group() Didn't receive enough data! [Timeout]")
            continue

        except:
            Logger().print_warning("aios_v1.get_pvc_group() except 1")
            continue

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len((server_ips))):
        server_ip = server_ips[i]
        data = response.get(server_ip).get("data")

        try:
            json_obj = data  # copy dict data -> json_obj

            if json_obj.get('status') == 'OK':
                response.get(server_ip).update({"return": FunctionResult.SUCCESS})
                response.get(server_ip).update({"position": json_obj.get('position')})
                response.get(server_ip).update({"velocity": json_obj.get('velocity')})
                response.get(server_ip).update({"current": json_obj.get('current')})
            else:
                response.get(server_ip).update({"return": FunctionResult.FAIL})
                Logger().print_error(f"{server_ip} receive status is not OK!")
                continue

        except:
            response.get(server_ip).update({"return": FunctionResult.FAIL})
            Logger().print_warning(server_ip + " aios_v1.get_pvc_group() except 2")
            continue

    positions = []
    velocitys = []
    currents = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        positions.append(response.get(server_ip).get("position"))
        velocitys.append(response.get(server_ip).get("velocity"))
        currents.append(response.get(server_ip).get("current"))

    if aios_debug is True:
        Logger().print_debug(positions)
        Logger().print_debug(velocitys)
        Logger().print_debug(currents)

    return positions, velocitys, currents


# AIOSV1 编码器校准 (初期版本电机编码器需要先校准才能使用，后期完善后不需要此操作)
# 参数：包括设备IP 电机号
# 无返回
def encoder_offset_calibration(server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/requested_state',
        # 'property' : AxisState.AXIS_STATE_ENCODER_OFFSET_CALIBRATION.value
        'property': AIOSV1AxisState.AXIS_STATE_FULL_CALIBRATION_SEQUENCE.value
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 test if the encoder is ready or not (If not ready, perform encoder calibration)
# Parameters: including server ip，motor number
# no return code
def encoder_is_ready(server_ip):
    data = {
        'method': 'GET',
        'reqTarget': '/m1/encoder/is_ready',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning('AIOSV1', ' encoderIsReady ', "Didn't receive data! [Timeout]")
        return False

    if json_obj.get('status') == 'OK':
        if json_obj.get('property') == True:
            return True
        elif json_obj.get('property') == False:

            if aios_debug is True:
                Logger().print_debug("encoderIsReady direction error !")

            return "MotorCrazy"
        else:
            return False
    else:
        Logger().print_warning('AIOSV1', "encoderIsReady Recv Data Error !")
        return "MotorCrazy"


# AIOS test if the encoder is ready or not (If not ready, perform encoder calibration)
# Parameters: including server ip，motor number
# no return code
def encoder_is_ready_group(server_ips):
    is_readys = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        is_readys.append(True)
    if aios_debug is True:
        Logger().print_debug(is_readys)
    Logger().print_debug('is_readys = ', is_readys)
    return is_readys

    for i in range(len(server_ips)):
        server_ip = server_ips[i]

        data = {
            'method': 'GET',
            'reqTarget': '/m1/encoder/is_ready',
        }
        json_str = json.dumps(data)

        if aios_debug is True:
            Logger().print_debug("encoder_is_ready_group Send JSON Obj:", json_str)

        socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))

    response = {}
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        response.update({server_ip: {}})

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len(server_ips)):
        try:
            data, address = socket_comm.recvfrom(1024)
            recv_ip, recv_port = address
            response.get(recv_ip).update({"data": data})

            if aios_debug is True:
                Logger().print_debug('Server received from {}:{}'.format(address, data.decode('utf-8')))
            Logger().print_debug('Server received from {}:{}'.format(address, data.decode('utf-8')))

        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_error("aios_v1.encoder_is_ready_group() Didn't receive enough data! [Timeout]")
            continue

        except:
            Logger().print_warning("aios_v1.encoder_is_ready_group() except")
            continue

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len((server_ips))):
        server_ip = server_ips[i]
        data = response.get(server_ip).get("data")

        try:
            json_obj = json.loads(data.decode('utf-8'))

            if json_obj.get('status') == 'OK':
                response.get(server_ip).update({"return": FunctionResult.SUCCESS})
                response.get(server_ip).update({"is_ready": json_obj.get('property')})
            else:
                response.get(server_ip).update({"return": FunctionResult.FAIL})
                response.get(server_ip).update({"is_ready": None})
                Logger().print_error(server_ip + " : Recv Data Error !")
                continue

        except:
            response.get(server_ip).update({"return": FunctionResult.FAIL})
            response.get(server_ip).update({"is_ready": None})
            Logger().print_warning(server_ip + " aios_v1.encoder_is_ready_group() except")
            continue

    is_readys = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        is_readys.append(response.get(server_ip).get("is_ready"))

    if aios_debug is True:
        Logger().print_debug(is_readys)
    Logger().print_debug('is_readys = ', is_readys)

    return is_readys


# AIOSV1 set control mode
# Parameters: including server ip，motor number
# no return code
def set_control_mode(control_mode, server_ip):
    pass


def set_control_mode_group(control_modes, server_ips):
    for i in range(len(server_ips)):
        control_mode_value = control_modes[i]
        server_ip = server_ips[i]

        set_control_mode(control_mode_value, server_ip)


# AIOSV1 reset linear count
# Parameters: including server ip，motor number
# no return code
def set_linear_count(set_linear_count, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/encoder',
        'set_linear_count': 0
    }

    data['set_linear_count'] = set_linear_count
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))

        if json_obj.get('status') == 'OK':
            return address[0], data.decode('utf-8')
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOS reset linear count
# Parameters: including server ip，motor number
# no return code
def set_linear_count_group(server_ips, set_linear_counts=None):
    if set_linear_counts is None:
        set_linear_counts = numpy.zeros_like(server_ips).tolist()

    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        # set_linear_count = set_linear_counts[i]

        data = {
            'method': 'SET',
            'reqTarget': '/m1/encoder',
            'set_linear_count': 0
        }
        json_str = json.dumps(data)

        if aios_debug is True:
            Logger().print_debug("set_linear_count_group Send JSON Obj:", json_str)

        socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

    response = {}
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        response.update({server_ip: {}})

    if aios_debug is True:
        Logger().print_debug(response)

    for i in range(len(server_ips)):
        try:
            data, address = socket_ctrl.recvfrom(1024)
            recv_ip, recv_port = address

            if recv_ip not in server_ips:
                # Logger().print_error("aios_v1.set_linear_count_group() receive wrong ip data: ",
                #                             recv_ip)
                continue
            else:
                json_obj = json.loads(data.decode('utf-8'))
                if json_obj.get('status') == 'OK' and json_obj.get('reqTarget') == '/home_offset':
                    response.get(recv_ip).update({"data": data})
                else:
                    Logger().print_error(server_ip, " receive data reqTarget error!")
                    continue

            if aios_debug is True:
                Logger().print_debug('Server received from {}:{}'.format(address, data.decode('utf-8')))

        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_error("aios_v1.set_linear_count_group() Didn't receive enough data! [Timeout]")
            continue

        except:
            Logger().print_warning("aios_v1.set_linear_count_group() except")
            continue

    if aios_debug is True:
        Logger().print_debug(f"response = {response}")

    for i in range(len((server_ips))):
        server_ip = server_ips[i]
        data = response.get(server_ip).get("data")

        try:
            json_obj = json.loads(data.decode('utf-8'))

            if json_obj.get('status') == 'OK':
                response.get(server_ip).update({"return": FunctionResult.SUCCESS})
            else:
                response.get(server_ip).update({"return": FunctionResult.FAIL})
                Logger().print_error(f"{server_ip} receive status is not OK!")
                continue

        except:
            response.get(server_ip).update({"return": FunctionResult.FAIL})
            Logger().print_error(server_ip, " receive data decode error!")
            continue

    func_result = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        func_result.append(response.get(server_ip).get("return"))

    if aios_debug is True:
        Logger().print_debug(func_result)

    return func_result


# AIOSV1 Get actuator PID controller parameters
# Parameters: including server ip，motor number
# Return to control mode in tuples:
# Position proportional gain
# Speed proportional gain
# Speed integral gain
# Speed limit
# Speed limit tolerance
def get_motion_ctrl_config(server_ip):
    data = {
        'method': 'GET',
        'reqTarget': '/m1/controller/config',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))

        if json_obj.get('status') == 'OK':
            return json_obj.get('control_mode'), json_obj.get('pos_gain'), json_obj.get('vel_gain'), json_obj.get(
                'vel_integrator_gain'), json_obj.get('vel_limit'), json_obj.get('vel_limit_tolerance')
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 Get actuator PID controller parameters
# parameter: Position proportional gain Speed proportional gain Speed integral gain Speed limit Speed limit tolerance
# return success or fail
def set_motion_ctrl_config(dict, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/controller/config',
        'pos_gain': 20,
        'vel_gain': 0.0005,
        'vel_integrator_gain': 0.0002,
        'vel_limit': 40000,
        'vel_limit_tolerance': 1.2,
    }
    data['pos_gain'] = dict['pos_gain']
    data['vel_gain'] = dict['vel_gain']
    data['vel_integrator_gain'] = dict['vel_integrator_gain']
    data['vel_limit'] = dict['vel_limit']
    data['vel_limit_tolerance'] = dict['vel_limit_tolerance']
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 get actuator MotorConfig parameters
# parameter: server ip, motor number
# return Parameters: motor current limit, current limit margin, inverter temperature offline, inverter temperature upper limit, current control bandwidth, including device IP, motor number as a tuple
def get_motor_config(server_ip):
    data = {
        'method': 'GET',
        'reqTarget': '/m1/motor/config',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
        if json_obj.get('status') == 'OK':
            return json_obj.get('current_lim'), json_obj.get('current_lim_margin'), json_obj.get(
                'inverter_temp_limit_lower'), json_obj.get('inverter_temp_limit_upper'), json_obj.get(
                'requested_current_range'), json_obj.get('current_control_bandwidth')
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 set actuator MotorConfig parameter
# Parameters: motor current limit, current limit margin, inverter temperature offline, inverter temperature upper limit, current control bandwidth, including device IP, motor number
# ruturn seccess or fail
def set_motor_config(dict, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/motor/config',
        'current_lim': 15,
        'current_lim_margin': 5,
        'inverter_temp_limit_lower': 100,
        'inverter_temp_limit_upper': 120,
        'requested_current_range': 30,
        'current_control_bandwidth': 1000,
    }
    data['current_lim'] = dict['current_lim']
    data['current_lim_margin'] = dict['current_lim_margin']
    data['inverter_temp_limit_lower'] = dict['inverter_temp_limit_lower']
    data['inverter_temp_limit_upper'] = dict['inverter_temp_limit_upper']
    data['requested_current_range'] = dict['requested_current_range']
    data['current_control_bandwidth'] = dict['current_control_bandwidth']
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
        if json_obj.get('status') == 'OK':
            return json_obj.get('current_lim'), json_obj.get('current_lim_margin'), json_obj.get(
                'inverter_temp_limit_lower'), json_obj.get('inverter_temp_limit_upper'), json_obj.get(
                'requested_current_range'), json_obj.get('current_control_bandwidth')
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 Get the trajectory parameters of actuator trapezoidal mode
# parameter: server ip, motor number
# ruturn trapezoidal acceleration, trapezoidal deceleration, trapezoidal speed limit as a tuple
def get_trap_traj(server_ip):
    data = {
        'method': 'GET',
        'reqTarget': '/m1/trap_traj',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
        if json_obj.get('status') == 'OK':
            return json_obj.get('accel_limit'), json_obj.get('decel_limit'), json_obj.get('vel_limit')
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 Set trajectory parameters of actuator trapezoidal mode
# parameter：Including trapezoidal acceleration, trapezoidal deceleration, trapezoidal speed limit, device IP, motor number
# Return success or failure as a tuple
def set_trap_traj(dict, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/trap_traj',
        'accel_limit': 320000,
        'decel_limit': 320000,
        'vel_limit': 200000
    }
    data['accel_limit'] = dict['accel_limit']
    data['decel_limit'] = dict['decel_limit']
    data['vel_limit'] = dict['vel_limit']
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 velocity ramp enable
# parameter:controller mode,server ip,motor number
# return none
def set_vel_ramp_enable(enable, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/controller',
        'vel_ramp_enable': False
    }
    data['vel_ramp_enable'] = enable
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 Speed ramp mode Set target speed
# parameter：target velocity,server ip,motor number
# no return
def vel_ramp_target(target, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/controller',
        'vel_ramp_target': 0
    }
    data['vel_ramp_target'] = target
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))
    try:
        data, address = socket_ctrl.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 Set the target position of the trapezoidal motion track
# parameter: position,reply enable,server ip,motor number
# return position, velocity, current
def trapezoidal_move(position, reply_enable, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/trapezoidalMove',
        'property': 0,
        'reply_enable': True
    }
    data['property'] = position
    data['reply_enable'] = reply_enable
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))
    if reply_enable:
        try:
            data, address = socket_ctrl.recvfrom(1024)

            if aios_debug is True:
                Logger().print_debug(f"AIOSV1 received from {address}:{data}")

            json_obj = json.loads(data.decode('utf-8'))

            if aios_debug is True:
                Logger().print_debug('AIOSV1', "Position = %.2f, Velocity = %.0f, Current = %.4f \n" % (

                    json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')))
        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 position control
# paramter: position,velocity,current feedforward,serverIP,motor number
# return position, velocity, current
def set_position(position, velocity_ff, current_ff, reply_enable, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/setPosition',
        'reply_enable': False,
        'position': 0,
        'velocity_ff': 0,
        'current_ff': 0
    }
    data['reply_enable'] = reply_enable
    data['position'] = position
    data['velocity_ff'] = velocity_ff
    data['current_ff'] = current_ff
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    try:
        socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))
        return FunctionResult.SUCCESS
    except socket.timeout:
        return FunctionResult.TIMEOUT
    except:
        return FunctionResult.FAIL
    else:
        return FunctionResult.FAIL
        # if reply_enable:
    #     try:
    #         data, address = socket_ctrl.recvfrom(1024)
    #         # Logger().print_debug(f"AIOSV1 received from {address}:{data}")
    #         json_obj = json.loads(data.decode('utf-8'))
    #         Logger().print_debug('AIOSV1', "Position = %.2f, Velocity = %.0f, Current = %.4f \n" %(json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')))
    #     except socket.timeout: # fail after 1 second of no activity
    #         Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


def set_position_group(server_ips, positions, velocity_ffs, current_ffs):
    # send request
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        position = positions[i]
        velocity_ff = velocity_ffs[i]
        current_ff = current_ffs[i]

        data = {
            "method": "SET",
            'reqTarget': '/m1/setPosition',
            "reply_enable": True,
            "position": position,
            "velocity_ff": velocity_ff,
            "current_ff": current_ff,
        }
        json_str = json.dumps(data)

        socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

        if aios_debug is True:
            Logger().print_debug("set_input_position_pt_group Send Data:", json_str)

    # get response
    response = {}
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        response.update({server_ip: {}})

    for i in range(len(server_ips)):
        try:
            data, address = socket_ctrl.recvfrom(1024)
            recv_ip, recv_port = address

            json_obj = json.loads(data.decode("utf-8"))

            if json_obj.get("status") == "OK":
                response.get(recv_ip).update({"data": json_obj})
            else:
                continue
            if recv_ip not in server_ips:
                # Logger().print_error("aios_v1.set_input_position_pt_group() receive wrong ip data: ",
                #                             recv_ip)
                continue

        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_error("aios_v1.set_input_position_pt_group() Didn't receive enough data! [Timeout]")
            continue

    # data parse
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        data = response.get(server_ip).get("data")

        if data:
            feedback = [data.get("position"), data.get("velocity"), data.get("current")]
        else:
            feedback = None

        response.get(server_ip).update({"feedback": feedback})

    # feedback
    positions = []
    velocitys = []
    currents = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        feedback = response.get(server_ip).get("feedback")

        if feedback is not None:
            positions.append(feedback[0])
            velocitys.append(feedback[1])
            currents.append(feedback[2])
        else:
            positions.append(None)
            velocitys.append(None)
            currents.append(None)

    return positions, velocitys, currents


# AIOSV1 velocity control
# paramter: velocity,current feedforward,serverIP,motor number
# return position, velocity, current
def set_velocity(velocity, current_ff, reply_enable, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/setVelocity',
        'velocity': 0,
        'current_ff': 0
    }
    data['reply_enable'] = reply_enable
    data['velocity'] = velocity
    data['current_ff'] = current_ff
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

    if reply_enable:
        try:
            data, address = socket_ctrl.recvfrom(1024)

            if aios_debug is True:
                Logger().print_debug(f"AIOSV1 received from {address}:{data}")

            json_obj = json.loads(data.decode('utf-8'))

            if aios_debug is True:
                Logger().print_debug('AIOSV1', "Position = %.2f, Velocity = %.0f, Current = %.4f \n" % (

                    json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')))

            if json_obj.get('status') == 'OK':
                return address[0], json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')
            else:
                return None
        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")
            return FunctionResult.TIMEOUT


def set_velocity_group(server_ips, velocitys, current_ffs):
    # send request
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        velocity = velocitys[i]
        current_ff = current_ffs[i]
        data = {
            "method": "SET",
            'reqTarget': '/m1/setVelocity',
            "reply_enable": True,
            "velocity": velocity,
            "current_ff": current_ff,
        }
        json_str = json.dumps(data)

        socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

        if aios_debug is True:
            Logger().print_debug("set_input_velocity_pt_group Send Data:", json_str)

    # get response
    response = {}
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        response.update({server_ip: {}})

    for i in range(len(server_ips)):
        try:
            data, address = socket_ctrl.recvfrom(1024)
            recv_ip, recv_port = address

            json_obj = json.loads(data.decode("utf-8"))

            if json_obj.get("status") == "OK":
                response.get(recv_ip).update({"data": json_obj})
            else:
                continue
            if recv_ip not in server_ips:
                # Logger().print_error("aios_v1.set_input_velocity_pt_group() receive wrong ip data: ",
                #                             recv_ip)
                continue

        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_error("aios_v1.set_input_velocity_pt_group() Didn't receive enough data! [Timeout]")
            continue

    # data parse
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        data = response.get(server_ip).get("data")

        if data:
            feedback = [data.get("position"), data.get("velocity"), data.get("current")]
        else:
            feedback = None

        response.get(server_ip).update({"feedback": feedback})

    # feedback
    positions = []
    velocitys = []
    currents = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        feedback = response.get(server_ip).get("feedback")

        if feedback is not None:
            positions.append(feedback[0])
            velocitys.append(feedback[1])
            currents.append(feedback[2])
        else:
            positions.append(None)
            velocitys.append(None)
            currents.append(None)

    return positions, velocitys, currents


# AIOSV1 current control
# parameter：current, server IP, motor number
# return position, speed, current
def set_current(current, reply_enable, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/m1/setCurrent',
        'current': 0,
    }
    data['reply_enable'] = reply_enable
    data['current'] = current
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

    if reply_enable:
        try:
            data, address = socket_ctrl.recvfrom(1024)

            if aios_debug is True:
                Logger().print_debug(f"AIOSV1 received from {address}:{data}")

            json_obj = json.loads(data.decode('utf-8'))

            if aios_debug is True:
                Logger().print_debug('AIOSV1', "Position = %.2f, Velocity = %.0f, Current = %.4f \n" % (

                    json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')))

            if json_obj.get('status') == 'OK':
                return address[0], json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')
            else:
                return None
        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


def set_current_group(server_ips, currents):
    # send request
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        current = currents[i]
        data = {
            "method": "SET",
            'reqTarget': '/m1/setCurrent',
            "reply_enable": True,
            "current": current,
        }
        json_str = json.dumps(data)

        socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

        if aios_debug is True:
            Logger().print_debug("set_input_torque_pt_group " + server_ip + " : Send Data:", json_str)

    # get response
    response = {}
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        response.update({server_ip: {}})

    for i in range(len(server_ips)):
        try:
            data, address = socket_ctrl.recvfrom(1024)
            recv_ip, recv_port = address

            json_obj = json.loads(data.decode("utf-8"))

            if json_obj.get("status") == "OK":
                response.get(recv_ip).update({"data": json_obj})
            else:
                continue

            if recv_ip not in server_ips:
                # Logger().print_error("aios_v1.set_input_torque_pt_group() receive wrong ip data: ",
                #                             recv_ip)
                continue

        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_error("aios_v1.set_input_torque_pt_group() Didn't receive enough data! [Timeout]")
            continue

    # data parse
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        data = response.get(server_ip).get("data")

        if data:
            feedback = [data.get("position"), data.get("velocity"), data.get("current")]
        else:
            feedback = None

        response.get(server_ip).update({"feedback": feedback})

    # feedback
    positions = []
    velocitys = []
    currents = []
    for i in range(len(server_ips)):
        server_ip = server_ips[i]
        feedback = response.get(server_ip).get("feedback")

        if feedback is not None:
            positions.append(feedback[0])
            velocitys.append(feedback[1])
            currents.append(feedback[2])
        else:
            positions.append(None)
            velocitys.append(None)
            currents.append(None)

    return positions, velocitys, currents


def receive_func():
    try:
        data, address = socket_ctrl.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        return True
    except socket.timeout:  # fail after 1 second of no activity
        return False
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


def receive_acvp():
    try:
        data, address = socket_ctrl.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))

        if json_obj.get('status') == 'OK':
            return address[0], json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')
        return True
    except socket.timeout:  # fail after 1 second of no activity
        return False
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# IO_Module set IO_State status
# parameter：PWM0_CH PWM1_CH SERVO0 SERVO1
# Parameter value range: PWM0_CH,PWM1_CH[0~65535], SERVO0,SERVO1[0~180]
# return AI0 AI1 DI0 DI1
def set_io_state(dict, reply_enable, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/IO_State',
        'reply_enable': True
    }
    data['reply_enable'] = reply_enable
    data['PWM0_CH'] = dict['PWM0_CH']
    data['PWM1_CH'] = dict['PWM1_CH']
    data['SERVO0'] = dict['SERVO0']
    data['SERVO1'] = dict['SERVO1']
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

    if reply_enable:
        try:
            data, address = socket_ctrl.recvfrom(1024)
            if aios_debug is True:
                Logger().print_debug(f"AIOSV1 received from {address}:{data}")

            # json_obj = json.loads(data.decode('utf-8'))
            # Logger().print_debug('AIOSV1', "Position = %.2f, Velocity = %.0f, Current = %.4f \n" %(json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')))
        except socket.timeout:  # fail after 1 second of no activity
            Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# IO_Module get IO_Staten status
# return data PWM0_CH,PWM1_CH[0~65535], SERVO0,SERVO1[0~180]
# return AI0[0~4096] AI1[0~4096] DI0[0,1] DI1[0,1] PWM0_CH,PWM1_CH[0~65535], SERVO0,SERVO1[0~180]
def get_io_state(server_ip):
    data = {
        'method': 'GET',
        'reqTarget': '/IO_State',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))

    try:
        data, address = socket_ctrl.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        # json_obj = json.loads(data.decode('utf-8'))
        # Logger().print_debug('AIOSV1', "Position = %.2f, Velocity = %.0f, Current = %.4f \n" %(json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# aios get network_setting status
# return data
def get_network_setting(server_ip):
    data = {
        'method': 'GET',
        'reqTarget': '/network_setting',
    }
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))

        if json_obj.get('status') == 'OK':
            return address[0], data.decode('utf-8')

        # json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# aios set network_setting status
# return data
def set_network_setting(dict, server_ip):
    data = {
        'method': 'SET',
        'reqTarget': '/network_setting',
        'DHCP_enable': 'True',
    }
    data['DHCP_enable'] = dict['DHCP_enable']
    data['SSID'] = dict['SSID']
    data['password'] = dict['password']
    data['name'] = dict['name']
    if dict['DHCP_enable'] == False:
        data['staticIP'] = dict['staticIP']
        data['gateway'] = dict['gateway']
        data['subnet'] = dict['subnet']
        data['dns_1'] = dict['dns_1']
        data['dns_2'] = dict['dns_2']
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_comm.sendto(str.encode(json_str), (server_ip, aios_port_comm))
    try:
        data, address = socket_comm.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        json_obj = json.loads(data.decode('utf-8'))
        if json_obj.get('status') == 'OK':
            return address[0], data.decode('utf-8')

        if aios_debug is True:
            Logger().print_debug('AIOSV1', "Position = %.2f, Velocity = %.0f, Current = %.4f \n" % (
                json_obj.get('position'), json_obj.get('velocity'), json_obj.get('current')))

    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 passthrough
# 参数：包括设备IP 电机号
# 无返回
def passthrough(server_ip, tx_messages):
    data = {
        'method': 'GET',
        'reqTarget': '/passthrough',
        'tx_messages': ''
    }
    data['tx_messages'] = tx_messages
    json_str = json.dumps(data)

    if aios_debug is True:
        Logger().print_debug(f"AIOSV1 Send JSON Obj: {json_str}")

    socket_ctrl.sendto(str.encode(json_str), (server_ip, aios_port_ctrl))
    try:
        data, address = socket_ctrl.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        # json_obj = json.loads(data.decode('utf-8'))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# AIOSV1 passthrough pt_port
# 参数：包括设备IP 电机号
# 无返回
def passthrough_fast(server_ip, tx_messages):
    if aios_debug is True:
        Logger().print_debug('AIOSV1', "Send Data:", tx_messages)

    socket_fast.sendto(tx_messages.encode('ascii'), (server_ip, aios_port_fast))
    try:
        data, address = socket_fast.recvfrom(1024)

        if aios_debug is True:
            Logger().print_debug(f"AIOSV1 received from {address}:{data}")

        # Logger().print_debug('AIOSV1', 'Server received from {}:{}'.format(address, data.hex()))
    except socket.timeout:  # fail after 1 second of no activity
        Logger().print_warning("AIOSV1 Didn't receive anymore data! [Timeout]")


# 广播查询局域网下的全部 AIOSV1
# 参数：无
# 返回 成功 失败 超时
def broadcast_func():
    timeout = 3
    found_server = False
    address_list = []

    start = time.time()
    socket_comm.sendto('Is any AIOSV1 server here?'.encode('utf-8'), (aios_network, aios_port_comm))

    if aios_debug is True:
        Logger().print_debug('AIOSV1', '\n')

    while True:
        try:
            data, address = socket_comm.recvfrom(1024)
            latency = time.time() - start

            if aios_debug is True:
                Logger().print_debug('AIOSV1', latency * 1000)

            address_list.append(address[0])

            if aios_debug is True:
                Logger().print_debug(f"AIOSV1 received from {address}:{data}")

            # json_obj = json.loads(data.decode('utf-8'))
            found_server = True
        except socket.timeout:  # fail after 1 second of no activity
            if found_server:
                if aios_debug is True:
                    Logger().print_debug('AIOSV1', '\n')
                    Logger().print_debug('AIOSV1', 'found servers')
                    Logger().print_debug('AIOSV1', address_list)
                    Logger().print_debug('AIOSV1', 'lookup Finished! \n')

                time.sleep(2)
                return address_list
            else:
                Logger().print_warning('AIOSV1', ' broadcast_func ', "Do not have any server! [Timeout] \n")
                return False
            break

    if aios_debug is True:
        Logger().print_debug('AIOSV1', '\n')
