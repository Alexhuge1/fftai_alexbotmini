class HardwareConfig:
    def __init__(self):
        self.parameters = {
            "device_connected": True,
            "cpu": "x64",
            "system": "Linux",
            "hardware_layer": "fourier-core-hardware",
            "fi_fsa": {
                "version": "v1",
            },
            "fi_fse": {
                "version": "v1",
            },
        }


gl_config = HardwareConfig()
