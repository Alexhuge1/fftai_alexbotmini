from .fi_hardware_predefine import FunctionResult
from .fi_hardware_logger import Logger
from .fi_hardware_base import HardwareBase


class HardwareConnect(HardwareBase):
    def __init__(self):
        super().__init__()

    # -------------------------------------------------------------------------

    from .fi_hardware_fi_fse import (
        fi_fse_init,
        fi_fse_comm,
        fi_fse_check,
        ################################
        fi_fse_get_measured,
        fi_fse_get_angle,
        fi_fse_get_radian,
    )

    from .fi_hardware_fi_fsa import (
        fi_fsa_init,
        fi_fsa_comm,
        fi_fsa_check,
        fi_fsa_subscribe,
        ################################
        fi_fsa_set_config,
        fi_fsa_get_pvc,
        fi_fsa_get_pvct,
        fi_fsa_get_error,
        fi_fsa_set_control_pid,
        fi_fsa_set_control_pd,
        fi_fsa_set_control_param,
        fi_fsa_set_control_mode,
        fi_fsa_set_position_control,
        fi_fsa_set_velocity_control,
        fi_fsa_set_torque_control,
        fi_fsa_set_current_control,
        fi_fsa_set_pd_control,
        fi_fsa_set_servo_on,
        fi_fsa_set_servo_off,
        fi_fsa_set_servo_reboot,
        fi_fsa_set_servo_zero,
        fi_fsa_set_clear_fault,
        fi_fsa_set_servo_on_group,
        fi_fsa_set_servo_off_group,
        fi_fsa_set_servo_reboot_group,
        fi_fsa_set_clear_fault_group,
        fi_fsa_get_pvc_group,
        fi_fsa_get_pvct_group,
        fi_fsa_get_error_group,
        fi_fsa_set_control_mode_group,
        fi_fsa_set_position_control_group,
        fi_fsa_set_velocity_control_group,
        fi_fsa_set_torque_control_group,
        fi_fsa_set_current_control_group,
        fi_fsa_set_pd_control_group,
        ################################
        fi_fsa_get_absolute_position,
        fi_fsa_set_absolute_zero,
        ################################
        fi_fsa_set_servo_on_fast,
        fi_fsa_set_servo_off_fast,
        fi_fsa_set_clear_fault_fast,
        fi_fsa_set_control_mode_fast,
        fi_fsa_set_position_control_fast,
        fi_fsa_set_velocity_control_fast,
        fi_fsa_set_torque_control_fast,
        fi_fsa_set_current_control_fast,
        fi_fsa_set_pd_control_fast,
        fi_fsa_get_pvc_fast,
        fi_fsa_get_pvct_fast,
        fi_fsa_get_error_fast,
        fi_fsa_set_control_pid_fast,
        fi_fsa_set_control_pd_fast,
        fi_fsa_set_servo_on_fast_group,
        fi_fsa_set_servo_off_fast_group,
        fi_fsa_set_clear_fault_fast_group,
        fi_fsa_set_control_mode_fast_group,
        fi_fsa_set_position_control_fast_group,
        fi_fsa_set_velocity_control_fast_group,
        fi_fsa_set_torque_control_fast_group,
        fi_fsa_set_current_control_fast_group,
        fi_fsa_set_pd_control_fast_group,
        fi_fsa_get_pvc_fast_group,
        fi_fsa_get_pvct_fast_group,
        fi_fsa_get_error_fast_group,
    )

    # -------------------------------------------------------------------------

    from .fi_hardware_ethernet_wsu import (
        ethernet_wsu_get_key_state,
    )

    from .fi_hardware_ethernet_asu import (
        ethernet_asu_get_adc_value,
    )

    from .fi_hardware_ethernet_imu import (
        ethernet_imu_get_angle_degree,
        ethernet_imu_get_acceleration,
        ethernet_imu_get_angular_velocity,
        ethernet_imu_get_magnetometer,
    )

    from .fi_hardware_ethernet_bisu import (
        ethernet_bisu_get_key_state,
        ethernet_bisu_get_magnetometer,
        ethernet_bisu_get_acceleration,
        ethernet_bisu_get_angular_velocity,
        ethernet_bisu_get_angle_degree,
    )

    from .fi_hardware_ethernet_ioboard import (
        ethernet_ioboard_fi_ioboard_typea_init,
        ethernet_ioboard_fi_ioboard_typea_get_info,
        ethernet_ioboard_fi_ioboard_typea_set_led,
        ethernet_ioboard_fi_ioboard_typea_get_xxx,
        ethernet_ioboard_fi_ioboard_typea_set_xxx,
    )

    # -------------------------------------------------------------------------

    def usb_imu_taobotics_init(self, usb):
        Logger().print_info(f"USB_IMU init: {usb}...")
        return FunctionResult.SUCCESS

    def usb_imu_taobotics_comm(self, usb):
        return FunctionResult.SUCCESS

    def usb_imu_taobotics_upload(self, usb):
        return FunctionResult.SUCCESS

    def usb_imu_taobotics_get_quat(self, usb):
        return [0, 0, 0, 0]

    def usb_imu_taobotics_get_angle(self, usb):
        return [0, 0, 0]

    def usb_imu_taobotics_get_acceleration(self, usb):
        return [0, 0, 0]

    def usb_imu_taobotics_get_angular_velocity(self, usb):
        return [0, 0, 0]

    # -------------------------------------------------------------------------

    def usb_imu_hipnuc_init(self, usb):
        Logger().print_info(f"USB_IMU init: {usb}...")
        return FunctionResult.SUCCESS

    def usb_imu_hipnuc_comm(self, usb, enable=True, frequency=100):
        return FunctionResult.SUCCESS

    def usb_imu_hipnuc_upload(self, usb):
        return FunctionResult.SUCCESS

    def usb_imu_hipnuc_get_quat(self, usb):
        return [0, 0, 0, 0]

    def usb_imu_hipnuc_get_angle(self, usb):
        return [0, 0, 0]

    def usb_imu_hipnuc_get_acceleration(self, usb):
        return [0, 0, 0]

    def usb_imu_hipnuc_get_angular_velocity(self, usb):
        return [0, 0, 0]

    # -------------------------------------------------------------------------

    from .fi_hardware_fd_aios import (
        fd_aios_init,
        fd_aios_comm,
        fd_aios_check,
        fd_aios_subscribe,
        ################################
        fd_aios_get_pvc,
        fd_aios_get_pvct,
        fd_aios_get_error,
        fd_aios_set_control_pid,
        fd_aios_set_control_pd,
        fd_aios_set_control_mode,
        fd_aios_set_position_control,
        fd_aios_set_velocity_control,
        fd_aios_set_torque_control,
        fd_aios_set_current_control,
        fd_aios_set_pd_control,
        fd_aios_set_servo_on,
        fd_aios_set_servo_off,
        fd_aios_set_servo_reboot,
        fd_aios_set_clear_fault,
        fd_aios_set_servo_on_group,
        fd_aios_set_servo_off_group,
        fd_aios_set_servo_reboot_group,
        fd_aios_set_clear_fault_group,
        fd_aios_get_pvc_group,
        fd_aios_get_pvct_group,
        fd_aios_get_error_group,
        fd_aios_set_control_mode_group,
        fd_aios_set_position_control_group,
        fd_aios_set_velocity_control_group,
        fd_aios_set_torque_control_group,
        fd_aios_set_current_control_group,
        fd_aios_set_pd_control_group,
        ################################
        fd_aios_get_absolute_position,
        fd_aios_set_absolute_zero,
        ################################
        fd_aios_set_servo_on_fast,
        fd_aios_set_servo_off_fast,
        fd_aios_set_clear_fault_fast,
        fd_aios_set_control_mode_fast,
        fd_aios_set_position_control_fast,
        fd_aios_set_velocity_control_fast,
        fd_aios_set_torque_control_fast,
        fd_aios_set_current_control_fast,
        fd_aios_set_pd_control_fast,
        fd_aios_get_pvc_fast,
        fd_aios_get_pvct_fast,
        fd_aios_get_error_fast,
        fd_aios_set_control_pid_fast,
        fd_aios_set_control_pd_fast,
        fd_aios_set_servo_on_fast_group,
        fd_aios_set_servo_off_fast_group,
        fd_aios_set_clear_fault_fast_group,
        fd_aios_set_control_mode_fast_group,
        fd_aios_set_position_control_fast_group,
        fd_aios_set_velocity_control_fast_group,
        fd_aios_set_torque_control_fast_group,
        fd_aios_set_current_control_fast_group,
        fd_aios_set_pd_control_fast_group,
        fd_aios_get_pvc_fast_group,
        fd_aios_get_pvct_fast_group,
        fd_aios_get_error_fast_group,
    )

    # -------------------------------------------------------------------------
