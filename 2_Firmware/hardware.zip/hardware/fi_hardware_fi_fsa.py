import numpy
from collections.abc import Iterable

from .fi_hardware_predefine import FunctionResult
from .fi_hardware_logger import Logger
from .fi_hardware_import import (
    fi_fsa,
)


# -------------------------------------------------------------------------
# FSA absolute encoder related functions
def fi_fsa_get_absolute_position(self, ip):
    result = fi_fsa.get_absolute_position(server_ip=ip)
    return result


def fi_fsa_set_absolute_zero(self, ip):
    fi_fsa.set_absolute_zero(server_ip=ip)
    return FunctionResult.SUCCESS


# -------------------------------------------------------------------------

def fi_fsa_init(self, ip):
    Logger().print_info(f"FI FSA init: {ip}...")
    fi_fsa.init(server_ip=ip)
    return FunctionResult.SUCCESS


def fi_fsa_comm(self, ip, enable=True):
    fi_fsa.comm(server_ip=ip, enable=enable)
    return FunctionResult.SUCCESS


def fi_fsa_check(self, ip):
    result = fi_fsa.check(server_ip=ip)
    return result


def fi_fsa_subscribe(self, ip, enable=False):
    result = fi_fsa.subscribe(server_ip=ip, enable=enable)
    return result


def fi_fsa_set_config(self,
                      ip,
                      actuator_type=None,
                      actuator_comm_hardware_type=None,
                      actuator_direction=None,
                      actuator_reduction_ratio=None,
                      motor_type=None,
                      motor_hardware_type=None,
                      motor_vbus=None,
                      motor_direction=None,
                      motor_max_speed=None,
                      motor_max_acceleration=None,
                      motor_max_current=None,
                      ):
    fi_fsa.set_config(server_ip=ip,
                      actuator_type=actuator_type,
                      actuator_comm_hardware_type=actuator_comm_hardware_type,
                      actuator_direction=actuator_direction,
                      actuator_reduction_ratio=actuator_reduction_ratio,
                      motor_type=motor_type,
                      motor_hardware_type=motor_hardware_type,
                      motor_vbus=motor_vbus,
                      motor_direction=motor_direction,
                      motor_max_speed=motor_max_speed,
                      motor_max_acceleration=motor_max_acceleration,
                      motor_max_current=motor_max_current,
                      )
    return FunctionResult.SUCCESS


def fi_fsa_get_pvc(self, ip):
    result = fi_fsa.get_pvc(server_ip=ip)

    position = None
    velocity = None
    current = None
    timeout = None

    if result is not None and isinstance(result, Iterable):
        position, velocity, current, timeout = result

    return position, velocity, current, timeout


def fi_fsa_get_pvct(self, ip):
    result = fi_fsa.get_pvct(server_ip=ip)

    position = None
    velocity = None
    current = None
    torque = None
    timeout = None

    if result is not None and isinstance(result, Iterable):
        position, velocity, current, torque, timeout = result

    return position, velocity, current, torque, timeout


def fi_fsa_get_error(self, ip):
    result = fi_fsa.get_error_code(server_ip=ip)
    return FunctionResult.SUCCESS


def fi_fsa_set_control_pid(
        self,
        ip,
        position_control_kp=None,
        velocity_control_kp=None,
        velocity_control_ki=None,
) -> FunctionResult:
    # support version above v1.0
    # support version above v2.0
    result = fi_fsa.set_pid_param_imm(
        server_ip=ip,
        control_position_kp=position_control_kp,
        control_velocity_kp=velocity_control_kp,
        control_velocity_ki=velocity_control_ki,
    )

    return result


def fi_fsa_set_control_pd(
        self,
        ip,
        pd_control_kp=None,
        pd_control_kd=None,
) -> FunctionResult:
    # support version above v1.0
    # support version above v2.0
    result = fi_fsa.set_pid_param_imm(
        server_ip=ip,
        control_pd_kp=pd_control_kp,
        control_pd_kd=pd_control_kd,
    )

    return result


def fi_fsa_set_control_param(
        self,
        ip,
        motor_max_speed=None,
        motor_max_acceleration=None,
        motor_max_current=None,
) -> FunctionResult:
    result = fi_fsa.set_control_param_imm(
        server_ip=ip,
        motor_max_speed=motor_max_speed,
        motor_max_acceleration=motor_max_acceleration,
        motor_max_current=motor_max_current,
    )
    return result


def fi_fsa_set_control_mode(self, ip, control_mode):
    fi_fsa.set_mode_of_operation(
        server_ip=ip,
        mode_of_operation=control_mode,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_position_control(self, ip, command_position, velocity_ff=0.0, current_ff=0.0):
    fi_fsa.set_position_control(
        server_ip=ip,
        position=command_position,
        velocity_ff=velocity_ff,
        current_ff=current_ff,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_velocity_control(self, ip, command_velocity, current_ff=0.0):
    fi_fsa.set_velocity_control(
        server_ip=ip,
        velocity=command_velocity,
        current_ff=current_ff,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_torque_control(self, ip, command_torque):
    fi_fsa.set_torque_control(
        server_ip=ip,
        torque=command_torque,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_current_control(self, ip, command_current):
    fi_fsa.set_current_control(
        server_ip=ip,
        current=command_current,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_pd_control(self, ip, command_position):
    fi_fsa.set_pd_control(
        server_ip=ip,
        position=command_position,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_servo_on(self, ip):
    fi_fsa.set_enable(server_ip=ip)
    return FunctionResult.SUCCESS


def fi_fsa_set_servo_off(self, ip):
    fi_fsa.set_disable(server_ip=ip)
    return FunctionResult.SUCCESS


def fi_fsa_set_servo_reboot(self, ip):
    fi_fsa.reboot(server_ip=ip)
    return FunctionResult.SUCCESS


def fi_fsa_set_servo_zero(self, ip):
    fi_fsa.set_zero(server_ip=ip)
    return FunctionResult.SUCCESS


def fi_fsa_set_clear_fault(self, ip):
    fi_fsa.set_clear_fault(server_ip=ip)
    return FunctionResult.SUCCESS


# -------------------------------------------------------------------------

def fi_fsa_set_servo_on_group(self, ips):
    fi_fsa.set_enable_group(server_ips=ips)
    return FunctionResult.SUCCESS


def fi_fsa_set_servo_off_group(self, ips):
    fi_fsa.set_disable_group(server_ips=ips)
    return FunctionResult.SUCCESS


def fi_fsa_set_servo_reboot_group(self, ips):
    for ip in ips:
        fi_fsa.reboot(server_ip=ip)
    return FunctionResult.SUCCESS


def fi_fsa_set_clear_fault_group(self, ips):
    fi_fsa.set_clear_fault_group(server_ips=ips)
    return FunctionResult.SUCCESS


def fi_fsa_get_pvc_group(self, ips):
    result = fi_fsa.get_pvc_group(server_ips=ips)

    positions = None
    velocities = None
    currents = None
    timeouts = None

    if result is not None and isinstance(result, Iterable):
        positions, velocities, currents, timeouts = result

    return positions, velocities, currents, timeouts


def fi_fsa_get_pvct_group(self, ips):
    result = fi_fsa.get_pvct_group(server_ips=ips)

    positions = None
    velocities = None
    currents = None
    torques = None
    timeouts = None

    if result is not None and isinstance(result, Iterable):
        positions, velocities, currents, torques, timeouts = result

    return positions, velocities, currents, torques, timeouts


def fi_fsa_get_error_group(self, ips):
    error_codes = fi_fsa.get_error_code_group(server_ips=ips)

    if error_codes is not None:
        return error_codes
    return FunctionResult.FAIL


def fi_fsa_set_control_mode_group(self, ips, control_modes):
    fi_fsa.set_mode_of_operation_group(
        server_ips=ips,
        mode_of_operations=control_modes
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_position_control_group(self, ips, command_positions):
    fi_fsa.set_position_control_group(
        server_ips=ips,
        positions=command_positions,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_velocity_control_group(self, ips, command_velocities):
    fi_fsa.set_velocity_control_group(
        server_ips=ips,
        velocities=command_velocities,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_torque_control_group(self, ips, command_torques):
    fi_fsa.set_torque_control_group(
        server_ips=ips,
        torques=command_torques
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_current_control_group(self, ips, command_currents):
    fi_fsa.set_current_control_group(
        server_ips=ips,
        currents=command_currents
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_pd_control_group(self, ips, command_positions):
    fi_fsa.set_pd_control_group(
        server_ips=ips,
        positions=command_positions
    )
    return FunctionResult.SUCCESS


# -------------------------------------------------------------------------

def fi_fsa_set_servo_on_fast(self, ip):
    fi_fsa.fast_set_enable(server_ip=ip)
    return FunctionResult.SUCCESS


def fi_fsa_set_servo_off_fast(self, ip):
    fi_fsa.fast_set_disable(server_ip=ip)
    return FunctionResult.SUCCESS


def fi_fsa_set_clear_fault_fast(self, ip):
    fi_fsa.fast_set_clear_fault(server_ip=ip)
    return FunctionResult.SUCCESS


def fi_fsa_set_control_mode_fast(self, ip, control_mode):
    fi_fsa.fast_set_mode_of_operation(server_ip=ip, mode_of_operation=control_mode)
    return FunctionResult.SUCCESS


def fi_fsa_set_position_control_fast(self, ip, command_position, velocity_ff=0.0, current_ff=0.0):
    fi_fsa.fast_set_position_control(
        server_ip=ip,
        position=command_position,
        velocity_ff=velocity_ff,
        current_ff=current_ff,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_velocity_control_fast(self, ip, command_velocity, current_ff=0.0):
    fi_fsa.fast_set_velocity_control(server_ip=ip, velocity=command_velocity, current_ff=current_ff)
    return FunctionResult.SUCCESS


def fi_fsa_set_torque_control_fast(self, ip, command_torque):
    fi_fsa.fast_set_torque_control(server_ip=ip, torque=command_torque)
    return FunctionResult.SUCCESS


def fi_fsa_set_current_control_fast(self, ip, command_current):
    fi_fsa.fast_set_current_control(server_ip=ip, current=command_current)
    return FunctionResult.SUCCESS


def fi_fsa_set_pd_control_fast(self, ip, command_position):
    fi_fsa.fast_set_pd_control(server_ip=ip, position=command_position)
    return FunctionResult.SUCCESS


def fi_fsa_get_pvc_fast(self, ip):
    result = fi_fsa.fast_get_pvc(server_ip=ip)

    position = None
    velocity = None
    current = None
    timeout = 0

    if result is not None and isinstance(result, Iterable):
        position, velocity, current, timeout = result
    else:
        timeout = 1

    return position, velocity, current, timeout


def fi_fsa_get_pvct_fast(self, ip):
    result = fi_fsa.fast_get_pvct(server_ip=ip)

    position = None
    velocity = None
    current = None
    torque = None
    timeout = 0

    if result is not None and isinstance(result, Iterable):
        position, velocity, current, torque, timeout = result
    else:
        timeout = 1

    return position, velocity, current, torque, timeout


def fi_fsa_get_error_fast(self, ip):
    result = fi_fsa.fast_get_error(server_ip=ip)

    error = None
    if result is not None:
        error = result

    return error


def fi_fsa_set_control_pid_fast(
        self,
        ip,
        position_control_kp=None,
        velocity_control_kp=None,
        velocity_control_ki=None):
    result = fi_fsa.fast_set_pid_param_imm(
        server_ip=ip,
        position_control_kp=position_control_kp,
        velocity_control_kp=velocity_control_kp,
        velocity_control_ki=velocity_control_ki,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_control_pd_fast(
        self,
        ip,
        pd_control_kp=None,
        pd_control_kd=None):
    result = fi_fsa.fast_set_pd_param_imm(
        server_ip=ip,
        pd_control_kp=pd_control_kp,
        pd_control_kd=pd_control_kd,
    )
    return FunctionResult.SUCCESS


# -------------------------------------------------------------------------

def fi_fsa_set_servo_on_fast_group(self, ips):
    fi_fsa.fast_set_enable_group(server_ips=ips)
    return FunctionResult.SUCCESS


def fi_fsa_set_servo_off_fast_group(self, ips):
    fi_fsa.fast_set_disable_group(server_ips=ips)
    return FunctionResult.SUCCESS


def fi_fsa_set_clear_fault_fast_group(self, ips):
    fi_fsa.fast_set_clear_fault_group(server_ips=ips)
    return FunctionResult.SUCCESS


def fi_fsa_set_control_mode_fast_group(self, ips, control_modes):
    fi_fsa.fast_set_mode_of_operation_group(server_ips=ips, mode_of_operations=control_modes)
    return FunctionResult.SUCCESS


def fi_fsa_set_position_control_fast_group(self, ips, command_positions):
    fi_fsa.fast_set_position_control_group(
        server_ips=ips,
        positions=command_positions,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_velocity_control_fast_group(self, ips, command_velocities):
    fi_fsa.fast_set_velocity_control_group(
        server_ips=ips,
        velocities=command_velocities,
    )
    return FunctionResult.SUCCESS


def fi_fsa_set_torque_control_fast_group(self, ips, command_torques):
    fi_fsa.fast_set_torque_control_group(server_ips=ips, torques=command_torques)
    return FunctionResult.SUCCESS


def fi_fsa_set_current_control_fast_group(self, ips, command_currents):
    fi_fsa.fast_set_current_control_group(server_ips=ips, currents=command_currents)
    return FunctionResult.SUCCESS


def fi_fsa_set_pd_control_fast_group(self, ips, command_positions):
    fi_fsa.fast_set_pd_control_group(server_ips=ips, positions=command_positions)
    return FunctionResult.SUCCESS


def fi_fsa_get_pvc_fast_group(self, ips):
    result = fi_fsa.fast_get_pvc_group(server_ips=ips)

    positions = [None] * len(ips)
    velocities = [None] * len(ips)
    currents = [None] * len(ips)
    timeouts = [0] * len(ips)

    if result is not None and isinstance(result, Iterable):
        positions, velocities, currents, timeouts = result
    else:
        timeouts = [1] * len(ips)

    return positions, velocities, currents, timeouts


def fi_fsa_get_pvct_fast_group(self, ips):
    result = fi_fsa.fast_get_pvct_group(server_ips=ips)

    positions = [None] * len(ips)
    velocities = [None] * len(ips)
    currents = [None] * len(ips)
    torques = [None] * len(ips)
    timeouts = [0] * len(ips)

    if result is not None and isinstance(result, Iterable):
        positions, velocities, currents, torques, timeouts = result
    else:
        timeouts = [1] * len(ips)

    return positions, velocities, currents, torques, timeouts


def fi_fsa_get_error_fast_group(self, ips):
    result = fi_fsa.fast_get_error_group(server_ips=ips)

    errors = None
    if result is not None:
        errors = result

    return errors
