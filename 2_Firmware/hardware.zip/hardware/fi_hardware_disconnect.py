from .fi_hardware_logger import Logger
from .fi_hardware_predefine import FunctionResult
from .fi_hardware_base import HardwareBase


class HardwareDisconnect(HardwareBase):
    def __init__(self):
        super().__init__()

    # -------------------------------------------------------------------------

    def fi_fse_init(self, ip):
        return FunctionResult.SUCCESS

    def fi_fse_comm(self, ip, enable=True):
        return FunctionResult.SUCCESS

    def fi_fse_check(self, ip):
        return FunctionResult.SUCCESS

    def fi_fse_get_measured(self, ip):
        return (0, 0)  # angle, radian

    def fi_fse_get_angle(self, ip):
        return 0

    def fi_fse_get_radian(self, ip):
        return 0

    # -------------------------------------------------------------------------

    def fi_fsa_init(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_comm(self, ip, enable=True):
        return FunctionResult.SUCCESS

    def fi_fsa_check(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_subscribe(self, ip, enable=False):
        return FunctionResult.SUCCESS

    def fi_fsa_set_config(self,
                          ip,
                          actuator_type=None,
                          actuator_comm_hardware_type=None,
                          actuator_direction=None,
                          actuator_reduction_ratio=None,
                          motor_type=None,
                          motor_hardware_type=None,
                          motor_vbus=None,
                          motor_direction=None,
                          motor_max_speed=None,
                          motor_max_acceleration=None,
                          motor_max_current=None,
                          ):
        return FunctionResult.SUCCESS

    def fi_fsa_get_pvc(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_get_pvct(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_get_error(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_control_pid(
            self,
            ip,
            position_control_kp=None,
            velocity_control_kp=None,
            velocity_control_ki=None,
    ) -> FunctionResult:
        return FunctionResult.SUCCESS

    def fi_fsa_set_control_pd(
            self,
            ip,
            pd_control_kp=None,
            pd_control_kd=None,
    ) -> FunctionResult:
        return FunctionResult.SUCCESS

    def fi_fsa_set_control_param(
            self,
            ip,
            motor_max_speed=None,
            motor_max_acceleration=None,
            motor_max_current=None,
    ) -> FunctionResult:
        return FunctionResult.SUCCESS

    def fi_fsa_set_control_mode(self, ip, control_mode):
        return FunctionResult.SUCCESS

    def fi_fsa_set_position_control(self, ip, command_position, velocity_ff=0.0, current_ff=0.0):
        return FunctionResult.SUCCESS

    def fi_fsa_set_velocity_control(self, ip, command_velocity, current_ff=0.0):
        return FunctionResult.SUCCESS

    def fi_fsa_set_torque_control(self, ip, command_torque):
        return FunctionResult.SUCCESS

    def fi_fsa_set_current_control(self, ip, command_current):
        return FunctionResult.SUCCESS

    def fi_fsa_set_pd_control(self, ip, command_position):
        return FunctionResult.SUCCESS

    def fi_fsa_set_servo_on(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_servo_off(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_servo_zero(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_servo_reboot(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_clear_fault(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_servo_on_group(self, ips):
        return FunctionResult.SUCCESS

    def fi_fsa_set_servo_off_group(self, ips):
        return FunctionResult.SUCCESS

    def fi_fsa_set_servo_reboot_group(self, ips):
        return FunctionResult.SUCCESS

    def fi_fsa_set_clear_fault_group(self, ips):
        return FunctionResult.SUCCESS

    def fi_fsa_get_pvc_group(self, ips):
        return FunctionResult.SUCCESS

    def fi_fsa_get_pvct_group(self, ips):
        return FunctionResult.SUCCESS

    def fi_fsa_get_error_group(self, ips):
        return FunctionResult.FAIL

    def fi_fsa_set_control_mode_group(self, ips, control_modes):
        return FunctionResult.SUCCESS

    def fi_fsa_set_position_control_group(self, ips, command_positions):
        return FunctionResult.SUCCESS

    def fi_fsa_set_velocity_control_group(self, ips, command_velocities):
        return FunctionResult.SUCCESS

    def fi_fsa_set_torque_control_group(self, ips, command_torques):
        return FunctionResult.SUCCESS

    def fi_fsa_set_current_control_group(self, ips, command_currents):
        return FunctionResult.SUCCESS

    def fi_fsa_set_pd_control_group(self, ips, command_positions):
        return FunctionResult.SUCCESS

    def fi_fsa_get_absolute_position(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_absolute_zero(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_servo_on_fast(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_servo_off_fast(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_clear_fault_fast(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_control_mode_fast(self, ip, control_mode):
        return FunctionResult.SUCCESS

    def fi_fsa_set_position_control_fast(self, ip, command_position, velocity_ff=0.0, current_ff=0.0):
        return FunctionResult.SUCCESS

    def fi_fsa_set_velocity_control_fast(self, ip, command_velocity, current_ff=0.0):
        return FunctionResult.SUCCESS

    def fi_fsa_set_torque_control_fast(self, ip, command_torque):
        return FunctionResult.SUCCESS

    def fi_fsa_set_current_control_fast(self, ip, command_current):
        return FunctionResult.SUCCESS

    def fi_fsa_set_pd_control_fast(self, ip, command_position):
        return FunctionResult.SUCCESS

    def fi_fsa_get_pvc_fast(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_get_pvct_fast(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_get_error_fast(self, ip):
        return FunctionResult.SUCCESS

    def fi_fsa_set_control_pid_fast(
            self,
            ip,
            position_control_kp=None,
            velocity_control_kp=None,
            velocity_control_ki=None):
        return FunctionResult.SUCCESS

    def fi_fsa_set_control_pd_fast(
            self,
            ip,
            pd_control_kp=None,
            pd_control_kd=None):
        return FunctionResult.SUCCESS

    def fi_fsa_set_servo_on_fast_group(self, ips):
        return FunctionResult.SUCCESS

    def fi_fsa_set_servo_off_fast_group(self, ips):
        return FunctionResult.SUCCESS

    def fi_fsa_set_clear_fault_fast_group(self, ips):
        return FunctionResult.SUCCESS

    def fi_fsa_set_control_mode_fast_group(self, ips, control_modes):
        return FunctionResult.SUCCESS

    def fi_fsa_set_position_control_fast_group(self, ips, command_positions):
        return FunctionResult.SUCCESS

    def fi_fsa_set_velocity_control_fast_group(self, ips, command_velocitys):
        return FunctionResult.SUCCESS

    def fi_fsa_set_torque_control_fast_group(self, ips, command_torques):
        return FunctionResult.SUCCESS

    def fi_fsa_set_pd_control_fast_group(self, ips, command_positions):
        return FunctionResult.SUCCESS

    def fi_fsa_get_pvc_fast_group(self, ips):
        return FunctionResult.SUCCESS

    def fi_fsa_get_pvct_fast_group(self, ips):
        return FunctionResult.SUCCESS

    def fi_fsa_get_error_fast_group(self, ips):
        return FunctionResult.SUCCESS

    # -------------------------------------------------------------------------

    def ethernet_wsu_get_key_state(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_asu_get_adc_value(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_imu_get_angle_degree(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_imu_get_acceleration(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_imu_get_angular_velocity(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_imu_get_magnetometer(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_bisu_get_key_state(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_bisu_get_angle_degree(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_bisu_get_acceleration(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_bisu_get_angular_velocity(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_bisu_get_magnetometer(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_ioboard_fi_ioboard_typea_init(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_ioboard_fi_ioboard_typea_set_xxx(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_ioboard_fi_ioboard_typea_set_led(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_ioboard_fi_ioboard_typea_get_xxx(self, ip):
        return FunctionResult.SUCCESS

    def ethernet_ioboard_fi_ioboard_typea_get_info(self, ip):
        return FunctionResult.SUCCESS

    # -------------------------------------------------------------------------

    def usb_imu_taobotics_init(self, usb):
        Logger().print_info(f"USB_IMU init: {usb}...")
        return FunctionResult.SUCCESS

    def usb_imu_taobotics_comm(self, usb):
        return FunctionResult.SUCCESS

    def usb_imu_taobotics_upload(self, usb):
        return FunctionResult.SUCCESS

    def usb_imu_taobotics_get_quat(self, usb):
        return [0, 0, 0, 0]

    def usb_imu_taobotics_get_angle(self, usb):
        return [0, 0, 0]

    def usb_imu_taobotics_get_acceleration(self, usb):
        return [0, 0, 0]

    def usb_imu_taobotics_get_angular_velocity(self, usb):
        return [0, 0, 0]

    # -------------------------------------------------------------------------

    def usb_imu_hipnuc_init(self, usb):
        Logger().print_info(f"USB_IMU init: {usb}...")
        return FunctionResult.SUCCESS

    def usb_imu_hipnuc_comm(self, usb, enable=True, frequency=100):
        return FunctionResult.SUCCESS

    def usb_imu_hipnuc_upload(self, usb):
        return FunctionResult.SUCCESS

    def usb_imu_hipnuc_get_quat(self, usb):
        return [0, 0, 0, 0]

    def usb_imu_hipnuc_get_angle(self, usb):
        return [0, 0, 0]

    def usb_imu_hipnuc_get_acceleration(self, usb):
        return [0, 0, 0]

    def usb_imu_hipnuc_get_angular_velocity(self, usb):
        return [0, 0, 0]

    # -------------------------------------------------------------------------
