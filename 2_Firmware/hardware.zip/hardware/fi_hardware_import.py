try:
    from fourier_core.config.fi_config import gl_config
except ImportError:
    from .fi_hardware_config import gl_config

from .fi_hardware_predefine import FunctionResult
from .fi_hardware_logger import Logger

# =============================================================================

if gl_config.parameters.get("hardware_layer") == "fourier-core":
    if gl_config.parameters.get("fi_fse", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core.hardware.fi.fi_fse_v1 as fi_fse
    else:
        Logger().print_debug("fi_fse version is not set, default version will be imported")
        import fourier_core.hardware.fi.fi_fse_v1 as fi_fse

    if gl_config.parameters.get("fi_fsa", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core.hardware.fi.fi_fsa_v1 as fi_fsa
    elif gl_config.parameters.get("fi_fsa", {}).get("version", "UNKNOWN") == "v1_9":
        import fourier_core.hardware.fi.fi_fsa_v1_9 as fi_fsa
    elif gl_config.parameters.get("fi_fsa", {}).get("version", "UNKNOWN") == "v2":
        import fourier_core.hardware.fi.fi_fsa_v2 as fi_fsa
    elif gl_config.parameters.get("fi_fsa", {}).get("version", "UNKNOWN") == "v2_subscribe":
        import fourier_core.hardware.fi.fi_fsa_v2_subscribe as fi_fsa
    else:
        Logger().print_debug("fi_fsa version is not set, default version will be imported")
        import fourier_core.hardware.fi.fi_fsa_v1 as fi_fsa

    if gl_config.parameters.get("fi_ioboard_typea", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core.hardware.fi.fi_ioboard_typea as fi_ioboard_typea
    else:
        Logger().print_debug("fi_ioboard_typea version is not set, default version will be imported")
        import fourier_core.hardware.fi.fi_ioboard_typea as fi_ioboard_typea

    if gl_config.parameters.get("fi_sensor_ethernet", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core.hardware.fi.fi_sensor_ethernet as fi_sensor_ethernet
    else:
        Logger().print_debug("fi_sensor_ethernet version is not set, default version will be imported")
        import fourier_core.hardware.fi.fi_sensor_ethernet as fi_sensor_ethernet

    if gl_config.parameters.get("hipnuc_imu_usb", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core.hardware.hipnuc.hipnuc_imu_usb_ischedule as hipnuc_imu_usb
    else:
        Logger().print_debug("hipnuc_imu_usb version is not set, default version will be imported")
        import fourier_core.hardware.hipnuc.hipnuc_imu_usb_ischedule as hipnuc_imu_usb

    if gl_config.parameters.get("taobotics_imu_usb", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core.hardware.taobotics.taobotics_imu_usb_ischedule as taobotics_imu_usb
    else:
        Logger().print_debug("taobotics_imu_usb version is not set, default version will be imported")
        import fourier_core.hardware.taobotics.taobotics_imu_usb_ischedule as taobotics_imu_usb

    if gl_config.parameters.get("fd_aios", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core.hardware.fd.fd_aios_v1 as fd_aios
    elif gl_config.parameters.get("fd_aios", {}).get("version", "UNKNOWN") == "v2":
        import fourier_core.hardware.fd.fd_aios_v2 as fd_aios
    else:
        Logger().print_debug("fd_aios version is not set, it will be not be imported")
        fd_aios = None

# =============================================================================

elif gl_config.parameters.get("hardware_layer") == "fourier-core-hardware":
    if gl_config.parameters.get("fi_fse", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core_hardware.hardware.fi.fi_fse_v1 as fi_fse
    else:
        Logger().print_debug("fi_fse version is not set, default version will be imported")
        import fourier_core_hardware.hardware.fi.fi_fse_v1 as fi_fse

    if gl_config.parameters.get("fi_fsa", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core_hardware.hardware.fi.fi_fsa_v1 as fi_fsa
    elif gl_config.parameters.get("fi_fsa", {}).get("version", "UNKNOWN") == "v1_9":
        import fourier_core_hardware.hardware.fi.fi_fsa_v1_9 as fi_fsa
    elif gl_config.parameters.get("fi_fsa", {}).get("version", "UNKNOWN") == "v2":
        import fourier_core_hardware.hardware.fi.fi_fsa_v2 as fi_fsa
    elif gl_config.parameters.get("fi_fsa", {}).get("version", "UNKNOWN") == "v2_subscribe":
        import fourier_core_hardware.hardware.fi.fi_fsa_v2_subscribe as fi_fsa
    else:
        Logger().print_debug("fi_fsa version is not set, default version will be imported")
        import fourier_core_hardware.hardware.fi.fi_fsa_v1 as fi_fsa

    if gl_config.parameters.get("fi_ioboard_typea", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core_hardware.hardware.fi.fi_ioboard_typea as fi_ioboard_typea
    else:
        Logger().print_debug("fi_ioboard_typea version is not set, default version will be imported")
        import fourier_core_hardware.hardware.fi.fi_ioboard_typea as fi_ioboard_typea

    if gl_config.parameters.get("fi_sensor_ethernet", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core_hardware.hardware.fi.fi_sensor_ethernet as fi_sensor_ethernet
    else:
        Logger().print_debug("fi_sensor_ethernet version is not set, default version will be imported")
        import fourier_core_hardware.hardware.fi.fi_sensor_ethernet as fi_sensor_ethernet

    if gl_config.parameters.get("hipnuc_imu_usb", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core_hardware.hardware.hipnuc.hipnuc_imu_usb_ischedule as hipnuc_imu_usb
    else:
        Logger().print_debug("hipnuc_imu_usb version is not set, default version will be imported")
        import fourier_core_hardware.hardware.hipnuc.hipnuc_imu_usb_ischedule as hipnuc_imu_usb

    if gl_config.parameters.get("taobotics_imu_usb", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core_hardware.hardware.taobotics.taobotics_imu_usb_ischedule as taobotics_imu_usb
    else:
        Logger().print_debug("taobotics_imu_usb version is not set, default version will be imported")
        import fourier_core_hardware.hardware.taobotics.taobotics_imu_usb_ischedule as taobotics_imu_usb

    if gl_config.parameters.get("fd_aios", {}).get("version", "UNKNOWN") == "v1":
        import fourier_core_hardware.hardware.fd.fd_aios_v1 as fd_aios
    elif gl_config.parameters.get("fd_aios", {}).get("version", "UNKNOWN") == "v2":
        import fourier_core_hardware.hardware.fd.fd_aios_v2 as fd_aios
    else:
        Logger().print_debug("fd_aios version is not set, it will be not be imported")
        fd_aios = None

# =============================================================================

else:
    Logger().print_error("config file hardware_layer is not supported, program stopped.")
    exit(FunctionResult.FAIL)
