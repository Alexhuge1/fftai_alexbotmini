try:
    from fourier_core.config.fi_config import gl_config
except ImportError:
    from .fi_hardware_config import gl_config

from .fi_hardware_predefine import HardwareType
from .fi_hardware_base import HardwareBase
from .fi_hardware_disconnect import HardwareDisconnect
from .fi_hardware_x64 import HardwareX64
from .fi_hardware_rk3399 import HardwareRK3399
from .fi_hardware_logger import Logger


class HardwareInterface:
    type = ""
    instance = None

    def __new__(cls):
        if not hasattr(cls, '_instance'):
            cls._instance = super().__new__(cls)

        return cls._instance

    def __init__(self):
        pass


if gl_config.parameters.get("device_connected", True) is True:
    if gl_config.parameters.get("cpu", HardwareType.X64) == HardwareType.X64:
        HardwareInterface().type = HardwareType.X64
        HardwareInterface().instance = HardwareX64()
        Logger().print_success("HardwareInterface device set connected: hardware platform init X64")

    elif gl_config.parameters.get("cpu", HardwareType.RK3399) == HardwareType.RK3399:
        HardwareInterface().type = HardwareType.RK3399
        HardwareInterface().instance = HardwareRK3399()
        Logger().print_success("HardwareInterface device set connected: hardware platform init RK3399")

    else:
        HardwareInterface().type = HardwareType.Base
        HardwareInterface().instance = HardwareBase()
        Logger().print_error("HardwareInterface device set disconnected: incompatible cpu type")

else:
    HardwareInterface().type = HardwareType.Disconnect
    HardwareInterface().instance = HardwareDisconnect()
    Logger().print_warning("HardwareInterface device set disconnected: config to disconnected")
