import socket
import time
import numpy
import serial
import serial.tools.list_ports
from multiprocessing import Process
from queue import Queue
from threading import Thread
from ischedule import run_loop, schedule

from .hipnuc_logger import Logger
from .hipnuc_predefine import (
    FunctionResult,
    FlagState,
)
from .hipnuc_protocol import (
    HipnucFrame_NotCompleted_Exception,
    HipnucFrame_ErrorFrame_Exception,
    intercept_one_complete_frame,
    extraction_information_from_frame,
    find_frameheader,
)

# 对象字典，用于存储设备的全部 IMU 信息，缓存数据，方便机器人快速获取
usb_imu_hipnuc_od = {}

# 全局变量（用于子进程）
usb_imu_hipnuc_socket = None
usb_imu_hipnuc_socket_address = None

usb_imu_hipnuc_usb_imu = None
usb_imu_hipnuc_serial = None
usb_imu_hipnuc_binbuffer = None
usb_imu_hipnuc_fifobuffer = None
usb_imu_hipnuc_report_datatype = None


# ---------------------------------------------------------------------------------------------------------------------

def thread_usb_imu_hipnuc_receive(usb_imu, socket_port, check_frequency=False):
    global usb_imu_hipnuc_od

    usb_imu_hipnuc_socket_address = ("127.0.0.1", socket_port)

    Logger().print_info(f"子线程 usb_imu = {usb_imu}")
    Logger().print_info(f"子线程 od = {usb_imu_hipnuc_od}")
    Logger().print_info(f"子线程 接收 socket_address = {usb_imu_hipnuc_socket_address}")

    # 创建数据传输 socket
    try:
        usb_imu_hipnuc_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        usb_imu_hipnuc_socket.bind(usb_imu_hipnuc_socket_address)
        usb_imu_hipnuc_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 512)
    except Exception as e:
        Logger().print_error(f"USB IMU Hipnuc {usb_imu} socket create error: {e}")
        return FunctionResult.FAIL

    current_time = time.time()
    receive_count = 0

    # 数据接收
    while True:
        try:
            data, _ = usb_imu_hipnuc_socket.recvfrom(256)
            data = data.decode()
            usb_imu_hipnuc_od.update({usb_imu: eval(data)})

            if check_frequency:
                receive_count += 1
                if time.time() - current_time >= 1:
                    Logger().print_info(f"子线程 usb_imu = {usb_imu} receive_count = {receive_count}")
                    receive_count = 0
                    current_time = time.time()
        except Exception as e:
            Logger().print_error(f"USB IMU Hipnuc {usb_imu} socket receive error: {e}")
            return FunctionResult.FAIL


def process_usb_imu_hipnuc_send(usb_imu, socket_port, data_upload_period=0.002):
    global \
        usb_imu_hipnuc_od, \
        usb_imu_hipnuc_socket, \
        usb_imu_hipnuc_socket_address, \
        usb_imu_hipnuc_usb_imu, \
        usb_imu_hipnuc_serial, \
        usb_imu_hipnuc_binbuffer, \
        usb_imu_hipnuc_fifobuffer, \
        usb_imu_hipnuc_report_datatype

    usb_imu_hipnuc_od.update({usb_imu: {}})
    usb_imu_hipnuc_socket_address = ("127.0.0.1", socket_port)

    Logger().print_info(f"子进程 usb_imu = {usb_imu}")
    Logger().print_info(f"子进程 od = {usb_imu_hipnuc_od}")
    Logger().print_info(f"子进程 发送 socket_address = {usb_imu_hipnuc_socket_address}")

    # 创建数据传输 socket
    usb_imu_hipnuc_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    # 打开串口
    usb_imu_hipnuc_usb_imu = usb_imu

    try:
        usb_imu_hipnuc_serial = serial.Serial(port=usb_imu, baudrate=921600, timeout=1.0)
    except Exception as e:
        Logger().print_error(f"USB IMU Hipnuc {usb_imu} init error: {e}")
        return FunctionResult.FAIL

    if usb_imu_hipnuc_serial.is_open:
        Logger().print_info(f"USB IMU Hipnuc {usb_imu} is already opened.")
    else:
        usb_imu_hipnuc_serial.open()

    # 配置模块数据发送频率, 单位 s (ASCII)
    usb_imu_hipnuc_serial.write(f"LOG IMU91 ONTIME {data_upload_period}\r\n".encode())

    # 配置缓冲区
    usb_imu_hipnuc_binbuffer = []
    usb_imu_hipnuc_fifobuffer = Queue()
    usb_imu_hipnuc_report_datatype = {
        "imusol": True,
        "gwsol": True,
        "id": True,
        "acc": True,
        "gyr": True,
        "mag": False,
        "euler": True,
        "quat": True,
        "imusol_raw": False,
        "gwsol_raw": False,
    }

    # 配置延时器
    target_read_data_period_in_s = data_upload_period  # update frequency
    Logger().print_info(f"子进程 upload_period = {target_read_data_period_in_s}")

    # 配置任务
    schedule(schedule_usb_imu_hipnuc_send, interval=target_read_data_period_in_s)

    # 启动调度器
    run_loop()

    # 关闭串口
    if usb_imu_hipnuc_serial.is_open:
        usb_imu_hipnuc_serial.close()
    else:
        Logger().print_info(f"USB IMU Hipnuc {usb_imu} is already closed.")

    # 关闭 socket
    if usb_imu_hipnuc_socket is not None:
        usb_imu_hipnuc_socket.close()

    return FunctionResult.SUCCESS


def schedule_usb_imu_hipnuc_send():
    global \
        usb_imu_hipnuc_od, \
        usb_imu_hipnuc_socket, \
        usb_imu_hipnuc_socket_address, \
        usb_imu_hipnuc_usb_imu, \
        usb_imu_hipnuc_serial, \
        usb_imu_hipnuc_binbuffer, \
        usb_imu_hipnuc_fifobuffer, \
        usb_imu_hipnuc_report_datatype

    usb_imu = usb_imu_hipnuc_usb_imu

    # 数据解析
    if usb_imu_hipnuc_od.get(usb_imu).get("thread_kill_flag") == FlagState.SET:
        return FunctionResult.FAIL

    # --------------------------------------------------------------------------------------------------------------

    # 读取数据
    try:
        usb_imu_hipnuc_serial_buff_count = usb_imu_hipnuc_serial.in_waiting
    except Exception as e:
        Logger().print_error(f"USB IMU Hipnuc {usb_imu} inWaiting error: {e}")
        return FunctionResult.FAIL

    if usb_imu_hipnuc_serial_buff_count > 0:
        usb_imu_hipnuc_serial_buff = usb_imu_hipnuc_serial.read(usb_imu_hipnuc_serial_buff_count)
        usb_imu_hipnuc_binbuffer.extend(usb_imu_hipnuc_serial_buff)

        # 解析数据
        try:
            while True:
                # 嘗試查找完整幀,若失敗會拋出異常
                headerpos, endpos = intercept_one_complete_frame(usb_imu_hipnuc_binbuffer)

                # 解析完整幀
                extraction_information_from_frame(
                    usb_imu_hipnuc_binbuffer[headerpos: endpos + 1],
                    usb_imu_hipnuc_fifobuffer,
                    usb_imu_hipnuc_report_datatype,
                )

                usb_imu_hipnuc_binbuffer = usb_imu_hipnuc_binbuffer[endpos + 1:]

        except HipnucFrame_NotCompleted_Exception:
            # 接收進行中
            pass

        except HipnucFrame_ErrorFrame_Exception as e:
            Logger().print_error(e)
            # 目前幀有幀頭，但是為錯誤幀，跳過錯誤幀
            headerpos = find_frameheader(usb_imu_hipnuc_binbuffer)
            usb_imu_hipnuc_binbuffer = usb_imu_hipnuc_binbuffer[headerpos + 1:]

    # --------------------------------------------------------------------------------------------------------------

    while not usb_imu_hipnuc_fifobuffer.empty():
        usb_imu_hipnuc_fifobuffer_value = usb_imu_hipnuc_fifobuffer.get(block=True, timeout=0.001)

        # print(usb_imu_hipnuc_fifobuffer.qsize())

        # 数据覆盖
        usb_imu_hipnuc_od.get(usb_imu).update(
            {
                "quat": [
                    usb_imu_hipnuc_fifobuffer_value["quat"][0]["X"],
                    usb_imu_hipnuc_fifobuffer_value["quat"][0]["Y"],
                    usb_imu_hipnuc_fifobuffer_value["quat"][0]["Z"],
                    usb_imu_hipnuc_fifobuffer_value["quat"][0]["W"],
                ],
                "angle_degree": [
                    usb_imu_hipnuc_fifobuffer_value["euler"][0]["Roll"],
                    usb_imu_hipnuc_fifobuffer_value["euler"][0]["Pitch"],
                    usb_imu_hipnuc_fifobuffer_value["euler"][0]["Yaw"],
                ],
                "angular_velocity": [
                    usb_imu_hipnuc_fifobuffer_value["gyr"][0]["X"],
                    usb_imu_hipnuc_fifobuffer_value["gyr"][0]["Y"],
                    usb_imu_hipnuc_fifobuffer_value["gyr"][0]["Z"],
                ],
                "acceleration": [
                    usb_imu_hipnuc_fifobuffer_value["acc"][0]["X"],
                    usb_imu_hipnuc_fifobuffer_value["acc"][0]["Y"],
                    usb_imu_hipnuc_fifobuffer_value["acc"][0]["Z"],
                ],
            }
        )

        # 推送数据
        try:
            usb_imu_hipnuc_socket.sendto(str(usb_imu_hipnuc_od.get(usb_imu)).encode(), usb_imu_hipnuc_socket_address)
        except Exception as e:
            Logger().print_error("USB IMU Hipnuc ", usb_imu, "socket sendto error: ", e)
            return FunctionResult.FAIL

    return FunctionResult.SUCCESS


# ---------------------------------------------------------------------------------------------------------------------


def authorize(usb_imu):
    # device authentication
    # 1. check all usb devices
    import os
    import serial

    ports = [port.device for port in serial.tools.list_ports.comports() if "USB" in port.device]

    # 2. check if the usb device exist
    if usb_imu not in ports:
        Logger().print_error("USB not found: " + usb_imu)
        Logger().print_error("Please check the connection of the USB device!")
        return FunctionResult.FAIL

    # 3. call script to setup usb(/dev/ttyUSB0) authority
    Logger().print_info("sudo chmod 777 " + usb_imu)
    try:
        os.system("sudo chmod 777 " + usb_imu)
    except Exception as e:
        Logger().print_error("USB authority setup failed: " + str(e))
        return FunctionResult.FAIL

    return FunctionResult.SUCCESS


def init(usb_imu):
    global usb_imu_hipnuc_od

    # 初始化字典 (od)
    usb_imu_hipnuc_od.update({usb_imu: {}})

    # 准备初始化数据 (od)
    usb_imu_hipnuc_od.get(usb_imu, {}).update(
        {
            "quat": [0, 0, 0, 0],
            "angle_degree": [0, 0, 0],
            "angular_velocity": [0, 0, 0],
            "acceleration": [0, 0, 0],
        }
    )

    return FunctionResult.SUCCESS


def comm(usb_imu, enable=True, frequency=100, check_frequency=False):
    global usb_imu_hipnuc_od

    if frequency not in [1, 2, 10, 50, 100, 200, 500, 1000]:
        Logger().print_error("USB IMU Hipnuc ", usb_imu, " frequency error: ", frequency)
        return FunctionResult.FAIL

    socket_port = 20000 + len(usb_imu_hipnuc_od)
    data_upload_period = 1 / frequency

    if enable:
        # 授权
        if authorize(usb_imu) == FunctionResult.FAIL:
            exit(FunctionResult.FAIL)

        # 清除线程杀死标志位
        usb_imu_hipnuc_od.get(usb_imu).update({"kill_flag": FlagState.CLEAR})

        # 创建子线程（用于接收 socket 数据）
        usb_imu_hipnuc_comm_thread = Thread(
            target=thread_usb_imu_hipnuc_receive, args=(usb_imu, socket_port, check_frequency)
        )
        usb_imu_hipnuc_comm_thread.start()

        # 等待子线程启动
        time.sleep(0.5)

        # 创建子进程（用于发送 socket 数据）
        usb_imu_hipnuc_comm_process = Process(
            target=process_usb_imu_hipnuc_send, args=(usb_imu, socket_port, data_upload_period)
        )
        usb_imu_hipnuc_comm_process.start()

        # 等待子进程启动
        time.sleep(0.5)

    else:
        usb_imu_hipnuc_od.get(usb_imu).update({"kill_flag": FlagState.SET})

    return FunctionResult.SUCCESS


def upload(usb_imu):
    # 更新放到子线程中...
    return FunctionResult.SUCCESS


def get_quat(usb_imu):
    global usb_imu_hipnuc_od

    if usb_imu_hipnuc_od.get(usb_imu) is not None:
        quat = usb_imu_hipnuc_od.get(usb_imu).get("quat")
    else:
        quat = [0, 0, 0, 0]

    return quat


def get_angle(usb_imu):
    global usb_imu_hipnuc_od

    if usb_imu_hipnuc_od.get(usb_imu) is not None:
        angle_degree = usb_imu_hipnuc_od.get(usb_imu).get("angle_degree")
    else:
        angle_degree = [0, 0, 0]

    return angle_degree


def get_angular_velocity(usb_imu):
    global usb_imu_hipnuc_od

    if usb_imu_hipnuc_od.get(usb_imu) is not None:
        angular_velocity = usb_imu_hipnuc_od.get(usb_imu).get("angular_velocity")
    else:
        angular_velocity = [0, 0, 0]

    return angular_velocity


def get_acceleration(usb_imu):
    global usb_imu_hipnuc_od

    if usb_imu_hipnuc_od.get(usb_imu) is not None:
        acceleration = usb_imu_hipnuc_od.get(usb_imu).get("acceleration")
    else:
        acceleration = [0, 0, 0]

    return acceleration


# ---------------------------------------------------------------------------------------------------------------------


# 测试代码
if __name__ == "__main__":
    import os

    import torch
    from ischedule import run_loop, schedule


    def euler_angle_ypr_to_quat(euler_angle_rpy):
        """
        Convert Euler angle (YPR) to Quaternion (XYZW)

        Input:
        - euler_angle: Euler angle (RPY) [deg]

        Output:
        - quat: Quaternion (XYZW)
        """
        euler_angle = numpy.deg2rad(euler_angle_rpy)

        roll = euler_angle[0] / 2
        pitch = euler_angle[1] / 2
        yaw = euler_angle[2] / 2

        cy = numpy.cos(yaw)
        sy = numpy.sin(yaw)
        cp = numpy.cos(pitch)
        sp = numpy.sin(pitch)
        cr = numpy.cos(roll)
        sr = numpy.sin(roll)

        quat_x = sr * cp * cy - cr * sp * sy
        quat_y = cr * sp * cy + sr * cp * sy
        quat_z = cr * cp * sy - sr * sp * cy
        quat_w = cr * cp * cy + sr * sp * sy

        quat = numpy.array([quat_x, quat_y, quat_z, quat_w])

        return quat


    def quat_rotate_inverse(q, v):
        shape = q.shape
        q_w = q[:, -1]
        q_vec = q[:, :3]
        a = v * (2.0 * q_w ** 2 - 1.0).unsqueeze(-1)
        b = torch.cross(q_vec, v, dim=-1) * q_w.unsqueeze(-1) * 2.0
        c = q_vec * torch.bmm(q_vec.view(shape[0], 1, 3), v.view(shape[0], 3, 1)).squeeze(-1) * 2.0
        return a - b + c


    def schedule_data_update():
        global usb_imu_hipnuc_od

        # record the time of start of read data
        # time_start_of_read_data_in_s = time.time()

        # ---------------------------------------------------------

        usb_imu_values = usb_imu_hipnuc_od.get(usb_imu).copy()

        raw_quat = usb_imu_values.get("quat")
        raw_euler = usb_imu_values.get("angle_degree")
        raw_angular_velocity = usb_imu_values.get("angular_velocity")
        raw_acceleration = usb_imu_values.get("acceleration")

        # upright installation direction
        # compatible_quat = numpy.array([-raw_quat[1], raw_quat[0], raw_quat[2], raw_quat[3]])
        # compatible_euler = numpy.array([-raw_euler[0],
        #                                 raw_euler[1],
        #                                 raw_euler[2]])

        # inverse installation direction
        # euler
        compatible_euler_angle = numpy.array(
            [-(180 - raw_euler[0]) if raw_euler[0] > 0 else 180 + raw_euler[0], -raw_euler[1], raw_euler[2]]
        )
        compatible_angular_velocity = numpy.array(
            [
                raw_angular_velocity[1],
                raw_angular_velocity[0],
                -raw_angular_velocity[2],
            ]
        )
        quat_from_euler = euler_angle_ypr_to_quat(euler_angle_rpy=compatible_euler_angle)

        # trick
        quat_from_trick = numpy.array([-raw_quat[3], -raw_quat[2], -raw_quat[0], raw_quat[1]])

        # rotation
        # from scipy.spatial.transform import Rotation as R

        # raw_rm = R.from_quat(raw_quat)
        # rotation_rm = R.from_euler('ZY', [-90, 180], degrees=True)
        # rotated_rm = raw_rm * rotation_rm
        # quat_from_rotation = rotated_rm.as_quat()

        # print("#############################################",
        #       f"gravity = {rotated_rm.inv().apply(numpy.array([0, 0, -1]))}", "\n",)

        # calculate
        # project gravity
        gravity_tensor = torch.from_numpy(numpy.array([[0, 0, -1]]).astype(numpy.float32))

        quat_tensor_from_trick = torch.from_numpy(quat_from_trick.astype(numpy.float32)).unsqueeze(0)
        projected_gravity_from_trick = quat_rotate_inverse(quat_tensor_from_trick, gravity_tensor)

        quat_tensor_from_euler = torch.from_numpy(quat_from_euler.astype(numpy.float32)).unsqueeze(0)
        projected_gravity_from_euler = quat_rotate_inverse(quat_tensor_from_euler, gravity_tensor)

        # quat_tensor_from_rotation = torch.from_numpy(quat_from_rotation.astype(numpy.float32)).unsqueeze(0)
        # projected_gravity_from_rotation = quat_rotate_inverse(quat_tensor_from_rotation, gravity_tensor)

        # print("#############################################",
        #       "raw ", "\n",
        #       "quat = ", numpy.round(raw_quat, 2), "\n",
        #       "euler = ", numpy.round(raw_euler, 2), "\n",
        #       "angular_velocity = ", numpy.round(raw_angular_velocity, 2), "\n",
        #       "compatible ", "\n",
        #       "compatible_euler_angle = ", numpy.round(compatible_euler_angle, 2), "\n",
        #       "compatible_angular_velocity = ", numpy.round(compatible_angular_velocity, 2), "\n",
        #       "calculate ", "\n",
        #       "quat_from_trick = ", numpy.round(quat_from_trick, 2), "\n",
        #       "quat_from_euler = ", numpy.round(quat_from_euler, 2), "\n",
        #       "quat_from_rotation = ", numpy.round(quat_from_rotation, 2), "\n",
        #       "algorithm ", "\n",
        #       "projected_gravity_from_trick = ", numpy.round(projected_gravity_from_trick.numpy(), 3), "\n",
        #       "projected_gravity_from_euler = ", numpy.round(projected_gravity_from_euler.numpy(), 3), "\n")

        # ---------------------------------------------------------


    ports = [port.device for port in serial.tools.list_ports.comports() if "USB" in port.device]
    Logger().print_info("当前电脑所连接的 {} 串口设备共 {} 个: {}".format("USB", len(ports), ports))

    # 调用脚本，设置 usb(/dev/ttyUSB0) 权限
    for i in range(len(ports)):
        port = ports[i]
        Logger().print_info("sudo chmod 777 " + port)
        os.system("sudo chmod 777 " + port)

    usb_imu = "/dev/ttyUSB0"
    if init(usb_imu) == FunctionResult.SUCCESS:
        pass
    else:
        exit(FunctionResult.FAIL)

    # Jason 2024-07-07:
    # Hipnuc IMU can only be set to 100Hz in python, higher frequency will cause data loss
    # Hipnuc IMU can be set to 500Hz in C++
    if comm(usb_imu, frequency=500, check_frequency=True) == FunctionResult.SUCCESS:
        pass
    else:
        exit(FunctionResult.FAIL)

    # sleep for child process to start
    time.sleep(1)

    # configure the loop period
    schedule(schedule_data_update, interval=(1 / 100))

    run_loop()

# ---------------------------------------------------------------------------------------------------------------------
