import time
import numpy
import serial
import serial.tools.list_ports
from multiprocessing import Manager, Process
from queue import Queue

from hipnuc_logger import Logger
from hipnuc_predefine import (
    FunctionResult,
    FlagState,
)
from hipnuc_protocol import (
    HipnucFrame_NotCompleted_Exception,
    HipnucFrame_ErrorFrame_Exception,
    intercept_one_complete_frame,
    extraction_information_from_frame,
    find_frameheader,
)

# 对象字典，用于存储设备的全部 IMU 信息，缓存数据，方便机器人快速获取
usb_imu_hipnuc_shared_od = {}
usb_imu_hipnuc_shared_manager = Manager()
usb_imu_hipnuc_od = {}

# 状态估计器
usb_imu_read_data_period = 0.002  # update frequency 500Hz


# usb_imu_read_data_period = 0.0025  # update frequency 400Hz
# usb_imu_read_data_period = 0.005  # update frequency 200Hz
# usb_imu_read_data_period = 0.01  # update frequency 100Hz


# ---------------------------------------------------------------------------------------------------------------------


def process_usb_imu_hipnuc_comm(usb_imu, parent_process_od_value):
    global usb_imu_hipnuc_shared_od, usb_imu_read_data_period

    print("子进程 usb_imu = ", usb_imu)
    print("子进程 od_value = ", parent_process_od_value)

    usb_imu_hipnuc_shared_od = dict(parent_process_od_value)

    # 打开串口
    try:
        usb_imu_hipnuc_serial = serial.Serial(port=usb_imu, baudrate=921600, timeout=1.0)
    except Exception as e:
        print("USB IMU Hipnuc ", usb_imu, " init error: ", e)
        return FunctionResult.FAIL

    if usb_imu_hipnuc_serial is not None:
        if usb_imu_hipnuc_serial.is_open:
            print("USB IMU Hipnuc ", usb_imu, " is already opened.")
        else:
            usb_imu_hipnuc_serial.open()
    else:
        print("USB IMU Hipnuc ", usb_imu, " is None")
        return FunctionResult.FAIL

    # 配置缓冲区
    usb_imu_hipnuc_binbuffer = []
    usb_imu_hipnuc_fifobuffer = Queue()
    usb_imu_hipnuc_report_datatype = {
        "imusol": True,
        "gwsol": True,
        "id": True,
        "acc": True,
        "gyr": True,
        "mag": False,
        "euler": True,
        "quat": True,
        "imusol_raw": False,
        "gwsol_raw": False,
    }

    # 配置延时器
    time_in_read_data_in_s = time.time()
    last_time_in_read_data_in_s = time.time()
    target_read_data_period_in_s = usb_imu_read_data_period  # update frequency

    # 数据解析
    while True:
        if usb_imu_hipnuc_shared_od.get(usb_imu).get("thread_kill_flag") == FlagState.SET:
            break

        # 记录数据采集时间
        time_in_read_data_in_s = time.time()
        read_data_period = time_in_read_data_in_s - last_time_in_read_data_in_s
        last_time_in_read_data_in_s = time_in_read_data_in_s

        # --------------------------------------------------------------------------------------------------------------
        time_start_of_read_data_in_s = time.time()

        # 读取数据
        try:
            usb_imu_hipnuc_serial_buff_count = usb_imu_hipnuc_serial.in_waiting
            # print("usb_imu_hipnuc_serial_buff_count = ", usb_imu_hipnuc_serial_buff_count)
        except Exception as e:
            print("USB IMU Hipnuc ", usb_imu, " inWaiting error: ", e)
            break
        else:
            if usb_imu_hipnuc_serial_buff_count > 0:
                usb_imu_hipnuc_serial_buff = usb_imu_hipnuc_serial.read(usb_imu_hipnuc_serial_buff_count)
                usb_imu_hipnuc_binbuffer.extend(usb_imu_hipnuc_serial_buff)

                # print(usb_imu_hipnuc_serial_buff_count)  # 测试采集数据的发送频率

                # 解析数据
                try:
                    while True:
                        # 嘗試查找完整幀,若失敗會拋出異常
                        headerpos, endpos = intercept_one_complete_frame(usb_imu_hipnuc_binbuffer)

                        # 解析完整幀
                        extraction_information_from_frame(
                            usb_imu_hipnuc_binbuffer[headerpos: endpos + 1],
                            usb_imu_hipnuc_fifobuffer,
                            usb_imu_hipnuc_report_datatype,
                        )

                        usb_imu_hipnuc_binbuffer = usb_imu_hipnuc_binbuffer[endpos + 1:]

                except HipnucFrame_NotCompleted_Exception:
                    # 接收進行中
                    pass

                except HipnucFrame_ErrorFrame_Exception as e:
                    print(e)
                    # 目前幀有幀頭，但是為錯誤幀，跳過錯誤幀
                    headerpos = find_frameheader(usb_imu_hipnuc_binbuffer)
                    usb_imu_hipnuc_binbuffer = usb_imu_hipnuc_binbuffer[headerpos + 1:]
                    pass

                # finally:
                #     pass

            else:
                # 没有数据的时候，不要更新共享变量 od_value，减少资源消耗
                pass

        # --------------------------------------------------------------------------------------------------------------

        if usb_imu_hipnuc_fifobuffer.empty() is False:
            usb_imu_hipnuc_fifobuffer_value = usb_imu_hipnuc_fifobuffer.get(block=True, timeout=1)
            # print("usb_imu_hipnuc_fifobuffer_value = \n", usb_imu_hipnuc_fifobuffer_value)

            # 数据覆盖
            usb_imu_hipnuc_shared_od.get(usb_imu).update(
                {
                    "quat": [
                        usb_imu_hipnuc_fifobuffer_value["quat"][0]["X"],
                        usb_imu_hipnuc_fifobuffer_value["quat"][0]["Y"],
                        usb_imu_hipnuc_fifobuffer_value["quat"][0]["Z"],
                        usb_imu_hipnuc_fifobuffer_value["quat"][0]["W"],
                    ],
                    "angle_degree": [
                        usb_imu_hipnuc_fifobuffer_value["euler"][0]["Roll"],
                        usb_imu_hipnuc_fifobuffer_value["euler"][0]["Pitch"],
                        usb_imu_hipnuc_fifobuffer_value["euler"][0]["Yaw"],
                    ],
                    "angular_velocity": [
                        usb_imu_hipnuc_fifobuffer_value["gyr"][0]["X"],
                        usb_imu_hipnuc_fifobuffer_value["gyr"][0]["Y"],
                        usb_imu_hipnuc_fifobuffer_value["gyr"][0]["Z"],
                    ],
                    "acceleration": [
                        usb_imu_hipnuc_fifobuffer_value["acc"][0]["X"],
                        usb_imu_hipnuc_fifobuffer_value["acc"][0]["Y"],
                        usb_imu_hipnuc_fifobuffer_value["acc"][0]["Z"],
                    ],
                }
            )

            parent_process_od_value.update({usb_imu: usb_imu_hipnuc_shared_od.get(usb_imu)})
            # print("子进程 usb_imu_hipnuc_shared_od = ", usb_imu_hipnuc_shared_od, "\n")

        time_end_of_read_data_in_s = time.time()
        time_of_read_data_in_s = time_end_of_read_data_in_s - time_start_of_read_data_in_s

        # --------------------------------------------------------------------------------------------------------------

        # wait for enough time for date update, and data to be ready
        time_to_sleep_in_s = target_read_data_period_in_s - time_of_read_data_in_s
        if time_to_sleep_in_s >= 0:
            pass
        else:
            time_to_sleep_in_s = 0

        time_to_sleep_mark_in_s = time.time()
        while True:
            time_offset_in_s = time.time() - time_to_sleep_mark_in_s
            if time_offset_in_s >= time_to_sleep_in_s:
                break

        # break

        # print("read_data_period: ", read_data_period)
        # print("hipnuc: ", numpy.round(usb_imu_hipnuc_shared_od.get(usb_imu).get("angle_degree"), 2))

    # 关闭串口
    if usb_imu_hipnuc_serial is not None:
        if usb_imu_hipnuc_serial.is_open:
            usb_imu_hipnuc_serial.close()
        else:
            print("USB IMU Hipnuc ", usb_imu, " is already closed.")
    else:
        print("USB IMU Hipnuc ", usb_imu, " is None")
        return FunctionResult.FAIL

    return FunctionResult.SUCCESS


# ---------------------------------------------------------------------------------------------------------------------


def authorize(usb_imu):
    # device authentication
    # 1. check all usb devices
    import os
    import serial

    ports = [port.device for port in serial.tools.list_ports.comports() if "USB" in port.device]

    # 2. check if the usb device exist
    if usb_imu not in ports:
        print("USB not found: " + usb_imu)
        print("Please check the connection of the USB device!")
        return FunctionResult.FAIL

    # 3. call script to setup usb(/dev/ttyUSB0) authority
    print("sudo chmod 777 " + usb_imu)
    try:
        os.system("sudo chmod 777 " + usb_imu)
    except Exception as e:
        print("USB authority setup failed: " + str(e))
        return FunctionResult.FAIL

    return FunctionResult.SUCCESS


def init(usb_imu):
    global usb_imu_hipnuc_shared_od, usb_imu_hipnuc_od, usb_imu_hipnuc_upload_thread

    # 初始化字典 (shared_od)
    usb_imu_hipnuc_shared_od.update({usb_imu: {}})

    # 准备初始化数据 (shared_od)
    usb_imu_hipnuc_shared_od.get(usb_imu).update(
        {
            "quat": [0, 0, 0, 0],
            "angle_degree": [0, 0, 0],
            "angular_velocity": [0, 0, 0],
            "acceleration": [0, 0, 0],
        }
    )

    # 初始化字典 (od)
    usb_imu_hipnuc_od.update({usb_imu: {}})

    # 准备初始化数据 (od)
    usb_imu_hipnuc_od.get(usb_imu).update(
        {
            "quat": [0, 0, 0, 0],
            "angle_degree": [0, 0, 0],
            "angular_velocity": [0, 0, 0],
            "acceleration": [0, 0, 0],
        }
    )

    return FunctionResult.SUCCESS


def comm(usb_imu, enable=True, frequency=100):
    global usb_imu_hipnuc_shared_od, usb_imu_hipnuc_shared_manager
    global usb_imu_read_data_period

    usb_imu_read_data_period = 1 / frequency

    if enable:
        # 授权
        if authorize(usb_imu) == FunctionResult.FAIL:
            exit(FunctionResult.FAIL)

        usb_imu_hipnuc_shared_od = usb_imu_hipnuc_shared_manager.dict(usb_imu_hipnuc_shared_od)

        # 创建子线程
        # usb_imu_hipnuc_comm_thread = Thread(target=thread_usb_imu_hipnuc_comm, args=(usb_imu,))
        # usb_imu_hipnuc_comm_thread.start()
        # usb_imu_hipnuc_shared_od.get(usb_imu).update({"thread": usb_imu_hipnuc_comm_thread})
        # usb_imu_hipnuc_shared_od.get(usb_imu).update({"thread_kill_flag": FlagState.CLEAR})

        # 创建子进程
        usb_imu_hipnuc_comm_process = Process(
            target=process_usb_imu_hipnuc_comm, args=(usb_imu, usb_imu_hipnuc_shared_od)
        )
        usb_imu_hipnuc_comm_process.start()

        print("父进程 usb_imu_hipnuc_shared_od_ = ", usb_imu_hipnuc_shared_od)

        value = usb_imu_hipnuc_shared_od.get(usb_imu)
        # value.update({"process": usb_imu_hipnuc_comm_process})  # process 不允许加入字典，用于共享内存
        value.update({"process_kill_flag": FlagState.CLEAR})
        usb_imu_hipnuc_shared_od.update({usb_imu: value})  # multiprocessing.Manager 只允许从最外层的字典中更新数据

        # while True:
        #     time.sleep(1)
        #     print("父进程 usb_imu_hipnuc_shared_od = ", usb_imu_hipnuc_shared_od, "\n")
    else:
        # 杀死子线程
        # usb_imu_hipnuc_shared_od.get(usb_imu).update({"thread_kill_flag": FlagState.SET})
        # usb_imu_hipnuc_thread = usb_imu_hipnuc_shared_od.get(usb_imu).get("thread")
        # usb_imu_hipnuc_thread.join()

        # 杀死子进程
        value = usb_imu_hipnuc_shared_od.get(usb_imu)
        value.update({"process_kill_flag": FlagState.SET})
        usb_imu_hipnuc_shared_od.update({usb_imu: value})  # multiprocessing.Manager 只允许从最外层的字典中更新数据

    return FunctionResult.SUCCESS


def upload(usb_imu):
    global usb_imu_hipnuc_od

    if usb_imu_hipnuc_od.get(usb_imu) is not None and usb_imu_hipnuc_shared_od.get(usb_imu) is not None:
        temp_usb_imu_hipnuc_shared_od_usb_imu = usb_imu_hipnuc_shared_od.get(usb_imu).copy()

        usb_imu_hipnuc_od.get(usb_imu).update(
            {
                "quat": temp_usb_imu_hipnuc_shared_od_usb_imu.get("quat"),
                "angle_degree": temp_usb_imu_hipnuc_shared_od_usb_imu.get("angle_degree"),
                "angular_velocity": temp_usb_imu_hipnuc_shared_od_usb_imu.get("angular_velocity"),
                "acceleration": temp_usb_imu_hipnuc_shared_od_usb_imu.get("acceleration"),
            }
        )

    return FunctionResult.SUCCESS


def get_quat(usb_imu):
    global usb_imu_hipnuc_od

    if usb_imu_hipnuc_od.get(usb_imu) is not None:
        quat = usb_imu_hipnuc_od.get(usb_imu).get("quat")
    else:
        quat = [0, 0, 0, 0]

    return quat


def get_angle(usb_imu):
    global usb_imu_hipnuc_od

    if usb_imu_hipnuc_od.get(usb_imu) is not None:
        angle_degree = usb_imu_hipnuc_od.get(usb_imu).get("angle_degree")
    else:
        angle_degree = [0, 0, 0]

    return angle_degree


def get_angular_velocity(usb_imu):
    global usb_imu_hipnuc_od

    if usb_imu_hipnuc_od.get(usb_imu) is not None:
        angular_velocity = usb_imu_hipnuc_od.get(usb_imu).get("angular_velocity")
    else:
        angular_velocity = [0, 0, 0]

    return angular_velocity


def get_acceleration(usb_imu):
    global usb_imu_hipnuc_od

    if usb_imu_hipnuc_od.get(usb_imu) is not None:
        acceleration = usb_imu_hipnuc_od.get(usb_imu).get("acceleration")
    else:
        acceleration = [0, 0, 0]

    return acceleration


# ---------------------------------------------------------------------------------------------------------------------


# 测试代码
if __name__ == "__main__":
    import os

    import torch


    def euler_angle_ypr_to_quat(euler_angle_rpy):
        """
        Convert Euler angle (YPR) to Quaternion (XYZW)

        Input:
        - euler_angle: Euler angle (RPY) [deg]

        Output:
        - quat: Quaternion (XYZW)
        """
        euler_angle = numpy.deg2rad(euler_angle_rpy)

        roll = euler_angle[0] / 2
        pitch = euler_angle[1] / 2
        yaw = euler_angle[2] / 2

        cy = numpy.cos(yaw)
        sy = numpy.sin(yaw)
        cp = numpy.cos(pitch)
        sp = numpy.sin(pitch)
        cr = numpy.cos(roll)
        sr = numpy.sin(roll)

        quat_x = sr * cp * cy - cr * sp * sy
        quat_y = cr * sp * cy + sr * cp * sy
        quat_z = cr * cp * sy - sr * sp * cy
        quat_w = cr * cp * cy + sr * sp * sy

        quat = numpy.array([quat_x, quat_y, quat_z, quat_w])

        return quat


    def quat_rotate_inverse(q, v):
        shape = q.shape
        q_w = q[:, -1]
        q_vec = q[:, :3]
        a = v * (2.0 * q_w ** 2 - 1.0).unsqueeze(-1)
        b = torch.cross(q_vec, v, dim=-1) * q_w.unsqueeze(-1) * 2.0
        c = q_vec * torch.bmm(q_vec.view(shape[0], 1, 3), v.view(shape[0], 3, 1)).squeeze(-1) * 2.0
        return a - b + c


    ports = [port.device for port in serial.tools.list_ports.comports() if "USB" in port.device]
    print("当前电脑所连接的 {} 串口设备共 {} 个: {}".format("USB", len(ports), ports))

    # 调用脚本，设置 usb(/dev/ttyUSB0) 权限
    for i in range(len(ports)):
        port = ports[i]
        print("sudo chmod 777 " + port)
        os.system("sudo chmod 777 " + port)

    usb_imu = "/dev/ttyUSB0"
    if init(usb_imu) == FunctionResult.SUCCESS:
        comm(usb_imu, frequency=500)

    # sleep for child process to start
    time.sleep(1)

    # configure the loop period
    time_in_read_data_in_s = time.time()
    last_time_in_read_data_in_s = time.time()
    target_read_data_period_in_s = 1.0  # usb_imu_read_data_period  # update frequency

    while True:
        # record the time of start of read data
        time_start_of_read_data_in_s = time.time()

        # ---------------------------------------------------------

        print("#############################################")

        usb_imu_values = usb_imu_hipnuc_shared_od.get(usb_imu).copy()

        raw_quat = usb_imu_values.get("quat")
        raw_euler = usb_imu_values.get("angle_degree")
        raw_angular_velocity = usb_imu_values.get("angular_velocity")
        raw_acceleration = usb_imu_values.get("acceleration")

        print(
            "raw ",
            "quat = ",
            numpy.round(raw_quat, 2),
            "euler = ",
            numpy.round(raw_euler, 2),
            "angular_velocity = ",
            numpy.round(raw_angular_velocity, 2),
        )

        # upright installation direction
        # compatible_quat = numpy.array([-raw_quat[1], raw_quat[0], raw_quat[2], raw_quat[3]])
        # compatible_euler = numpy.array([-raw_euler[0],
        #                                 raw_euler[1],
        #                                 raw_euler[2]])

        # inverse installation direction
        compatible_quat = numpy.array([-raw_quat[3], -raw_quat[2], -raw_quat[0], raw_quat[1]])
        compatible_euler = numpy.array(
            [-(180 - raw_euler[0]) if raw_euler[0] > 0 else 180 + raw_euler[0], -raw_euler[1], raw_euler[2]]
        )
        compatible_angular_velocity = numpy.array(
            [raw_angular_velocity[1], raw_angular_velocity[0], -raw_angular_velocity[2]]
        )

        print(
            "compatible ",
            "quat = ",
            numpy.round(compatible_quat, 2),
            "euler = ",
            numpy.round(compatible_euler, 2),
            "angular_velocity = ",
            numpy.round(compatible_angular_velocity, 2),
        )

        calculate_quat = euler_angle_ypr_to_quat(euler_angle_rpy=compatible_euler)

        print("calculate " "quat = ", numpy.round(calculate_quat, 2))

        gravity_tensor = torch.tensor([[0, 0, -1]], dtype=torch.float32)
        quat_tensor = torch.tensor([compatible_quat], dtype=torch.float32)

        projected_gravity = quat_rotate_inverse(quat_tensor, gravity_tensor)

        print("projected gravity = ", numpy.round(projected_gravity.numpy(), 2))

        # ---------------------------------------------------------

        # calculate the time to wait
        time_end_of_read_data_in_s = time.time()
        time_of_read_data_in_s = time_end_of_read_data_in_s - time_start_of_read_data_in_s

        # wait for enough time for date update, and data to be ready
        time_to_sleep_in_s = target_read_data_period_in_s - time_of_read_data_in_s
        if time_to_sleep_in_s >= 0:
            pass
        else:
            time_to_sleep_in_s = 0

        time_to_sleep_mark_in_s = time.time()
        while True:
            time_offset_in_s = time.time() - time_to_sleep_mark_in_s
            if time_offset_in_s >= time_to_sleep_in_s:
                break

    usb = "/dev/ttyUSB0"
    usb_imu_hipnuc_disable(usb)

# ---------------------------------------------------------------------------------------------------------------------
