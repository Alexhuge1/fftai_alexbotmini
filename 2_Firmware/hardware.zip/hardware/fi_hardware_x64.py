from .fi_hardware_connect import HardwareConnect


class HardwareX64(HardwareConnect):
    def __init__(self):
        super().__init__()

    # -------------------------------------------------------------------------

    from .fi_hardware_usb_imu_hipnuc import (
        usb_imu_hipnuc_init,
        usb_imu_hipnuc_comm,
        usb_imu_hipnuc_check,
        ################################
        usb_imu_hipnuc_upload,
        usb_imu_hipnuc_get_quat,
        usb_imu_hipnuc_get_angle,
        usb_imu_hipnuc_get_acceleration,
        usb_imu_hipnuc_get_angular_velocity,
    )

    # -------------------------------------------------------------------------

    from .fi_hardware_usb_imu_taobotics import (
        usb_imu_taobotics_init,
        usb_imu_taobotics_comm,
        usb_imu_taobotics_check,
        ################################
        usb_imu_taobotics_upload,
        usb_imu_taobotics_get_angle,
        usb_imu_taobotics_get_acceleration,
        usb_imu_taobotics_get_angular_velocity,
    )

    # -------------------------------------------------------------------------
